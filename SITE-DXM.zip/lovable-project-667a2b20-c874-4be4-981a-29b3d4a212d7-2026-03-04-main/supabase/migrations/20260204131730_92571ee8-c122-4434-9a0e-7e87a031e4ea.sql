-- Tabela para armazenar leads do formulário de contato
CREATE TABLE public.contact_leads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  message TEXT NOT NULL,
  source TEXT DEFAULT 'contato',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  read_at TIMESTAMP WITH TIME ZONE
);

-- Habilitar RLS
ALTER TABLE public.contact_leads ENABLE ROW LEVEL SECURITY;

-- Política: Qualquer pessoa pode inserir (enviar formulário)
CREATE POLICY "Anyone can insert leads"
ON public.contact_leads
FOR INSERT
TO anon
WITH CHECK (true);

-- Política: Usuários autenticados podem ver (para admin futuro)
CREATE POLICY "Authenticated users can view leads"
ON public.contact_leads
FOR SELECT
TO authenticated
USING (true);