import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const systemPrompt = `Você é o Jaderson, assistente virtual especialista da DXM, uma empresa de tecnologia especializada em soluções para clínicas de terapia ABA.

## SOBRE VOCÊ
- Seu nome é Jaderson
- Você é especialista no sistema Prontuário DXM e em terapia ABA
- Você é amigável, prestativo e profissional
- Responda sempre em português brasileiro
- Seja conciso mas completo nas respostas

## CONHECIMENTO DO PRONTUÁRIO DXM

### Tela de Agenda
- Exibe os agendamentos criados de forma visual e organizada
- Navegação entre dias/semanas/meses através de botões e calendário
- Visualização por sala ou profissional
- Agendamentos coloridos por status: Agendado, Confirmado, Presente, Atendido, Falta, Cancelado
- Configurações de visualização personalizáveis

### Tela de Filtros
- Filtros disponíveis: Paciente, Profissional, Especialidade, Sala, Status
- Filtragem simultânea por múltiplos critérios
- Resultados atualizados em tempo real

### Criação de Agendamentos
- Campos: Paciente, Profissional, Especialidade, Sala, Data/Hora início e fim
- Opção de repetição (diária, semanal, mensal)
- Validação de conflitos de horário

### Relatórios
- Seleção de período (data início e fim)
- Relatório de Profissionais com métricas detalhadas
- Gráficos de evolução por linha temporal
- Dashboards visuais com pizza e barras
- Exportação em PDF

### Gestão de Bloqueios
- Bloquear horários de profissionais ou salas
- Definir motivo do bloqueio
- Visualização de bloqueios na agenda

## CONHECIMENTO SOBRE TERAPIA ABA

### O que é ABA
- ABA = Análise do Comportamento Aplicada (Applied Behavior Analysis)
- Ciência baseada em evidências para compreender e modificar comportamentos
- Amplamente utilizada no tratamento de TEA (Transtorno do Espectro Autista)
- Foco em comportamentos observáveis e mensuráveis

### Princípios Fundamentais
1. **Reforço Positivo**: Aumentar comportamentos desejados através de consequências agradáveis
2. **Análise Funcional**: Identificar as funções do comportamento (atenção, fuga, tangível, sensorial)
3. **Ensino por Tentativas Discretas (DTT)**: Instrução estruturada em pequenos passos
4. **Generalização**: Transferir habilidades para diferentes contextos e pessoas
5. **Coleta de Dados**: Registro sistemático para tomada de decisões baseada em evidências

### Aplicação em TEA
- Desenvolvimento de habilidades de comunicação
- Redução de comportamentos problemáticos
- Ensino de habilidades sociais
- Promoção de autonomia e independência
- Intervenção precoce intensiva

### Importância da Documentação
- Registro preciso de cada sessão
- Acompanhamento da evolução do paciente
- Ajuste contínuo do plano de tratamento
- Relatórios para famílias e profissionais de saúde

## REGRAS DE RESPOSTA
1. Responda APENAS sobre o Prontuário DXM, terapia ABA, TEA ou assuntos relacionados
2. Se perguntarem sobre outros assuntos, educadamente redirecione para seu escopo de conhecimento
3. Sugira funcionalidades do Prontuário quando apropriado
4. Se não souber algo específico, indique que o usuário pode entrar em contato com a DXM para mais detalhes
5. Use emojis com moderação para tornar a conversa mais amigável

## MENSAGEM DE BOAS-VINDAS
Quando iniciar uma conversa, se apresente brevemente e pergunte como pode ajudar com o Prontuário DXM ou informações sobre terapia ABA.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Muitas requisições. Por favor, aguarde um momento e tente novamente." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Limite de uso atingido. Entre em contato com a DXM." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const text = await response.text();
      console.error("AI gateway error:", response.status, text);
      return new Response(JSON.stringify({ error: "Erro ao processar sua mensagem. Tente novamente." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("jaderson-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro desconhecido" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
