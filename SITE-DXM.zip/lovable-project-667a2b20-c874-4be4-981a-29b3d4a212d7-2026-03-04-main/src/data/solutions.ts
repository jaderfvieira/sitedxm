import { Database, Users, Workflow, Link as LinkIcon, BarChart3 } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface SolutionFeature {
  title: string;
  description: string;
}

export interface SolutionData {
  id: string;
  slug: string;
  icon: LucideIcon;
  title: string;
  subtitle: string;
  tagline: string;
  description: string;
  overview: string;
  marketPosition: string;
  features: SolutionFeature[];
  benefits: string[];
  idealFor: string[];
  whatsappMessage: string;
}

export const solutionsData: Record<string, SolutionData> = {
  protheus: {
    id: "protheus",
    slug: "/solucoes/protheus",
    icon: Database,
    title: "TOTVS Protheus",
    subtitle: "ERP Completo",
    tagline: "O ERP mais utilizado no Brasil, com mais de 40 anos de mercado.",
    description:
      "Gestão integrada de todos os processos empresariais em uma única plataforma robusta, desenvolvida para a realidade fiscal e tributária brasileira.",
    overview:
      "O TOTVS Protheus é o ERP líder de mercado no Brasil, com presença em mais de 50 segmentos de negócios e utilizado por empresas de todos os portes. Com mais de 40 anos de história, foi construído sobre o profundo conhecimento da legislação brasileira, tornando-o a escolha natural para empresas que precisam de compliance fiscal, contábil e trabalhista automatizado. Sua arquitetura modular permite que cada empresa implante apenas o que precisa, com a possibilidade de expandir conforme o crescimento do negócio. A integração nativa entre todos os módulos — financeiro, estoque, vendas, produção, fiscal e contábil — elimina retrabalho e garante dados consistentes em toda a operação.",
    marketPosition:
      "Líder de mercado no Brasil com mais de 40 anos de atuação e presença em +50 segmentos",
    features: [
      {
        title: "Gestão Financeira",
        description: "Contas a pagar, receber, fluxo de caixa e conciliação bancária integrados.",
      },
      {
        title: "Fiscal e Contábil",
        description: "SPED, ECF, ECD e obrigações acessórias totalmente automatizadas.",
      },
      {
        title: "Controle de Estoque",
        description: "Gestão de armazéns, rastreabilidade de lotes e movimentações em tempo real.",
      },
      {
        title: "Módulo de Vendas",
        description: "Pedidos, faturamento, CRM básico e gestão de representantes.",
      },
      {
        title: "Gestão de Produção",
        description: "Planejamento, ordens de produção, chão de fábrica e qualidade.",
      },
      {
        title: "Business Intelligence",
        description: "Dashboards e relatórios gerenciais para tomada de decisão estratégica.",
      },
      {
        title: "Gestão de Compras",
        description: "Cotações, pedidos de compra, aprovações e controle de fornecedores.",
      },
      {
        title: "Patrimonial",
        description: "Controle de ativos fixos, depreciação e inventário patrimonial.",
      },
    ],
    benefits: [
      "Conformidade fiscal e tributária automatizada para o ambiente brasileiro",
      "Redução significativa de custos operacionais e retrabalho",
      "Visibilidade completa de toda a operação em tempo real",
      "Tomada de decisão baseada em dados confiáveis e atualizados",
      "Escalabilidade para acompanhar o crescimento da empresa",
      "Integração nativa entre todos os módulos do negócio",
    ],
    idealFor: [
      "Empresas de médio e grande porte",
      "Indústrias com processos produtivos complexos",
      "Distribuidoras e atacadistas com alta movimentação de estoque",
      "Empresas com necessidade de compliance fiscal rigoroso",
      "Negócios com múltiplas filiais e operações descentralizadas",
    ],
    whatsappMessage:
      "Olá! Tenho interesse em saber mais sobre o TOTVS Protheus para a minha empresa.",
  },

  rm: {
    id: "rm",
    slug: "/solucoes/rm",
    icon: Users,
    title: "TOTVS RM",
    subtitle: "Gestão de Pessoas",
    tagline: "A solução líder em gestão de RH e folha de pagamento no Brasil.",
    description:
      "Plataforma completa para gestão de capital humano, do recrutamento ao desligamento, com total conformidade ao eSocial e legislação trabalhista brasileira.",
    overview:
      "O TOTVS RM é a solução de gestão de recursos humanos mais completa do mercado brasileiro, reconhecida pela robustez no processamento da folha de pagamento e pela profunda integração com as obrigações legais brasileiras como eSocial, FGTS Digital e Ponto Eletrônico. Utilizada por empresas de todos os portes e segmentos, a plataforma cobre todo o ciclo de vida do colaborador: desde o recrutamento e seleção, passando por admissão, gestão de benefícios, treinamento e desenvolvimento, avaliação de desempenho, até o desligamento. O portal do colaborador democratiza o acesso à informação, reduzindo a carga operacional do RH e aumentando a satisfação das equipes.",
    marketPosition:
      "Líder em gestão de RH no Brasil com cobertura completa do ciclo de vida do colaborador",
    features: [
      {
        title: "Folha de Pagamento",
        description: "Processamento robusto com suporte a múltiplas convenções coletivas e vínculos.",
      },
      {
        title: "eSocial e Obrigações",
        description: "Integração completa com eSocial, FGTS Digital, DIRF e RAIS.",
      },
      {
        title: "Recrutamento e Seleção",
        description: "ATS integrado com banco de talentos, triagem automatizada e onboarding digital.",
      },
      {
        title: "Gestão de Benefícios",
        description: "Controle de vale-transporte, plano de saúde, alimentação e benefícios flexíveis.",
      },
      {
        title: "Treinamento e Desenvolvimento",
        description: "LMS integrado com trilhas de aprendizagem e controle de certificações.",
      },
      {
        title: "Avaliação de Desempenho",
        description: "Ciclos de avaliação 360°, metas individuais e succession planning.",
      },
      {
        title: "Portal do Colaborador",
        description: "Self-service para holerites, férias, atestados e atualizações cadastrais.",
      },
      {
        title: "Controle de Ponto",
        description: "Integração com relógios de ponto, gestão de escalas e banco de horas.",
      },
    ],
    benefits: [
      "Conformidade total com a legislação trabalhista e previdenciária brasileira",
      "Redução de erros no processamento da folha de pagamento",
      "Automatização de rotinas repetitivas do RH, liberando a equipe para atividades estratégicas",
      "Melhor experiência para o colaborador com acesso self-service",
      "Gestão de talentos estruturada para retenção e desenvolvimento",
      "Relatórios gerenciais para tomada de decisão sobre pessoas",
    ],
    idealFor: [
      "Empresas com mais de 50 colaboradores",
      "Organizações com alta complexidade na folha de pagamento",
      "Empresas que precisam de conformidade rigorosa com o eSocial",
      "RHs que desejam migrar de planilhas para uma plataforma profissional",
      "Empresas em crescimento que precisam estruturar a gestão de pessoas",
    ],
    whatsappMessage:
      "Olá! Gostaria de conhecer o TOTVS RM para gestão de RH e folha de pagamento.",
  },

  fluig: {
    id: "fluig",
    slug: "/solucoes/fluig",
    icon: Workflow,
    title: "TOTVS Fluig",
    subtitle: "Processos e Colaboração",
    tagline: "A plataforma de BPM e ECM que digitaliza processos e acelera decisões.",
    description:
      "Transforme processos manuais em workflows digitais inteligentes, centralize documentos e conecte sua equipe em uma única plataforma de colaboração empresarial.",
    overview:
      "O TOTVS Fluig é uma plataforma de Business Process Management (BPM) e Enterprise Content Management (ECM) que permite às empresas digitalizar qualquer processo de negócio sem a necessidade de programação avançada. Com seu construtor visual de workflows, qualquer processo — desde aprovação de compras até onboarding de clientes — pode ser mapeado, automatizado e monitorado em tempo real. Além disso, o Fluig centraliza toda a gestão documental da empresa, garantindo controle de versões, rastreabilidade e conformidade. O portal corporativo conecta colaboradores, parceiros e clientes em um ambiente integrado, reduzindo o uso de e-mails e aumentando a produtividade.",
    marketPosition:
      "Plataforma líder de BPM e ECM no Brasil, integrada nativamente ao ecossistema TOTVS",
    features: [
      {
        title: "Construtor de Workflows",
        description: "Interface visual drag-and-drop para modelar qualquer processo sem código.",
      },
      {
        title: "Gestão de Documentos",
        description: "ECM completo com controle de versões, aprovações e armazenamento seguro.",
      },
      {
        title: "Portal Corporativo",
        description: "Intranet moderna com notícias, comunicados e espaços de colaboração.",
      },
      {
        title: "Formulários Dinâmicos",
        description: "Criação de formulários inteligentes com validações e lógica condicional.",
      },
      {
        title: "Assinatura Digital",
        description: "Assinatura eletrônica integrada para contratos e documentos oficiais.",
      },
      {
        title: "Analytics de Processos",
        description: "Dashboards de SLA, gargalos e performance de cada etapa do workflow.",
      },
      {
        title: "Integração com ERPs",
        description: "Conexão nativa com TOTVS Protheus, RM e outros sistemas via API.",
      },
      {
        title: "App Mobile",
        description: "Aprovações e tarefas de workflow disponíveis no smartphone.",
      },
    ],
    benefits: [
      "Eliminação de processos em papel, reduzindo custos e aumentando agilidade",
      "Rastreabilidade completa de cada etapa de qualquer processo",
      "Redução do tempo de aprovação e tomada de decisão",
      "Colaboração em tempo real entre equipes e departamentos",
      "Conformidade e auditoria facilitadas com histórico completo",
      "Aceleração do onboarding de novos colaboradores e clientes",
    ],
    idealFor: [
      "Empresas com processos de aprovação complexos e demorados",
      "Organizações que ainda dependem de papel para fluxos internos",
      "Empresas que precisam de gestão documental estruturada",
      "Times de RH, Financeiro e Jurídico com alto volume de processos",
      "Empresas que já usam TOTVS e querem expandir a automação",
    ],
    whatsappMessage:
      "Olá! Gostaria de saber como o TOTVS Fluig pode digitalizar processos na minha empresa.",
  },

  ipass: {
    id: "ipass",
    slug: "/solucoes/ipass",
    icon: LinkIcon,
    title: "TOTVS IPASS",
    subtitle: "Hub de Integrações",
    tagline: "Conecte qualquer sistema, automatize qualquer fluxo de dados.",
    description:
      "Plataforma iPaaS (Integration Platform as a Service) low-code que integra ERPs, e-commerces, APIs e sistemas legados sem necessidade de desenvolvimento complexo.",
    overview:
      "O TOTVS IPASS é uma plataforma de integração empresarial (iPaaS) que resolve um dos maiores desafios das empresas modernas: fazer sistemas diferentes se comunicarem de forma confiável e eficiente. Com uma abordagem low-code, o IPASS permite que times de TI e até analistas de negócio criem e gerenciem integrações entre ERPs, CRMs, e-commerces, marketplaces, transportadoras e qualquer outro sistema com API disponível. A plataforma oferece conectores prontos para os principais sistemas do mercado, além de um motor de orquestração robusto que garante a entrega, transformação e monitoramento de dados em tempo real.",
    marketPosition:
      "Hub de integração iPaaS da TOTVS com conectores prontos para os principais sistemas do mercado",
    features: [
      {
        title: "Conectores Prontos",
        description: "+200 conectores para ERPs, marketplaces, transportadoras e sistemas financeiros.",
      },
      {
        title: "Orquestração de APIs",
        description: "Motor de integração que garante a entrega e sequenciamento de chamadas.",
      },
      {
        title: "Transformação de Dados",
        description: "Mapeamento e conversão de formatos (JSON, XML, CSV, EDI) entre sistemas.",
      },
      {
        title: "Monitoramento em Tempo Real",
        description: "Dashboard de saúde das integrações com alertas automáticos de falhas.",
      },
      {
        title: "Logs e Auditoria",
        description: "Histórico completo de todas as mensagens trafegadas para rastreabilidade.",
      },
      {
        title: "Retry Automático",
        description: "Reprocessamento inteligente de transações com falha sem intervenção manual.",
      },
      {
        title: "Low-Code Builder",
        description: "Interface visual para criar e editar integrações sem programação avançada.",
      },
      {
        title: "Escalabilidade",
        description: "Arquitetura cloud-native que suporta altos volumes de transações simultâneas.",
      },
    ],
    benefits: [
      "Eliminação de retrabalho manual de digitação de dados entre sistemas",
      "Dados sincronizados e consistentes em toda a operação",
      "Redução de erros causados por integrações frágeis ou manuais",
      "Visibilidade total sobre o fluxo de dados entre sistemas",
      "Aceleração de novas integrações com conectores prontos",
      "Operação 24/7 sem dependência de intervenção humana",
    ],
    idealFor: [
      "Empresas com múltiplos sistemas que não se comunicam",
      "E-commerces que precisam integrar ERP, marketplace e logística",
      "Indústrias com integração entre sistemas de produção e ERP",
      "Times de TI sobrecarregados com manutenção de integrações",
      "Empresas em expansão que adquirem novos sistemas com frequência",
    ],
    whatsappMessage:
      "Olá! Preciso integrar sistemas na minha empresa e gostaria de conhecer o TOTVS IPASS.",
  },

  "rd-station": {
    id: "rd-station",
    slug: "/solucoes/rd-station",
    icon: BarChart3,
    title: "RD Station",
    subtitle: "Marketing e Vendas",
    tagline: "A plataforma líder em Martech no Brasil para gerar e converter leads.",
    description:
      "Automatize sua estratégia de marketing digital, nutra leads com inteligência e alinhe marketing e vendas para maximizar o ROI das suas campanhas.",
    overview:
      "O RD Station é a plataforma de automação de marketing e CRM mais utilizada no Brasil, com mais de 50.000 empresas clientes. Desenvolvida pela RD Station (Resultados Digitais), a plataforma oferece um conjunto completo de ferramentas para atrair visitantes, converter em leads, nutri-los com conteúdo relevante e entregá-los ao time de vendas no momento certo. Com o RD Station Marketing e o RD Station CRM integrados, as empresas têm visibilidade completa do funil de vendas, desde o primeiro clique até o fechamento do negócio, possibilitando decisões baseadas em dados e aumento consistente da receita.",
    marketPosition:
      "Líder em Martech no Brasil com +50.000 empresas clientes e ecossistema completo de marketing e vendas",
    features: [
      {
        title: "Landing Pages",
        description: "Construtor drag-and-drop para criar páginas de conversão de alta performance.",
      },
      {
        title: "Automação de E-mail",
        description: "Fluxos de nutrição inteligentes baseados no comportamento do lead.",
      },
      {
        title: "Lead Scoring",
        description: "Pontuação automática de leads para priorizar os mais prontos para compra.",
      },
      {
        title: "CRM Integrado",
        description: "Pipeline de vendas visual com gestão de oportunidades e follow-ups.",
      },
      {
        title: "Segmentação Avançada",
        description: "Segmente leads por comportamento, dados demográficos e estágio no funil.",
      },
      {
        title: "Integração com Anúncios",
        description: "Sincronização com Google Ads e Meta Ads para captura e mensuração de leads.",
      },
      {
        title: "Analytics e Relatórios",
        description: "ROI por canal, custo por lead e performance de cada campanha em tempo real.",
      },
      {
        title: "Formulários e Pop-ups",
        description: "Captura de leads em qualquer página do site com formulários inteligentes.",
      },
    ],
    benefits: [
      "Aumento significativo na geração de leads qualificados",
      "Jornada de compra automatizada que educa e converte",
      "ROI de marketing mensurável e transparente",
      "Alinhamento estratégico entre marketing e vendas",
      "Redução do custo de aquisição de clientes (CAC)",
      "Visibilidade completa do funil de vendas de ponta a ponta",
    ],
    idealFor: [
      "Empresas B2B com ciclo de vendas complexo",
      "Negócios que querem escalar a geração de leads digitais",
      "Times de marketing que precisam comprovar resultados para a diretoria",
      "Empresas migrando de marketing tradicional para o digital",
      "Startups e scale-ups com foco em crescimento acelerado",
    ],
    whatsappMessage:
      "Olá! Gostaria de saber como o RD Station pode aumentar a geração de leads da minha empresa.",
  },
};

export const solutionsList = Object.values(solutionsData);
