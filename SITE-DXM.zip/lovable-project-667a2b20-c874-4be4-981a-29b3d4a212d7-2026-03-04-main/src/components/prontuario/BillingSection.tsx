import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { 
  FileCode, 
  Landmark, 
  Calculator, 
  CalendarClock, 
  AlertTriangle,
  Settings,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

const billingFeatures = [
  {
    icon: FileCode,
    title: "Convênios",
    description: "Geração de XML, gestão de glosa, importação de arquivo de retorno e muito mais.",
    color: "hsl(210 100% 56%)",
  },
  {
    icon: Landmark,
    title: "Faturamento Liminar",
    description: "Controle de liminares de paciente e suas obrigatoriedades.",
    color: "hsl(50 97% 60%)",
  },
  {
    icon: Calculator,
    title: "Controle Financeiro",
    description: "Fluxo de caixa completo, borderôs de pagamento, contas a pagar e receber, integração bancária via CNAB.",
    color: "hsl(122 39% 49%)",
  },
  {
    icon: CalendarClock,
    title: "Previsão de Faturamento",
    description: "Conheça o seu fluxo financeiro de forma programada.",
    color: "hsl(6 76% 55%)",
  },
  {
    icon: AlertTriangle,
    title: "Falta Faturada",
    description: "Controle de falta faturada para pacientes faturados por liminar.",
    color: "hsl(210 100% 56%)",
  },
];

const topBadges = [
  { label: "Produtividade", color: "hsl(210 100% 56%)" },
  { label: "Experiência do Profissional", color: "hsl(50 97% 60%)" },
  { label: "+Segurança", color: "hsl(122 39% 49%)" },
];

const BillingSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="starry-bg py-20 lg:py-32 overflow-hidden relative"
    >
      {/* Decorative elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Floating gear icons */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          className="absolute top-20 right-10 opacity-10"
        >
          <Settings size={120} className="text-secondary" />
        </motion.div>
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-20 left-10 opacity-5"
        >
          <Settings size={180} className="text-secondary" />
        </motion.div>
      </div>

      <div className="container-dxm relative z-10">
        {/* Top Badges */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {topBadges.map((badge, index) => (
            <motion.div
              key={badge.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Badge
                className="px-4 py-1.5 text-xs font-semibold uppercase tracking-wider border-0"
                style={{
                  background: `linear-gradient(135deg, ${badge.color}20, ${badge.color}10)`,
                  color: badge.color,
                  boxShadow: `0 0 20px -5px ${badge.color}40`,
                }}
              >
                {badge.label}
              </Badge>
            </motion.div>
          ))}
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            {/* Header */}
            <div className="mb-10">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
                <span className="text-gradient-orange">Faturamento</span>
              </h2>
              <p className="text-white/50 text-lg leading-relaxed">
                Faturamento facilitador, com métodos práticos e controle absoluto, 
                apoiando na integridade dos processos de faturamento.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid sm:grid-cols-2 gap-4">
              {billingFeatures.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                  whileHover={{ scale: 1.02, x: 4 }}
                  className="group"
                >
                  <div
                    className="p-5 rounded-xl h-full transition-all duration-300"
                    style={{
                      background: "linear-gradient(135deg, hsl(234 29% 14% / 0.8), hsl(234 29% 10% / 0.6))",
                      borderLeft: `3px solid ${feature.color}`,
                      boxShadow: "0 4px 24px -8px hsl(0 0% 0% / 0.4)",
                    }}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
                        style={{
                          background: `linear-gradient(135deg, ${feature.color}30, ${feature.color}10)`,
                        }}
                      >
                        <feature.icon size={20} style={{ color: feature.color }} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white mb-1 text-sm">
                          {feature.title}
                        </h4>
                        <p className="text-white/50 text-xs leading-relaxed">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Footer Badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="mt-8 flex flex-wrap gap-3"
            >
              <Badge
                className="px-4 py-1.5 text-xs border-0"
                style={{
                  background: "linear-gradient(135deg, hsl(187 80% 48% / 0.2), hsl(187 80% 48% / 0.1))",
                  color: "hsl(187 80% 60%)",
                }}
              >
                TOTVS HIS
              </Badge>
              <Badge
                className="px-4 py-1.5 text-xs border-0"
                style={{
                  background: "linear-gradient(135deg, hsl(24 95% 53% / 0.2), hsl(24 95% 53% / 0.1))",
                  color: "hsl(24 95% 63%)",
                }}
              >
                Prontuário Eletrônico
              </Badge>
            </motion.div>
          </motion.div>

          {/* Right: Visual Element */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative"
          >
            {/* Decorative Card Stack */}
            <div className="relative">
              {/* Glow behind */}
              <div
                className="absolute -inset-8 rounded-3xl opacity-30 blur-3xl"
                style={{
                  background: "linear-gradient(135deg, hsl(187 80% 48% / 0.4), hsl(24 95% 53% / 0.3))",
                }}
              />

              {/* Main visual container */}
              <motion.div
                whileHover={{ rotateY: 5, rotateX: -5 }}
                transition={{ type: "spring", stiffness: 100 }}
                className="relative rounded-2xl overflow-hidden"
                style={{
                  background: "linear-gradient(180deg, hsl(210 40% 14%), hsl(210 40% 8%))",
                  border: "1px solid hsl(187 80% 48% / 0.2)",
                  boxShadow: "0 20px 60px -20px hsl(0 0% 0% / 0.6)",
                  transformStyle: "preserve-3d",
                }}
              >
                {/* Header bar */}
                <div
                  className="px-6 py-4"
                  style={{
                    background: "linear-gradient(90deg, hsl(187 80% 48% / 0.1), hsl(24 95% 53% / 0.05))",
                    borderBottom: "1px solid hsl(187 80% 48% / 0.2)",
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: "hsl(6 76% 55%)" }} />
                    <div className="w-3 h-3 rounded-full" style={{ background: "hsl(50 97% 60%)" }} />
                    <div className="w-3 h-3 rounded-full" style={{ background: "hsl(122 39% 49%)" }} />
                    <span className="ml-4 text-xs text-white/40">Módulo de Faturamento</span>
                  </div>
                </div>

                {/* Content simulation */}
                <div className="p-6 space-y-4">
                  {/* Stats row */}
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: "Guias Geradas", value: "1.248", color: "hsl(210 100% 56%)" },
                      { label: "XML Enviados", value: "856", color: "hsl(122 39% 49%)" },
                      { label: "Pendentes", value: "42", color: "hsl(50 97% 60%)" },
                    ].map((stat) => (
                      <motion.div
                        key={stat.label}
                        whileHover={{ scale: 1.05 }}
                        className="p-3 rounded-lg text-center"
                        style={{
                          background: `linear-gradient(135deg, ${stat.color}15, ${stat.color}05)`,
                          border: `1px solid ${stat.color}30`,
                        }}
                      >
                        <div className="text-lg font-bold" style={{ color: stat.color }}>
                          {stat.value}
                        </div>
                        <div className="text-[10px] text-white/40">{stat.label}</div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Progress bars simulation */}
                  <div className="space-y-3 pt-2">
                    {[
                      { label: "Convênio A", progress: 85, color: "hsl(210 100% 56%)" },
                      { label: "Particular", progress: 92, color: "hsl(122 39% 49%)" },
                      { label: "Convênio B", progress: 78, color: "hsl(24 95% 53%)" },
                    ].map((item, index) => (
                      <motion.div
                        key={item.label}
                        initial={{ opacity: 0, x: -20 }}
                        animate={inView ? { opacity: 1, x: 0 } : {}}
                        transition={{ duration: 0.5, delay: 0.8 + index * 0.15 }}
                      >
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-white/60">{item.label}</span>
                          <span style={{ color: item.color }}>{item.progress}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={inView ? { width: `${item.progress}%` } : {}}
                            transition={{ duration: 1, delay: 1 + index * 0.15 }}
                            className="h-full rounded-full"
                            style={{ background: item.color }}
                          />
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-3 pt-2">
                    <div
                      className="flex-1 py-2 rounded-lg text-center text-xs font-medium"
                      style={{
                        background: "linear-gradient(135deg, hsl(187 80% 48% / 0.2), hsl(187 80% 48% / 0.1))",
                        color: "hsl(187 80% 60%)",
                      }}
                    >
                      Gerar XML
                    </div>
                    <div
                      className="flex-1 py-2 rounded-lg text-center text-xs font-medium"
                      style={{
                        background: "linear-gradient(135deg, hsl(24 95% 53% / 0.2), hsl(24 95% 53% / 0.1))",
                        color: "hsl(24 95% 63%)",
                      }}
                    >
                      Exportar
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default BillingSection;
