import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { LayoutGrid, CalendarDays, Users, RefreshCw } from "lucide-react";
import prontuarioAgenda from "@/assets/prontuario-agenda.png";

const features = [
  {
    icon: LayoutGrid,
    title: "Visualização Inteligente",
    description:
      "Visualização de disponibilidade de multiprofissionais de forma rápida, prática e simples.",
    color: "hsl(210 100% 56%)",
  },
  {
    icon: CalendarDays,
    title: "Gerenciamento de Agendas",
    description:
      "Configuração e visualização diária, semanal e mensal para melhor organização.",
    color: "hsl(6 76% 55%)",
  },
  {
    icon: Users,
    title: "Multiprofissionais",
    description:
      "Gestão de horários do paciente com múltiplos profissionais no mesmo lugar.",
    color: "hsl(50 97% 60%)",
  },
  {
    icon: RefreshCw,
    title: "Agendamento de Sessões",
    description:
      "Agendamento e controle de forma recorrente, aumentando produtividade.",
    color: "hsl(122 39% 49%)",
  },
];

const AgendaSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-20 lg:py-32 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, hsl(234 29% 10%) 0%, hsl(234 29% 14%) 50%, hsl(234 29% 10%) 100%)",
      }}
    >
      {/* Decorative glow */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full blur-[150px]"
          style={{ background: "hsl(210 100% 56%)" }}
        />
        <div
          className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full blur-[120px]"
          style={{ background: "hsl(122 39% 49%)" }}
        />
      </div>

      <div className="container-dxm relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Screenshot */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative order-2 lg:order-1"
          >
            {/* Glow behind */}
            <div
              className="absolute -inset-4 rounded-3xl blur-2xl opacity-30"
              style={{
                background: "linear-gradient(135deg, hsl(210 100% 56% / 0.5), hsl(122 39% 49% / 0.5))",
              }}
            />

            {/* Screenshot with frame */}
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <img
                src={prontuarioAgenda}
                alt="Agenda do Prontuário ABA"
                className="w-full h-auto"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(234,29%,10%,0.3)] to-transparent pointer-events-none" />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="order-1 lg:order-2"
          >
            {/* Header */}
            <span className="text-sm font-semibold uppercase tracking-[0.2em] mb-4 block text-autism-gradient">
              Gestão de Tempo
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
              Agenda <span className="text-autism-gradient">Prática</span>
            </h2>
            <p className="text-white/50 text-lg mb-10 max-w-lg">
              Mais facilidade para consultar disponibilidades e agendar consultas e exames de forma
              intuitiva e rápida.
            </p>

            {/* Features Grid */}
            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  whileHover={{ scale: 1.02, x: 4 }}
                  className="p-4 rounded-xl transition-all"
                  style={{
                    background: "hsl(0 0% 100% / 0.05)",
                    border: "1px solid hsl(0 0% 100% / 0.08)",
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                    style={{ background: `${feature.color}20` }}
                  >
                    <feature.icon size={20} style={{ color: feature.color }} />
                  </div>
                  <h4 className="text-white font-semibold text-sm mb-1">{feature.title}</h4>
                  <p className="text-white/40 text-xs leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AgendaSection;
