import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Zap, TrendingUp, Heart } from "lucide-react";

const pillars = [
  {
    icon: Zap,
    title: "Agilidade",
    description: "Fluxo rápido para criação e aplicação de programas terapêuticos.",
    color: "hsl(210 100% 56%)",
    gradient: "from-[hsl(210,100%,56%)] to-[hsl(210,100%,40%)]",
  },
  {
    icon: TrendingUp,
    title: "+Produtividade",
    description: "Menos tempo no sistema, mais tempo dedicado ao paciente.",
    color: "hsl(50 97% 60%)",
    gradient: "from-[hsl(50,97%,60%)] to-[hsl(40,90%,50%)]",
  },
  {
    icon: Heart,
    title: "Experiência do Paciente",
    description: "Visualização rápida e prática do tratamento para todos os envolvidos.",
    color: "hsl(122 39% 49%)",
    gradient: "from-[hsl(122,39%,49%)] to-[hsl(122,39%,35%)]",
  },
];

const PillarsSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-20 lg:py-28 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, hsl(234 29% 8%) 0%, hsl(234 29% 12%) 50%, hsl(234 29% 8%) 100%)",
      }}
    >
      {/* Subtle glow */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full blur-[120px]"
          style={{
            background: "linear-gradient(90deg, hsl(210 100% 56% / 0.3), hsl(50 97% 60% / 0.2), hsl(122 39% 49% / 0.3))",
          }}
        />
      </div>

      <div className="container-dxm relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-sm font-semibold uppercase tracking-[0.2em] mb-4 block text-autism-gradient">
            Pilares do Sistema
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">
            Foco no que <span className="text-autism-gradient">importa</span>
          </h2>
        </motion.div>

        {/* Pillars Grid */}
        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {pillars.map((pillar, index) => (
            <motion.div
              key={pillar.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="text-center group"
            >
              {/* Animated Icon Container */}
              <motion.div
                animate={{
                  y: [0, -8, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: index * 0.3,
                }}
                className="relative inline-flex mb-6"
              >
                {/* Glow behind icon */}
                <motion.div
                  animate={{
                    opacity: [0.3, 0.6, 0.3],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: index * 0.2,
                  }}
                  className="absolute inset-0 rounded-full blur-xl"
                  style={{ background: pillar.color, opacity: 0.4 }}
                />

                {/* Icon circle */}
                <div
                  className={`relative w-20 h-20 rounded-full flex items-center justify-center bg-gradient-to-br ${pillar.gradient} shadow-lg transition-transform duration-300 group-hover:scale-110`}
                >
                  <pillar.icon size={32} className="text-white" />
                </div>
              </motion.div>

              {/* Title */}
              <h3 className="text-2xl font-bold text-white mb-3">{pillar.title}</h3>

              {/* Description */}
              <p className="text-white/50 text-base leading-relaxed max-w-xs mx-auto">
                {pillar.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PillarsSection;
