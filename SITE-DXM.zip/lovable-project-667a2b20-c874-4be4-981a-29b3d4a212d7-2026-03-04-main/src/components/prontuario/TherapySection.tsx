import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Target, TrendingUp, Zap } from "lucide-react";
import prontuarioDashboard from "@/assets/prontuario-dashboard.png";

const features = [
  {
    icon: Target,
    title: "Protocolos Personalizados",
    description:
      "Entendemos o seu negócio e trazemos a aplicação dos protocolos para nosso sistema de forma customizada.",
    color: "hsl(6 76% 55%)",
  },
  {
    icon: TrendingUp,
    title: "Evolução do Paciente",
    description:
      "Pais e profissionais com acesso amplo à evolução do paciente. Uma visualização rápida e prática do tratamento.",
    color: "hsl(50 97% 60%)",
  },
  {
    icon: Zap,
    title: "Praticidade de Aplicação",
    description:
      "A agilidade de aplicação de programas permite que o profissional passe mais tempo com o paciente.",
    color: "hsl(122 39% 49%)",
  },
];

const TherapySection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="bg-white py-20 lg:py-32 overflow-hidden">
      <div className="container-dxm">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            {/* Header */}
            <span className="text-sm font-semibold uppercase tracking-[0.2em] mb-4 block text-autism-gradient">
              Protocolos ABA
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Terapia{" "}
              <span className="text-autism-gradient">Ocupacional</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-10 max-w-lg">
              Fluxo ágil e prático para criação, associação e aplicação de programas terapêuticos
              individualizados.
            </p>

            {/* Features */}
            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.15 }}
                  whileHover={{ x: 8 }}
                  className="flex gap-4 p-4 rounded-xl transition-all border-l-4 bg-muted/50"
                  style={{ borderLeftColor: feature.color }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${feature.color}15` }}
                  >
                    <feature.icon size={24} style={{ color: feature.color }} />
                  </div>
                  <div>
                    <h4 className="text-foreground font-semibold mb-1">{feature.title}</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Screenshot */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            {/* Decorative elements */}
            <div
              className="absolute -top-8 -right-8 w-32 h-32 rounded-full opacity-20 blur-2xl"
              style={{ background: "hsl(6 76% 55%)" }}
            />
            <div
              className="absolute -bottom-8 -left-8 w-40 h-40 rounded-full opacity-15 blur-3xl"
              style={{ background: "hsl(122 39% 49%)" }}
            />

            {/* Screenshot with elevated frame */}
            <motion.div
              whileHover={{ scale: 1.02, rotateY: 3 }}
              transition={{ duration: 0.4 }}
              className="relative rounded-2xl overflow-hidden shadow-2xl border border-border"
              style={{ perspective: "1000px" }}
            >
              <img
                src={prontuarioDashboard}
                alt="Dashboard de Terapia ABA"
                className="w-full h-auto"
              />
            </motion.div>

            {/* Floating badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="absolute -bottom-6 -left-6 px-4 py-3 rounded-xl shadow-lg"
              style={{
                background: "linear-gradient(135deg, hsl(6 76% 55%), hsl(6 76% 45%))",
              }}
            >
              <div className="flex items-center gap-2 text-white">
                <Target size={18} />
                <span className="font-semibold text-sm">15+ Protocolos</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TherapySection;
