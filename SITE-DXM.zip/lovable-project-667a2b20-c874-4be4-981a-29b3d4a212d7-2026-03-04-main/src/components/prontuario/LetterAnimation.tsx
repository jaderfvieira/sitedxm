import { motion, Variants } from "framer-motion";

interface LetterAnimationProps {
  text: string;
  className?: string;
  delay?: number;
  gradient?: boolean;
}

export const LetterAnimation = ({ 
  text, 
  className = "", 
  delay = 0,
  gradient = false 
}: LetterAnimationProps) => {
  const letters = text.split("");
  
  const container: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.03,
        delayChildren: delay,
      },
    },
  };
  
  const letter: Variants = {
    hidden: { 
      opacity: 0, 
      y: 20,
      rotateX: -90,
    },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        type: "spring" as const,
        damping: 12,
        stiffness: 100,
      },
    },
  };

  return (
    <motion.span
      className={`inline-block ${className} ${gradient ? 'text-autism-gradient' : ''}`}
      variants={container}
      initial="hidden"
      animate="visible"
      style={{ perspective: 500 }}
    >
      {letters.map((char, index) => (
        <motion.span
          key={index}
          variants={letter}
          className="inline-block"
          style={{ 
            transformStyle: "preserve-3d",
            display: char === " " ? "inline" : "inline-block",
            minWidth: char === " " ? "0.3em" : "auto",
          }}
        >
          {char === " " ? "\u00A0" : char}
        </motion.span>
      ))}
    </motion.span>
  );
};
