import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Screenshot {
  src: string;
  title: string;
  description: string;
}

interface ScreenshotCarouselProps {
  screenshots: Screenshot[];
  autoPlay?: boolean;
  interval?: number;
}

export const ScreenshotCarousel = ({
  screenshots,
  autoPlay = true,
  interval = 5000,
}: ScreenshotCarouselProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [direction, setDirection] = useState(0);

  useEffect(() => {
    if (!autoPlay || isPaused) return;
    
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % screenshots.length);
    }, interval);
    
    return () => clearInterval(timer);
  }, [autoPlay, isPaused, interval, screenshots.length]);

  const goTo = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  const goNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % screenshots.length);
  };

  const goPrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + screenshots.length) % screenshots.length);
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 500 : -500,
      rotateY: direction > 0 ? 45 : -45,
      opacity: 0,
      scale: 0.8,
    }),
    center: {
      x: 0,
      rotateY: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 500 : -500,
      rotateY: direction < 0 ? 45 : -45,
      opacity: 0,
      scale: 0.8,
    }),
  };

  return (
    <div 
      className="relative"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Main carousel */}
      <div 
        className="relative overflow-hidden rounded-3xl"
        style={{ perspective: 1500 }}
      >
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              rotateY: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
            }}
            className="relative"
            style={{ transformStyle: "preserve-3d" }}
          >
            {/* Glow effect */}
            <div className="absolute -inset-4 rounded-3xl opacity-40 blur-2xl"
              style={{
                background: "linear-gradient(135deg, hsl(210 100% 56% / 0.3), hsl(6 76% 55% / 0.2), hsl(50 97% 60% / 0.2), hsl(122 39% 49% / 0.3))",
              }}
            />
            
            {/* Screenshot */}
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <img 
                src={screenshots[currentIndex].src} 
                alt={screenshots[currentIndex].title}
                className="w-full h-auto"
              />
              
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(234,29%,10%,0.5)] via-transparent to-transparent" />
              
              {/* Title overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-4 lg:p-8">
                <motion.h4 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-white text-xl lg:text-2xl font-semibold mb-2"
                >
                  {screenshots[currentIndex].title}
                </motion.h4>
                <motion.p 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-white/60 text-sm lg:text-base"
                >
                  {screenshots[currentIndex].description}
                </motion.p>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Navigation arrows */}
        <button
          onClick={goPrev}
          className="absolute left-2 lg:left-4 top-1/2 -translate-y-1/2 w-8 h-8 lg:w-12 lg:h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
        >
          <ChevronLeft size={18} className="lg:hidden" />
          <ChevronLeft size={24} className="hidden lg:block" />
        </button>
        <button
          onClick={goNext}
          className="absolute right-2 lg:right-4 top-1/2 -translate-y-1/2 w-8 h-8 lg:w-12 lg:h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
        >
          <ChevronRight size={18} className="lg:hidden" />
          <ChevronRight size={24} className="hidden lg:block" />
        </button>
      </div>

      {/* Dots indicator */}
      <div className="flex justify-center gap-2 lg:gap-3 mt-6 lg:mt-8">
        {screenshots.map((_, index) => (
          <button
            key={index}
            onClick={() => goTo(index)}
            className={`h-2 rounded-full transition-all duration-300 ${
              index === currentIndex 
                ? "w-8 autism-gradient-animated" 
                : "w-2 bg-white/30 hover:bg-white/50"
            }`}
          />
        ))}
      </div>
    </div>
  );
};
