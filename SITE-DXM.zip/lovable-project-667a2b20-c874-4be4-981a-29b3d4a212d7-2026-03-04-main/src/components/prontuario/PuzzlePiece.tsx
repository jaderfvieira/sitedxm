import { motion } from "framer-motion";

interface PuzzlePieceProps {
  color: "blue" | "red" | "yellow" | "green";
  size?: number;
  className?: string;
  delay?: number;
  duration?: number;
}

const colorMap = {
  blue: "hsl(210 100% 56%)",
  red: "hsl(6 76% 55%)",
  yellow: "hsl(50 97% 60%)",
  green: "hsl(122 39% 49%)",
};

export const PuzzlePiece = ({ 
  color, 
  size = 60, 
  className = "",
  delay = 0,
  duration = 6
}: PuzzlePieceProps) => {
  return (
    <motion.svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      initial={{ opacity: 0, scale: 0.5, rotate: -20 }}
      animate={{ 
        opacity: 0.15, 
        scale: 1, 
        rotate: 0,
        y: [0, -15, 0],
      }}
      transition={{
        opacity: { duration: 1, delay },
        scale: { duration: 0.8, delay },
        rotate: { duration: 0.8, delay },
        y: { 
          duration, 
          repeat: Infinity, 
          ease: "easeInOut",
          delay 
        },
      }}
    >
      <path
        d="M25,0 L25,20 C25,20 15,20 15,30 C15,40 25,40 25,40 L25,60 C25,60 15,60 15,70 C15,80 25,80 25,80 L25,100 L45,100 C45,100 45,90 55,90 C65,90 65,100 65,100 L85,100 L85,80 C85,80 75,80 75,70 C75,60 85,60 85,60 L85,40 C85,40 75,40 75,30 C75,20 85,20 85,20 L85,0 L65,0 C65,0 65,10 55,10 C45,10 45,0 45,0 L25,0"
        fill={colorMap[color]}
        fillOpacity="1"
      />
    </motion.svg>
  );
};
