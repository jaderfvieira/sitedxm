import { motion, useInView } from "framer-motion";
import { useRef } from "react";

interface ProgressBarProps {
  value: number;
  color: "blue" | "red" | "yellow" | "green";
  delay?: number;
}

const colorClasses = {
  blue: "bg-[hsl(210,100%,56%)]",
  red: "bg-[hsl(6,76%,55%)]",
  yellow: "bg-[hsl(50,97%,60%)]",
  green: "bg-[hsl(122,39%,49%)]",
};

export const ProgressBar = ({ value, color, delay = 0 }: ProgressBarProps) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  
  return (
    <div ref={ref} className="h-1.5 bg-white/10 rounded-full overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={isInView ? { width: `${value}%` } : {}}
        transition={{ duration: 1.5, delay, ease: "easeOut" }}
        className={`h-full rounded-full ${colorClasses[color]}`}
      />
    </div>
  );
};
