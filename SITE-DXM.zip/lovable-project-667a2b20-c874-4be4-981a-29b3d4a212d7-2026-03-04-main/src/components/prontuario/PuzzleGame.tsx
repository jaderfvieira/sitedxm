import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RotateCcw, Sparkles, Star, Move, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

// Celebration sound using Web Audio API
const playCelebrationSound = () => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    
    notes.forEach((freq, i) => {
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.value = freq;
      
      const startTime = audioCtx.currentTime + i * 0.12;
      gainNode.gain.setValueAtTime(0.25, startTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.35);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + 0.35);
    });
  } catch (e) {
    console.log('Audio not supported');
  }
};

interface PuzzlePieceData {
  id: number;
  color: "blue" | "red" | "yellow" | "green";
  currentPosition: { x: number; y: number };
  targetPosition: { x: number; y: number };
  isPlaced: boolean;
}

const colorMap = {
  blue: "hsl(210 100% 56%)",
  red: "hsl(6 76% 55%)",
  yellow: "hsl(50 97% 60%)",
  green: "hsl(122 39% 49%)",
};

// SVG paths for each piece with interlocking connectors
// Piece 1 (Top-Left): flat top, flat left, male right, male bottom
const piecePaths = {
  1: "M0,0 L70,0 L70,25 C70,25 80,25 80,35 C80,45 70,45 70,45 L70,70 L45,70 C45,70 45,80 35,80 C25,80 25,70 25,70 L0,70 L0,0 Z",
  // Piece 2 (Top-Right): flat top, female left, flat right, male bottom
  2: "M0,0 L70,0 L70,70 L45,70 C45,70 45,80 35,80 C25,80 25,70 25,70 L0,70 L0,45 C0,45 10,45 10,35 C10,25 0,25 0,25 L0,0 Z",
  // Piece 3 (Bottom-Left): female top, flat left, male right, flat bottom
  3: "M0,0 L25,0 C25,0 25,10 35,10 C45,10 45,0 45,0 L70,0 L70,25 C70,25 80,25 80,35 C80,45 70,45 70,45 L70,70 L0,70 L0,0 Z",
  // Piece 4 (Bottom-Right): female top, female left, flat right, flat bottom
  4: "M0,0 L25,0 C25,0 25,10 35,10 C45,10 45,0 45,0 L70,0 L70,70 L0,70 L0,45 C0,45 10,45 10,35 C10,25 0,25 0,25 L0,0 Z",
};

// Map piece ID to grid position for silhouettes
const pieceGridMap = {
  1: { x: 0, y: 0 }, // blue - top left
  2: { x: 1, y: 0 }, // red - top right
  3: { x: 0, y: 1 }, // yellow - bottom left
  4: { x: 1, y: 1 }, // green - bottom right
};

const initialPieces: PuzzlePieceData[] = [
  { id: 1, color: "blue", currentPosition: { x: -160, y: -120 }, targetPosition: { x: 0, y: 0 }, isPlaced: false },
  { id: 2, color: "red", currentPosition: { x: 160, y: -120 }, targetPosition: { x: 1, y: 0 }, isPlaced: false },
  { id: 3, color: "yellow", currentPosition: { x: -160, y: 120 }, targetPosition: { x: 0, y: 1 }, isPlaced: false },
  { id: 4, color: "green", currentPosition: { x: 160, y: 120 }, targetPosition: { x: 1, y: 1 }, isPlaced: false },
];

const shufflePositions = () => {
  const positions = [
    { x: -160, y: -120 },
    { x: 160, y: -120 },
    { x: -160, y: 120 },
    { x: 160, y: 120 },
  ];
  // Fisher-Yates shuffle
  for (let i = positions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [positions[i], positions[j]] = [positions[j], positions[i]];
  }
  return positions;
};

export const PuzzleGame = () => {
  const [pieces, setPieces] = useState<PuzzlePieceData[]>(() => {
    const shuffled = shufflePositions();
    return initialPieces.map((piece, i) => ({
      ...piece,
      currentPosition: shuffled[i],
    }));
  });
  const [isComplete, setIsComplete] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);
  const pieceSize = 70;
  const gap = 4;

  useEffect(() => {
    const allPlaced = pieces.every(p => p.isPlaced);
    if (allPlaced && !isComplete) {
      setIsComplete(true);
      setShowCelebration(true);
      // Play celebration sound
      const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!prefersReducedMotion) {
        playCelebrationSound();
      }
    }
  }, [pieces, isComplete]);

  const handleDragEnd = (pieceId: number, info: { point: { x: number; y: number } }) => {
    if (!gridRef.current) return;

    const gridRect = gridRef.current.getBoundingClientRect();
    const piece = pieces.find(p => p.id === pieceId);
    if (!piece || piece.isPlaced) return;

    // Calculate drop position relative to grid center
    const relativeX = info.point.x - gridRect.left;
    const relativeY = info.point.y - gridRect.top;

    // Calculate target cell center for this piece
    const targetCellCenterX = (piece.targetPosition.x + 0.5) * (pieceSize + gap);
    const targetCellCenterY = (piece.targetPosition.y + 0.5) * (pieceSize + gap);

    // Tolerance: 60% of piece size for easier snapping
    const tolerance = pieceSize * 0.6;
    
    // Check if within snap tolerance of correct cell
    const isWithinTolerance = 
      Math.abs(relativeX - targetCellCenterX) < tolerance &&
      Math.abs(relativeY - targetCellCenterY) < tolerance;

    // Check if cell is already occupied
    const cellOccupied = pieces.some(
      p => p.isPlaced && 
        p.targetPosition.x === piece.targetPosition.x && 
        p.targetPosition.y === piece.targetPosition.y
    );

    if (isWithinTolerance && !cellOccupied) {
      // Snap to correct position
      setPieces(prev =>
        prev.map(p =>
          p.id === pieceId
            ? {
                ...p,
                isPlaced: true,
                currentPosition: {
                  x: piece.targetPosition.x * (pieceSize + gap),
                  y: piece.targetPosition.y * (pieceSize + gap),
                },
              }
            : p
        )
      );
    } else {
      // Keep piece where it was dropped (don't snap back to original)
      const gridCenterX = gridRect.width / 2;
      const gridCenterY = gridRect.height / 2;
      const newX = relativeX - gridCenterX;
      const newY = relativeY - gridCenterY;

      setPieces(prev =>
        prev.map(p =>
          p.id === pieceId
            ? {
                ...p,
                currentPosition: { x: newX, y: newY },
              }
            : p
        )
      );
    }
  };

  const resetGame = () => {
    const shuffled = shufflePositions();
    setPieces(
      initialPieces.map((piece, i) => ({
        ...piece,
        currentPosition: shuffled[i],
        isPlaced: false,
      }))
    );
    setIsComplete(false);
    setShowCelebration(false);
  };

  return (
    <section className="relative py-24 lg:py-32 overflow-hidden" style={{ background: "linear-gradient(180deg, hsl(234 29% 8%) 0%, hsl(234 29% 12%) 50%, hsl(234 29% 8%) 100%)" }}>
      {/* Background glow */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          background: "radial-gradient(ellipse at center, hsl(210 100% 56% / 0.2), hsl(6 76% 55% / 0.1), transparent 60%)",
        }}
      />

      <div className="container-dxm relative z-10">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Cada peça <span className="text-autism-gradient">importa.</span>
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Monte o quebra-cabeça e descubra a mensagem.
          </p>
        </motion.div>

        {/* Game Area */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-col items-center justify-center"
        >
          <div 
            className="relative rounded-3xl p-8 md:p-12 border border-white/10"
            style={{
              background: "rgba(255, 255, 255, 0.03)",
              backdropFilter: "blur(20px)",
            }}
          >
            {/* Progress indicator */}
            <div className="flex items-center justify-center gap-3 mb-6">
              {pieces.map(piece => (
                <motion.div
                  key={`progress-${piece.id}`}
                  initial={{ scale: 0.8, opacity: 0.5 }}
                  animate={{ 
                    scale: piece.isPlaced ? 1 : 0.8, 
                    opacity: piece.isPlaced ? 1 : 0.5 
                  }}
                  className="flex items-center gap-1"
                >
                  <div 
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: colorMap[piece.color] }}
                  />
                  {piece.isPlaced && (
                    <CheckCircle2 size={12} className="text-white/60" />
                  )}
                </motion.div>
              ))}
              <span className="text-white/40 text-sm ml-2">
                {pieces.filter(p => p.isPlaced).length} de 4
              </span>
            </div>

            {/* Grid Area */}
            <div
              ref={gridRef}
              className="relative mx-auto"
              style={{
                width: pieceSize * 2 + gap,
                height: pieceSize * 2 + gap,
              }}
            >
              {/* Grid slots with silhouettes */}
              {[0, 1].map(row =>
                [0, 1].map(col => {
                  const pieceForSlot = Object.entries(pieceGridMap).find(
                    ([_, pos]) => pos.x === col && pos.y === row
                  );
                  const pieceId = pieceForSlot ? parseInt(pieceForSlot[0]) : 1;
                  const pieceData = initialPieces.find(p => p.id === pieceId);
                  const isSlotFilled = pieces.some(
                    p => p.isPlaced && p.targetPosition.x === col && p.targetPosition.y === row
                  );
                  
                  return (
                    <div
                      key={`slot-${row}-${col}`}
                      className="absolute rounded-lg overflow-hidden"
                      style={{
                        width: pieceSize,
                        height: pieceSize,
                        left: col * (pieceSize + gap),
                        top: row * (pieceSize + gap),
                      }}
                    >
                      {/* Silhouette of the piece that should go here */}
                      {!isSlotFilled && pieceData && (
                        <motion.svg
                          width={pieceSize}
                          height={pieceSize}
                          viewBox="0 0 80 80"
                          className="absolute inset-0"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 0.2 }}
                          transition={{ duration: 0.5 }}
                        >
                          <path
                            d={piecePaths[pieceId as keyof typeof piecePaths]}
                            fill={colorMap[pieceData.color]}
                          />
                        </motion.svg>
                      )}
                      {/* Dashed border */}
                      <div 
                        className="absolute inset-0 rounded-lg border-2 border-dashed"
                        style={{
                          borderColor: isSlotFilled ? 'transparent' : 'rgba(255,255,255,0.2)',
                        }}
                      />
                    </div>
                  );
                })
              )}

              {/* Draggable Pieces */}
              {pieces.map(piece => (
                <motion.div
                  key={piece.id}
                  drag={!piece.isPlaced}
                  dragMomentum={false}
                  dragElastic={0.1}
                  onDragEnd={(_, info) => handleDragEnd(piece.id, info)}
                  initial={false}
                  animate={{
                    x: piece.isPlaced
                      ? piece.targetPosition.x * (pieceSize + gap)
                      : piece.currentPosition.x,
                    y: piece.isPlaced
                      ? piece.targetPosition.y * (pieceSize + gap)
                      : piece.currentPosition.y,
                    scale: piece.isPlaced ? 1 : 0.95,
                  }}
                  whileDrag={{ scale: 1.1, zIndex: 50 }}
                  whileHover={!piece.isPlaced ? { scale: 1.08, y: piece.currentPosition.y - 5 } : {}}
                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                  className="absolute cursor-grab active:cursor-grabbing"
                  style={{
                    width: pieceSize,
                    height: pieceSize,
                    left: 0,
                    top: 0,
                    zIndex: piece.isPlaced ? 1 : 10,
                  }}
                  aria-label={`Peça ${piece.color} do quebra-cabeça`}
                  role="button"
                  tabIndex={0}
                >
                  {/* Floating animation for unplaced pieces */}
                  <motion.div
                    animate={!piece.isPlaced ? {
                      y: [0, -4, 0],
                    } : {}}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  >
                    <svg
                      width={pieceSize}
                      height={pieceSize}
                      viewBox="0 0 80 80"
                      className="drop-shadow-lg"
                      style={{ overflow: 'visible' }}
                    >
                      <defs>
                        <filter id={`glow-${piece.id}`} x="-50%" y="-50%" width="200%" height="200%">
                          <feGaussianBlur stdDeviation="4" result="blur" />
                          <feFlood floodColor={colorMap[piece.color]} floodOpacity="0.6" />
                          <feComposite in2="blur" operator="in" />
                          <feMerge>
                            <feMergeNode />
                            <feMergeNode in="SourceGraphic" />
                          </feMerge>
                        </filter>
                        <filter id={`shadow-${piece.id}`} x="-20%" y="-20%" width="140%" height="140%">
                          <feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="rgba(0,0,0,0.3)" />
                        </filter>
                      </defs>
                      <path
                        d={piecePaths[piece.id as keyof typeof piecePaths]}
                        fill={colorMap[piece.color]}
                        filter={piece.isPlaced ? `url(#glow-${piece.id})` : `url(#shadow-${piece.id})`}
                      />
                    </svg>
                  </motion.div>
                  
                  {/* Placed indicator glow with pulse */}
                  {piece.isPlaced && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ 
                        opacity: [0, 1, 0.8],
                        scale: [0.8, 1.1, 1],
                      }}
                      transition={{ duration: 0.4 }}
                      className="absolute inset-0 rounded-lg pointer-events-none"
                      style={{
                        boxShadow: `0 0 25px ${colorMap[piece.color]}`,
                      }}
                    />
                  )}
                </motion.div>
              ))}
            </div>

            {/* Celebration Overlay */}
            <AnimatePresence>
              {showCelebration && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center rounded-3xl z-50 overflow-hidden"
                  style={{
                    background: "rgba(19, 21, 32, 0.95)",
                    backdropFilter: "blur(10px)",
                  }}
                >
                  {/* Initial pulse explosion */}
                  <motion.div
                    initial={{ scale: 0, opacity: 0.8 }}
                    animate={{ scale: 3, opacity: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute w-20 h-20 rounded-full"
                    style={{
                      background: "radial-gradient(circle, rgba(255,255,255,0.4) 0%, transparent 70%)",
                    }}
                  />

                  {/* Falling stars from top */}
                  {[...Array(8)].map((_, i) => (
                    <motion.div
                      key={`star-${i}`}
                      initial={{ 
                        opacity: 0,
                        y: -50,
                        x: (i - 4) * 30,
                        rotate: 0,
                      }}
                      animate={{ 
                        opacity: [0, 1, 1, 0],
                        y: [-50, 100],
                        rotate: 360,
                      }}
                      transition={{ 
                        duration: 2,
                        delay: 0.1 + i * 0.1,
                        repeat: Infinity,
                        repeatDelay: 1.5,
                      }}
                      className="absolute top-0"
                      style={{
                        color: Object.values(colorMap)[i % 4],
                      }}
                    >
                      <Star size={12 + (i % 3) * 4} fill="currentColor" />
                    </motion.div>
                  ))}

                  {/* Expanded confetti sparkles - 24 particles */}
                  {[...Array(24)].map((_, i) => {
                    const angle = (i * 15) * Math.PI / 180;
                    const distance = 60 + (i % 3) * 30;
                    const size = 10 + (i % 4) * 5;
                    return (
                      <motion.div
                        key={`confetti-${i}`}
                        initial={{ 
                          opacity: 0, 
                          scale: 0,
                          x: 0,
                          y: 0,
                        }}
                        animate={{ 
                          opacity: [0, 0.9, 0],
                          scale: [0, 1.2, 0],
                          x: Math.cos(angle) * distance,
                          y: Math.sin(angle) * distance,
                        }}
                        transition={{ 
                          duration: 1.8, 
                          delay: 0.2 + (i * 0.03),
                          repeat: Infinity,
                          repeatDelay: 1.8,
                        }}
                        className="absolute"
                        style={{
                          color: Object.values(colorMap)[i % 4],
                        }}
                      >
                        <Sparkles size={size} />
                      </motion.div>
                    );
                  })}

                  {/* Glowing ring effect */}
                  <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: [0.5, 1.5, 1.5], opacity: [0, 0.5, 0] }}
                    transition={{ duration: 1.2, delay: 0.1 }}
                    className="absolute w-32 h-32 rounded-full border-4"
                    style={{
                      borderColor: colorMap.blue,
                      boxShadow: `0 0 30px ${colorMap.blue}`,
                    }}
                  />

                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.3, stiffness: 200 }}
                    className="text-center px-6 relative z-10"
                  >
                    {/* Bouncing emoji */}
                    <motion.span
                      initial={{ scale: 0, rotate: -20 }}
                      animate={{ scale: [0, 1.3, 1], rotate: [-20, 10, 0] }}
                      transition={{ duration: 0.6, delay: 0.4, type: "spring" }}
                      className="text-5xl md:text-6xl block mb-4"
                    >
                      🧩
                    </motion.span>
                    
                    <motion.h3 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                      className="text-2xl md:text-3xl font-bold text-white mb-3"
                    >
                      Perfeito!
                    </motion.h3>
                    
                    <motion.p 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.7 }}
                      className="text-white/60 text-sm md:text-base max-w-xs mx-auto mb-6"
                    >
                      Assim como cada peça tem seu lugar, cada pessoa no espectro autista é única e especial.
                    </motion.p>
                    
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.9 }}
                    >
                      <Button
                        onClick={resetGame}
                        variant="outline"
                        className="gap-2 border-white/20 text-white hover:bg-white/10"
                      >
                        <RotateCcw size={16} />
                        Jogar novamente
                      </Button>
                    </motion.div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Reset Button (when not complete) */}
            {!isComplete && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-8 text-center"
              >
                <Button
                  onClick={resetGame}
                  variant="ghost"
                  size="sm"
                  className="gap-2 text-white/40 hover:text-white/60 hover:bg-white/5"
                >
                  <RotateCcw size={14} />
                  Embaralhar
                </Button>
              </motion.div>
            )}
          </div>

          {/* Instructions Card */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="mt-8 flex items-center justify-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10"
          >
            <Move size={20} className="text-white/40" />
            <div className="text-left">
              <p className="text-white/60 text-sm font-medium">
                Arraste cada peça colorida para sua posição
              </p>
              <p className="text-white/30 text-xs">
                As silhuetas indicam onde cada cor deve ir
              </p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};
