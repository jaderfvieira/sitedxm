import { useState } from "react";
import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";

interface FlipCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  backContent: string;
  color: "blue" | "red" | "yellow" | "green";
  delay?: number;
}

const colorClasses = {
  blue: {
    border: "border-t-[hsl(210,100%,56%)]",
    bg: "bg-[hsl(210,100%,56%)]",
    glow: "shadow-[0_0_30px_-5px_hsl(210,100%,56%,0.5)]",
    gradient: "from-[hsl(210,100%,56%)] to-[hsl(210,100%,40%)]",
  },
  red: {
    border: "border-t-[hsl(6,76%,55%)]",
    bg: "bg-[hsl(6,76%,55%)]",
    glow: "shadow-[0_0_30px_-5px_hsl(6,76%,55%,0.5)]",
    gradient: "from-[hsl(6,76%,55%)] to-[hsl(6,76%,40%)]",
  },
  yellow: {
    border: "border-t-[hsl(50,97%,60%)]",
    bg: "bg-[hsl(50,97%,60%)]",
    glow: "shadow-[0_0_30px_-5px_hsl(50,97%,60%,0.5)]",
    gradient: "from-[hsl(50,97%,60%)] to-[hsl(50,97%,45%)]",
  },
  green: {
    border: "border-t-[hsl(122,39%,49%)]",
    bg: "bg-[hsl(122,39%,49%)]",
    glow: "shadow-[0_0_30px_-5px_hsl(122,39%,49%,0.5)]",
    gradient: "from-[hsl(122,39%,49%)] to-[hsl(122,39%,35%)]",
  },
};

export const FlipCard = ({
  icon: Icon,
  title,
  description,
  backContent,
  color,
  delay = 0,
}: FlipCardProps) => {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleToggle = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true }}
      transition={{ 
        duration: 0.6, 
        delay,
        type: "spring",
        stiffness: 100,
      }}
      className="h-48 lg:h-64 perspective-1000 cursor-pointer"
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
      onClick={handleToggle}
    >
      <motion.div
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 100 }}
        className="relative w-full h-full"
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Front */}
        <div 
          className={`absolute inset-0 bg-muted rounded-2xl p-4 lg:p-6 transition-shadow duration-300 border-t-4 ${colorClasses[color].border} ${isFlipped ? '' : colorClasses[color].glow} hover:translate-y-[-2px]`}
          style={{ backfaceVisibility: "hidden" }}
        >
          <motion.div 
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className={`w-10 h-10 lg:w-12 lg:h-12 rounded-xl lg:rounded-2xl flex items-center justify-center mb-3 lg:mb-4 ${colorClasses[color].bg}`}
          >
            <Icon size={18} className="text-white lg:hidden" />
            <Icon size={22} className="text-white hidden lg:block" />
          </motion.div>
          <h3 className="font-semibold text-foreground text-base lg:text-lg mb-1 lg:mb-2">
            {title}
          </h3>
          <p className="text-muted-foreground text-xs lg:text-sm leading-relaxed line-clamp-3 lg:line-clamp-none">
            {description}
          </p>
          
          {/* Animated border trace */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ borderRadius: "1rem" }}>
            <rect
              x="2"
              y="2"
              width="calc(100% - 4px)"
              height="calc(100% - 4px)"
              rx="14"
              ry="14"
              fill="none"
              stroke="url(#border-gradient)"
              strokeWidth="2"
              strokeDasharray="400"
              strokeDashoffset={isFlipped ? 0 : 400}
              style={{ transition: "stroke-dashoffset 1s ease-in-out" }}
            />
            <defs>
              <linearGradient id="border-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="hsl(210 100% 56%)" />
                <stop offset="33%" stopColor="hsl(6 76% 55%)" />
                <stop offset="66%" stopColor="hsl(50 97% 60%)" />
                <stop offset="100%" stopColor="hsl(122 39% 49%)" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Back */}
        <div 
          className={`absolute inset-0 rounded-2xl p-4 lg:p-6 flex items-center justify-center text-center bg-gradient-to-br ${colorClasses[color].gradient}`}
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <div>
            <Icon size={24} className="text-white/80 mx-auto mb-3 lg:hidden" />
            <Icon size={32} className="text-white/80 mx-auto mb-4 hidden lg:block" />
            <p className="text-white text-xs lg:text-sm leading-relaxed font-medium">
              {backContent}
            </p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
