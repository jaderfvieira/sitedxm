import { useMemo } from "react";
import { motion } from "framer-motion";
import { useIsMobile } from "@/hooks/use-mobile";

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  color: string;
}

const colors = [
  "hsl(210 100% 56%)", // blue
  "hsl(6 76% 55%)",    // red
  "hsl(50 97% 60%)",   // yellow
  "hsl(122 39% 49%)",  // green
  "hsl(0 0% 100%)",    // white
  "hsl(0 0% 100%)",    // white (more white particles)
];

export const ParticleField = ({ 
  count = 40,
  className = "" 
}: { 
  count?: number;
  className?: string;
}) => {
  const isMobile = useIsMobile();
  const particleCount = isMobile ? Math.floor(count / 2) : count;
  
  const particles = useMemo<Particle[]>(() => {
    return Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 2, // 2-4px
      duration: Math.random() * 10 + 10, // 10-20s
      delay: Math.random() * 5,
      color: colors[Math.floor(Math.random() * colors.length)],
    }));
  }, [particleCount]);

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute rounded-full"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: particle.size,
            height: particle.size,
            backgroundColor: particle.color,
          }}
          animate={{
            x: [0, Math.random() * 15 - 7.5, Math.random() * 10 - 5, 0],
            y: [0, Math.random() * 15 - 7.5, Math.random() * 10 - 5, 0],
            opacity: [0.2, 0.5, 0.3, 0.2],
            scale: [1, 1.2, 0.9, 1],
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            delay: particle.delay,
            ease: "linear",
          }}
        />
      ))}
    </div>
  );
};
