import { motion, useMotionValue, useTransform, useSpring } from "framer-motion";
import { useEffect, useState } from "react";

interface MouseFollowPuzzleProps {
  color: "blue" | "red" | "yellow" | "green";
  size?: number;
  className?: string;
  intensity?: number;
}

const colorMap = {
  blue: "hsl(210 100% 56%)",
  red: "hsl(6 76% 55%)",
  yellow: "hsl(50 97% 60%)",
  green: "hsl(122 39% 49%)",
};

export const MouseFollowPuzzle = ({ 
  color, 
  size = 60, 
  className = "",
  intensity = 1
}: MouseFollowPuzzleProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  // Mouse position
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  // Smooth spring animation
  const springConfig = { damping: 25, stiffness: 150 };
  const x = useSpring(useTransform(mouseX, (v) => v * 0.02 * intensity), springConfig);
  const y = useSpring(useTransform(mouseY, (v) => v * 0.02 * intensity), springConfig);
  
  // 3D rotation based on mouse
  const rotateX = useSpring(useTransform(mouseY, [-500, 500], [10, -10]), springConfig);
  const rotateY = useSpring(useTransform(mouseX, [-500, 500], [-10, 10]), springConfig);
  
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      mouseX.set(e.clientX - centerX);
      mouseY.set(e.clientY - centerY);
    };
    
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <motion.svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={`cursor-pointer ${className}`}
      style={{ 
        x, 
        y,
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
        perspective: 1000,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      animate={{
        scale: isHovered ? 1.2 : 1,
        opacity: isHovered ? 0.4 : 0.15,
        filter: isHovered ? `drop-shadow(0 0 20px ${colorMap[color]})` : "none",
      }}
      transition={{ duration: 0.3 }}
    >
      <path
        d="M25,0 L25,20 C25,20 15,20 15,30 C15,40 25,40 25,40 L25,60 C25,60 15,60 15,70 C15,80 25,80 25,80 L25,100 L45,100 C45,100 45,90 55,90 C65,90 65,100 65,100 L85,100 L85,80 C85,80 75,80 75,70 C75,60 85,60 85,60 L85,40 C85,40 75,40 75,30 C75,20 85,20 85,20 L85,0 L65,0 C65,0 65,10 55,10 C45,10 45,0 45,0 L25,0"
        fill={colorMap[color]}
        fillOpacity="1"
      />
    </motion.svg>
  );
};
