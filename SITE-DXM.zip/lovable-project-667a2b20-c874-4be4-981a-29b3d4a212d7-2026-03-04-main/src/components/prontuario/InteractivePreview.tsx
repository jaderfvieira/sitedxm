import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

interface Hotspot {
  id: string;
  x: number;
  y: number;
  title: string;
  description: string;
  color: "blue" | "red" | "yellow" | "green";
}

interface PreviewTab {
  id: string;
  label: string;
  image: string;
  hotspots: Hotspot[];
}

interface InteractivePreviewProps {
  tabs: PreviewTab[];
}

const colorClasses = {
  blue: "bg-[hsl(210,100%,56%)]",
  red: "bg-[hsl(6,76%,55%)]",
  yellow: "bg-[hsl(50,97%,60%)]",
  green: "bg-[hsl(122,39%,49%)]",
};

export const InteractivePreview = ({ tabs }: InteractivePreviewProps) => {
  const [activeTab, setActiveTab] = useState(tabs[0]?.id || "");
  const [zoomedHotspot, setZoomedHotspot] = useState<Hotspot | null>(null);
  const currentTab = tabs.find(t => t.id === activeTab);

  return (
    <div className="relative">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        {/* Tab navigation */}
        <TabsList className="mx-auto mb-6 lg:mb-8 bg-white/5 border border-white/10 backdrop-blur-md p-1 rounded-xl lg:rounded-2xl flex-wrap justify-center">
          {tabs.map((tab, index) => (
            <TabsTrigger 
              key={tab.id} 
              value={tab.id}
              className="relative px-3 py-2 lg:px-6 lg:py-3 text-xs lg:text-sm text-white/60 data-[state=active]:text-white data-[state=active]:bg-transparent rounded-lg lg:rounded-xl transition-all"
            >
              {tab.label}
              {/* Animated underline */}
              {activeTab === tab.id && (
                <motion.div
                  layoutId="tab-indicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 autism-gradient-animated rounded-full"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Tab content */}
        {tabs.map((tab) => (
          <TabsContent key={tab.id} value={tab.id} className="mt-0">
            <AnimatePresence mode="wait">
              <motion.div
                key={tab.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3 }}
                className="relative"
              >
                {/* Glow behind */}
                <div className="absolute -inset-8 rounded-3xl opacity-40 blur-3xl"
                  style={{
                    background: "radial-gradient(ellipse at center, hsl(210 100% 56% / 0.3), hsl(6 76% 55% / 0.2), transparent 70%)",
                  }}
                />
                
                {/* Main screenshot */}
                <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/10">
                  <img 
                    src={tab.image} 
                    alt={tab.label} 
                    className="w-full h-auto"
                  />
                  
                  {/* Hotspots */}
                  {tab.hotspots.map((hotspot, idx) => (
                    <motion.div
                      key={hotspot.id}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5 + idx * 0.1 }}
                      className="absolute hidden lg:block cursor-pointer"
                      style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
                      onClick={() => setZoomedHotspot(hotspot)}
                    >
                      <div className="relative group">
                        <motion.div 
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 2, repeat: Infinity }}
                          className={`w-5 h-5 rounded-full border-2 border-white shadow-lg ${colorClasses[hotspot.color]}`}
                        />
                        {/* Pulse ring */}
                        <motion.div 
                          animate={{ scale: [1, 2.5], opacity: [0.6, 0] }}
                          transition={{ duration: 2, repeat: Infinity }}
                          className={`absolute inset-0 rounded-full border border-white/50 ${colorClasses[hotspot.color]}`}
                        />
                        
                        {/* Tooltip */}
                        <div className="absolute left-6 top-1/2 -translate-y-1/2 bg-white rounded-xl px-4 py-2 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20">
                          <p className="text-sm font-medium text-foreground">{hotspot.title}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Mobile Hotspot List */}
                {tab.hotspots.length > 0 && (
                  <div className="lg:hidden mt-4 space-y-2">
                    {tab.hotspots.map((hotspot) => (
                      <button
                        key={hotspot.id}
                        onClick={() => setZoomedHotspot(hotspot)}
                        className={`w-full text-left p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3`}
                      >
                        <div className={`w-3 h-3 rounded-full ${colorClasses[hotspot.color]}`} />
                        <span className="text-white text-sm">{hotspot.title}</span>
                      </button>
                    ))}
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </TabsContent>
        ))}
      </Tabs>

      {/* Zoom Modal */}
      <AnimatePresence>
        {zoomedHotspot && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setZoomedHotspot(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              transition={{ type: "spring", damping: 20 }}
              className="relative bg-white rounded-2xl lg:rounded-3xl p-5 lg:p-8 max-w-lg w-full mx-4"
              onClick={(e) => e.stopPropagation()}
            >
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setZoomedHotspot(null)}
                className="absolute top-4 right-4 w-10 h-10 rounded-full bg-muted flex items-center justify-center"
              >
                <X size={20} />
              </motion.button>
              
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 ${colorClasses[zoomedHotspot.color]}`}>
                <div className="w-4 h-4 bg-white rounded-full" />
              </div>
              
              <h3 className="text-2xl font-semibold text-foreground mb-4">
                {zoomedHotspot.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {zoomedHotspot.description}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
