import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "react-router-dom";
import hexagonCyan from "@/assets/totvs/hexagon-cyan.png";

interface PageTransitionProps {
  children: React.ReactNode;
}

export const PageTransition = ({ children }: PageTransitionProps) => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <motion.div key={location.pathname} className="relative">
        {/* Backdrop Blur Overlay - appears during transition */}
        <motion.div
          className="fixed inset-0 z-[99] pointer-events-none bg-black/5 backdrop-blur-[4px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 1, 0] }}
          transition={{ 
            duration: 1.0,
            times: [0, 0.2, 0.7, 1],
            ease: "easeInOut"
          }}
        />

        {/* Cyan Hexagon Transition Overlay - spinning logo */}
        <motion.div
          className="fixed inset-0 z-[100] pointer-events-none flex items-center justify-center"
          initial={{ opacity: 1 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 1 }}
        >
          <motion.div
            className="relative"
            initial={{ scale: 0, rotate: 0, opacity: 0 }}
            animate={{ 
              scale: [0, 1.2, 1.5, 1.8, 1.5, 0],
              rotate: 360,
              opacity: [0, 0.4, 0.35, 0.3, 0.2, 0]
            }}
            transition={{ 
              duration: 1.0, 
              ease: "easeInOut",
              times: [0, 0.2, 0.4, 0.6, 0.8, 1]
            }}
          >
            {/* Glow effect behind hexagon */}
            <div 
              className="absolute inset-0 blur-2xl bg-dxm-orange/20 rounded-full scale-150"
              style={{ zIndex: -1 }}
            />
            <motion.img
              src={hexagonCyan}
              alt=""
              className="w-[200px] h-[200px] object-contain drop-shadow-2xl"
            />
          </motion.div>
        </motion.div>

        {/* Page Content - starts visible, crossfades */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ 
            duration: 0.4, 
            delay: 0.3,
            ease: "easeOut"
          }}
        >
          {children}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
