import { motion, useMotionValue, useTransform, useSpring, useScroll } from "framer-motion";
import { useEffect, useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

// Import assets
import hexagonCyan from "@/assets/totvs/hexagon-cyan.png";
import hexagonPetrol from "@/assets/totvs/hexagon-petrol.png";
import hexagonPartial from "@/assets/totvs/hexagon-partial.png";
import diagonalLines from "@/assets/totvs/diagonal-lines.png";
import diagonalLinesOrange from "@/assets/totvs/diagonal-lines-orange.png";

type Variant = "hexagon-cyan" | "hexagon-petrol" | "hexagon-partial" | "diagonal-lines" | "diagonal-lines-orange";
type Animation = "float" | "rotate" | "parallax" | "mouse-follow" | "pulse" | "glow" | "scale";

interface FloatingShapeProps {
  variant: Variant;
  size?: number;
  position?: {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
  };
  animation?: Animation | Animation[];
  opacity?: number;
  delay?: number;
  className?: string;
  hideOnMobile?: boolean;
}

const variantMap: Record<Variant, string> = {
  "hexagon-cyan": hexagonCyan,
  "hexagon-petrol": hexagonPetrol,
  "hexagon-partial": hexagonPartial,
  "diagonal-lines": diagonalLines,
  "diagonal-lines-orange": diagonalLinesOrange,
};

export const FloatingShape = ({
  variant,
  size = 200,
  position = {},
  animation = "float",
  opacity = 0.1,
  delay = 0,
  className = "",
  hideOnMobile = true,
}: FloatingShapeProps) => {
  const isMobile = useIsMobile();
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  
  // Check for reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handler);
    return () => mediaQuery.removeEventListener("change", handler);
  }, []);

  // Mouse position for mouse-follow animation
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  // Smooth spring animation for mouse follow
  const springConfig = { damping: 50, stiffness: 100 };
  const x = useSpring(useTransform(mouseX, (v) => v * 0.03), springConfig);
  const y = useSpring(useTransform(mouseY, (v) => v * 0.03), springConfig);
  
  // Scroll position for parallax
  const { scrollY } = useScroll();
  const parallaxY = useTransform(scrollY, [0, 1000], [0, -100]);
  const smoothParallaxY = useSpring(parallaxY, { damping: 30, stiffness: 100 });

  // Track mouse position
  useEffect(() => {
    const animations = Array.isArray(animation) ? animation : [animation];
    if (!animations.includes("mouse-follow")) return;
    
    const handleMouseMove = (e: MouseEvent) => {
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      mouseX.set(e.clientX - centerX);
      mouseY.set(e.clientY - centerY);
    };
    
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [animation, mouseX, mouseY]);

  // Hide on mobile if configured
  if (hideOnMobile && isMobile) {
    return null;
  }

  // Disable animations if reduced motion is preferred
  if (prefersReducedMotion) {
    return (
      <div
        className={`absolute pointer-events-none ${className}`}
        style={{
          ...position,
          width: size,
          height: size,
          opacity,
        }}
      >
        <img
          src={variantMap[variant]}
          alt=""
          className="w-full h-full object-contain"
          loading="lazy"
        />
      </div>
    );
  }

  const animations = Array.isArray(animation) ? animation : [animation];
  
  // Build animation props
  const floatAnimation = animations.includes("float") ? {
    y: [-8, 8, -8],
  } : {};
  
  const rotateAnimation = animations.includes("rotate") ? {
    rotate: [-3, 3, -3],
  } : {};

  const pulseAnimation = animations.includes("pulse") ? {
    scale: [1, 1.08, 1],
  } : {};

  const glowAnimation = animations.includes("glow") ? {
    opacity: [opacity, opacity * 1.4, opacity],
  } : {};

  const transition = {
    duration: animations.includes("rotate") ? 12 : animations.includes("pulse") ? 3 : 5,
    repeat: Infinity,
    ease: "easeInOut" as const,
    delay,
  };

  // Determine which motion values to use
  const motionStyle: Record<string, unknown> = {
    willChange: "transform",
  };
  
  if (animations.includes("mouse-follow")) {
    motionStyle.x = x;
    motionStyle.y = y;
  }
  
  if (animations.includes("parallax")) {
    motionStyle.y = smoothParallaxY;
  }

  const scaleInitial = animations.includes("scale") ? { scale: 0.8, opacity: 0 } : {};
  
  return (
    <motion.div
      className={`absolute pointer-events-none ${className}`}
      style={{
        ...position,
        width: size,
        height: size,
        opacity: animations.includes("glow") ? undefined : opacity,
        ...motionStyle,
      }}
      initial={scaleInitial}
      animate={{
        ...floatAnimation,
        ...rotateAnimation,
        ...pulseAnimation,
        ...glowAnimation,
        ...(animations.includes("scale") ? { scale: 1, opacity } : {}),
      }}
      transition={transition}
    >
      <img
        src={variantMap[variant]}
        alt=""
        className="w-full h-full object-contain"
        loading="lazy"
      />
    </motion.div>
  );
};
