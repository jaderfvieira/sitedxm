import { motion, useScroll, useTransform, useSpring, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import diagonalLinesOrange from "@/assets/totvs/diagonal-lines-orange.png";

type Animation = "slide-in" | "parallax" | "glow" | "stagger";
type Direction = "top-left" | "top-right" | "bottom-left" | "bottom-right";

interface FloatingDiagonalLinesProps {
  size?: number;
  position?: {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
  };
  animation?: Animation | Animation[];
  opacity?: number;
  delay?: number;
  direction?: Direction;
  className?: string;
  hideOnMobile?: boolean;
}

export const FloatingDiagonalLines = ({
  size = 300,
  position = {},
  animation = "parallax",
  opacity = 0.12,
  delay = 0,
  direction = "bottom-left",
  className = "",
  hideOnMobile = true,
}: FloatingDiagonalLinesProps) => {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const isInView = useInView(ref, { once: false, margin: "-10%" });
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Check for reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handler);
    return () => mediaQuery.removeEventListener("change", handler);
  }, []);

  // Scroll-based parallax
  const { scrollY } = useScroll();
  const parallaxY = useTransform(scrollY, [0, 1000], [0, -100]);
  const parallaxRotate = useTransform(scrollY, [0, 1000], [0, 5]);
  const smoothParallaxY = useSpring(parallaxY, { damping: 30, stiffness: 100 });
  const smoothRotate = useSpring(parallaxRotate, { damping: 30, stiffness: 100 });

  // Hide on mobile if configured
  if (hideOnMobile && isMobile) {
    return null;
  }

  const animations = Array.isArray(animation) ? animation : [animation];
  const hasParallax = animations.includes("parallax");
  const hasSlideIn = animations.includes("slide-in");
  const hasGlow = animations.includes("glow");

  // Calculate slide-in direction
  const getSlideInOffset = () => {
    switch (direction) {
      case "top-left":
        return { x: -100, y: -100 };
      case "top-right":
        return { x: 100, y: -100 };
      case "bottom-left":
        return { x: -100, y: 100 };
      case "bottom-right":
        return { x: 100, y: 100 };
      default:
        return { x: -100, y: 100 };
    }
  };

  const slideOffset = getSlideInOffset();

  // Static render for reduced motion
  if (prefersReducedMotion) {
    return (
      <div
        ref={ref}
        className={`absolute pointer-events-none ${className}`}
        style={{
          ...position,
          width: size,
          height: size,
          opacity,
        }}
      >
        <img
          src={diagonalLinesOrange}
          alt=""
          className="w-full h-full object-contain"
          loading="lazy"
        />
      </div>
    );
  }

  // Motion style for parallax
  const motionStyle: Record<string, unknown> = {
    willChange: "transform",
  };

  if (hasParallax) {
    motionStyle.y = smoothParallaxY;
    motionStyle.rotate = smoothRotate;
  }

  // Glow animation
  const glowAnimation = hasGlow
    ? {
        opacity: [opacity, opacity * 1.5, opacity],
      }
    : {};

  const glowTransition = hasGlow
    ? {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut" as const,
      }
    : {};

  return (
    <motion.div
      ref={ref}
      className={`absolute pointer-events-none ${className}`}
      style={{
        ...position,
        width: size,
        height: size,
        opacity: hasGlow ? undefined : opacity,
        ...motionStyle,
      }}
      initial={
        hasSlideIn
          ? { opacity: 0, x: slideOffset.x, y: slideOffset.y }
          : { opacity: 0 }
      }
      animate={
        isInView
          ? {
              opacity: hasGlow ? undefined : opacity,
              x: 0,
              y: hasParallax ? undefined : 0,
              ...glowAnimation,
            }
          : {}
      }
      transition={{
        duration: 0.8,
        delay,
        ease: "easeOut",
        ...glowTransition,
      }}
    >
      <img
        src={diagonalLinesOrange}
        alt=""
        className="w-full h-full object-contain"
        loading="lazy"
      />
    </motion.div>
  );
};
