import { motion, AnimatePresence } from "framer-motion";
import { Bot } from "lucide-react";
import { useState, useEffect } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

interface JadersonAvatarProps {
  onClick: () => void;
  isOpen: boolean;
}

const speechBubbleMessages = [
  "Posso ajudar?",
  "Dúvidas sobre ABA?",
  "Olá! 👋",
];

export const JadersonAvatar = ({ onClick, isOpen }: JadersonAvatarProps) => {
  const [showBubble, setShowBubble] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);
  const [isWaving, setIsWaving] = useState(false);
  const [isBouncing, setIsBouncing] = useState(false);
  const isMobile = useIsMobile();

  // Speech bubble cycle: show 3s, hide 12s
  useEffect(() => {
    if (isOpen) return;
    
    const showInterval = setInterval(() => {
      setShowBubble(true);
      setMessageIndex((prev) => (prev + 1) % speechBubbleMessages.length);
      
      setTimeout(() => {
        setShowBubble(false);
      }, 3000);
    }, 15000);

    // Initial show after 2s
    const initialTimeout = setTimeout(() => {
      setShowBubble(true);
      setTimeout(() => setShowBubble(false), 3000);
    }, 2000);

    return () => {
      clearInterval(showInterval);
      clearTimeout(initialTimeout);
    };
  }, [isOpen]);

  // Wave animation: every 6 seconds
  useEffect(() => {
    if (isOpen) return;
    
    const waveInterval = setInterval(() => {
      setIsWaving(true);
      setTimeout(() => setIsWaving(false), 600);
    }, 6000);

    // Initial wave after 1s
    const initialWave = setTimeout(() => {
      setIsWaving(true);
      setTimeout(() => setIsWaving(false), 600);
    }, 1000);

    return () => {
      clearInterval(waveInterval);
      clearTimeout(initialWave);
    };
  }, [isOpen]);

  // Bounce animation: every 8 seconds
  useEffect(() => {
    if (isOpen) return;
    
    const bounceInterval = setInterval(() => {
      setIsBouncing(true);
      setTimeout(() => setIsBouncing(false), 800);
    }, 8000);

    return () => clearInterval(bounceInterval);
  }, [isOpen]);

  return (
    <motion.div
      className="fixed bottom-28 right-4 z-40"
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: isOpen ? 0 : 1, 
        y: isOpen ? 20 : (isBouncing ? [-8, 0, -4, 0] : 0),
        pointerEvents: isOpen ? "none" : "auto" 
      }}
      transition={{ duration: 0.2 }}
    >
      {/* Speech Bubble */}
      <AnimatePresence>
        {showBubble && !isOpen && (
          <motion.div
            className={`absolute ${isMobile ? '-top-14 left-1/2 -translate-x-1/2' : 'right-20 top-1/2 -translate-y-1/2'} bg-white rounded-2xl px-4 py-2 shadow-lg whitespace-nowrap`}
            initial={{ opacity: 0, scale: 0.8, x: isMobile ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.8, x: isMobile ? 0 : 10 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            <span className="text-sm font-medium text-[#131520]">
              {speechBubbleMessages[messageIndex]}
            </span>
            {/* Bubble tail */}
            <div 
              className={`absolute ${isMobile ? '-bottom-2 left-1/2 -translate-x-1/2 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-white' : '-right-2 top-1/2 -translate-y-1/2 border-t-8 border-b-8 border-l-8 border-t-transparent border-b-transparent border-l-white'}`}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={onClick}
        className="group relative"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* Enhanced outer glow */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: "conic-gradient(from 0deg, #FFDD00, #EF4136, #00A5E0, #8BC53F, #FFDD00)",
            filter: "blur(12px)",
          }}
          animate={{
            rotate: 360,
            scale: [1, 1.3, 1],
            opacity: [0.6, 0.9, 0.6],
          }}
          transition={{
            rotate: { duration: 8, repeat: Infinity, ease: "linear" },
            scale: { duration: 2, repeat: Infinity, ease: "easeInOut" },
            opacity: { duration: 2, repeat: Infinity, ease: "easeInOut" },
          }}
        />

        {/* Main button */}
        <div 
          className={`relative ${isMobile ? 'w-[56px] h-[56px]' : 'w-[60px] h-[60px]'} rounded-full p-[3px]`}
          style={{
            background: "conic-gradient(from 0deg, #FFDD00, #EF4136, #00A5E0, #8BC53F, #FFDD00)",
          }}
        >
          <div className="w-full h-full rounded-full bg-[#131520] flex items-center justify-center relative overflow-hidden">
            {/* Enhanced pulse animation */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: "radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%)",
              }}
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.4, 0, 0.4],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
            
            {/* Waving Icon */}
            <motion.div
              animate={isWaving ? {
                rotate: [0, -15, 15, -10, 10, 0],
              } : {}}
              transition={{ duration: 0.6, ease: "easeInOut" }}
            >
              <Bot size={isMobile ? 24 : 26} className="text-white relative z-10" />
            </motion.div>
          </div>
        </div>

        {/* Online badge */}
        <div className="absolute -top-1 -right-1 flex items-center gap-1 bg-[#131520] rounded-full px-2 py-0.5 border border-green-500/50">
          <motion.div 
            className="w-2 h-2 bg-green-500 rounded-full"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [1, 0.7, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <span className="text-[10px] text-white font-medium">Online</span>
        </div>

        {/* Name label on hover */}
        <motion.div
          className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-[#131520]/90 backdrop-blur-sm rounded-full px-3 py-1 border border-white/10 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <span className="text-xs text-white font-medium">Jaderson</span>
        </motion.div>
      </motion.button>
    </motion.div>
  );
};
