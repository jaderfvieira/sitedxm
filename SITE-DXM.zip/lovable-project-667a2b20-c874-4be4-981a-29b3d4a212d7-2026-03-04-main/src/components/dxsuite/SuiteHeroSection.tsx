import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles, ChevronDown } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import logoDxmLight from "@/assets/logo-dxm-light.png";
import logoDxSymbol from "@/assets/dx-logo.png";

const DxmLogo = ({ height = 28, className = "" }: { height?: number; className?: string }) => (
  <img
    src={logoDxSymbol}
    alt="DX"
    style={{ height: `${height}px` }}
    className={`inline-block align-middle ${className}`}
    draggable={false}
  />
);

// DX SUITE Products
const products = [
  {
    id: "saude",
    suffix: "Saúde",
    subtitle: "Prontuário ABA",
    description:
      "Prontuário especializado em atendimento a pacientes com TEA e suas particularidades. Também contempla prestadores de serviços continuados (Fonoaudiologia, Nutrição, etc).",
    link: "/prontuario",
  },
  {
    id: "paineis",
    suffix: "Painéis",
    subtitle: "Hospitalares",
    description:
      "Painéis hospitalares personalizados para visualização em tempo real de indicadores e métricas críticas.",
    link: "/contato?produto=paineis",
  },
  {
    id: "ilpi",
    suffix: "Saúde LP",
    subtitle: "Longa Permanência",
    description: "Prontuário especializado em gestão de pacientes em Instituições de Longa Permanência.",
    link: "/contato?produto=ilpi",
  },
  {
    id: "callcenter",
    suffix: "Call Center",
    subtitle: "Call Center Saúde",
    description:
      "Módulo Call Center especializado em atendimento da RN 623 para Operadoras. Integrado com URAs e ferramentas de chat de conversas.",
    link: "/contato?produto=callcenter",
  },
  {
    id: "beneficios",
    suffix: "Benefícios",
    subtitle: "ADM de Benefícios",
    description:
      "Módulo de Administradora de Benefícios para gestão completa e informatizada do seu processo. Controle beneficiários, valor net, valor over e todo background da sua operação.",
    link: "/contato?produto=beneficios",
  },
  {
    id: "credenciamento",
    suffix: "Credenciamento",
    subtitle: "Portal de Credenciamento",
    description:
      "Portal de credenciamento de prestadores para operadoras. Auxiliando a sua operadora a credenciar de forma mais rápida e prática os seus prestadores.",
    link: "/contato?produto=credenciamento",
  },
];

const ProductName = ({ suffix, height = 28 }: { suffix: string; height?: number }) => (
  <span className="inline-flex items-center gap-0">
    <DxmLogo height={height} />
    <span>{suffix}</span>
  </span>
);

// Animated particles component
const FloatingParticles = ({ count }: { count: number }) => (
  <>
    {[...Array(count)].map((_, i) => (
      <motion.div
        key={i}
        className="absolute rounded-full bg-white/20"
        style={{
          width: Math.random() * 4 + 2,
          height: Math.random() * 4 + 2,
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`,
        }}
        animate={{
          y: [0, Math.random() * -100 - 50],
          x: [0, Math.random() * 40 - 20],
          opacity: [0, 0.6, 0],
        }}
        transition={{
          duration: Math.random() * 8 + 6,
          repeat: Infinity,
          delay: Math.random() * 5,
          ease: "easeInOut",
        }}
      />
    ))}
  </>
);

// Network pattern dots
const NetworkPattern = () => (
  <svg className="absolute inset-0 w-full h-full opacity-[0.03]" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <pattern id="network-dots" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
        <circle cx="2" cy="2" r="1" fill="white" />
      </pattern>
    </defs>
    <rect width="100%" height="100%" fill="url(#network-dots)" />
  </svg>
);

// Pulsing gradient orbs
const GradientOrbs = () => (
  <>
    <motion.div
      className="absolute top-20 left-10 w-[400px] h-[400px] rounded-full pointer-events-none"
      style={{
        background: "radial-gradient(circle, hsl(211 100% 45% / 0.15) 0%, transparent 70%)",
        filter: "blur(60px)",
      }}
      animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
      transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
    />
    <motion.div
      className="absolute top-1/3 right-0 w-[350px] h-[350px] rounded-full pointer-events-none"
      style={{
        background: "radial-gradient(circle, hsl(265 83% 57% / 0.12) 0%, transparent 70%)",
        filter: "blur(50px)",
      }}
      animate={{ scale: [1.1, 0.9, 1.1], opacity: [0.4, 0.7, 0.4] }}
      transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 2 }}
    />
    <motion.div
      className="absolute bottom-20 left-1/3 w-[300px] h-[300px] rounded-full pointer-events-none"
      style={{
        background: "radial-gradient(circle, hsl(28 92% 54% / 0.1) 0%, transparent 70%)",
        filter: "blur(40px)",
      }}
      animate={{ scale: [0.9, 1.15, 0.9], opacity: [0.3, 0.6, 0.3] }}
      transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
    />
  </>
);

// 3D Card component
const ProductCard = ({ product, isActive }: { product: (typeof products)[0]; isActive: boolean }) => (
  <motion.div
    key={product.id}
    initial={{ rotateY: 90, opacity: 0 }}
    animate={{ rotateY: 0, opacity: 1 }}
    exit={{ rotateY: -90, opacity: 0 }}
    transition={{ duration: 0.6, ease: "easeOut" }}
    className="absolute inset-0 flex items-center justify-center"
    style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
  >
    <div
      className="relative w-full max-w-[300px] sm:max-w-md p-5 sm:p-8 rounded-3xl overflow-hidden"
      style={{
        background: "linear-gradient(135deg, hsl(0 0% 100% / 0.08) 0%, hsl(0 0% 100% / 0.03) 100%)",
        backdropFilter: "blur(24px)",
        WebkitBackdropFilter: "blur(24px)",
        border: "1px solid hsl(0 0% 100% / 0.15)",
        boxShadow: "0 25px 50px -12px hsl(0 0% 0% / 0.5), 0 0 0 1px hsl(0 0% 100% / 0.05) inset",
      }}
    >
      <div
        className="absolute inset-0 rounded-3xl pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 50% 0%, hsl(211 100% 45% / 0.15) 0%, transparent 50%)",
        }}
      />

      <div className="flex items-start gap-4 mb-6 relative z-10">
        <div
          className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center shrink-0"
          style={{
            background: "linear-gradient(135deg, hsl(195 65% 30%) 0%, hsl(195 65% 35%) 100%)",
            boxShadow: "0 8px 20px -4px hsl(195 65% 30% / 0.4)",
          }}
        >
          <DxmLogo height={36} />
        </div>
        <div className="pt-1">
          <h3 className="text-xl sm:text-2xl font-semibold text-white mb-1">{product.suffix}</h3>
          <p className="text-white/50 text-sm">{product.subtitle}</p>
        </div>
      </div>

      <p className="text-white/60 text-sm sm:text-base leading-relaxed mb-6 sm:mb-8 relative z-10 line-clamp-4">
        {product.description}
      </p>

      <Link
        to={product.link}
        className="inline-flex items-center gap-2 px-5 py-2.5 sm:px-6 sm:py-3 rounded-xl text-white font-medium text-sm sm:text-base transition-all duration-300 hover:gap-3 relative z-10"
        style={{
          background: "hsl(0 0% 100% / 0.1)",
          border: "1px solid hsl(0 0% 100% / 0.1)",
        }}
      >
        Conhecer
        <ArrowRight size={16} />
      </Link>
    </div>
  </motion.div>
);

const SuiteHeroSection = () => {
  const [activeProduct, setActiveProduct] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      setActiveProduct((prev) => (prev + 1) % products.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const handleProductClick = useCallback((index: number) => {
    setActiveProduct(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  }, []);

  const scrollToForm = useCallback(() => {
    const formElement = document.getElementById("demo-form");
    if (formElement) {
      formElement.scrollIntoView({ behavior: "smooth" });
    }
  }, []);

  const particleCount = isMobile ? 8 : 20;

  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ background: "linear-gradient(180deg, #0a1929 0%, #0d1f35 50%, #0a1929 100%)" }}
    >
      <div className="absolute inset-0 pointer-events-none">
        <GradientOrbs />
        <NetworkPattern />
        <FloatingParticles count={particleCount} />
      </div>

      <div className="container-dxm relative z-10 py-32 lg:py-40">
        {/* Mobile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="lg:hidden text-center mb-12"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium mb-4 bg-secondary/20 text-secondary border border-secondary/30">
            <Sparkles size={14} />
            Parceiro TOTVS
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2 px-4">
            MAIS <span className="text-gradient-orange">CLIENTES</span>
          </h1>
          <p className="text-white/50 text-base sm:text-lg">PARA O SEU NEGÓCIO</p>
        </motion.div>

        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column - Product List (Desktop only) */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="hidden lg:block lg:col-span-3"
          >
            <h2 className="text-xs font-semibold uppercase tracking-[0.2em] mb-6 inline-flex items-center gap-0">
              <img
                src={logoDxSymbol}
                alt="DX"
                style={{ height: "40px" }}
                className="inline-block align-middle"
                draggable={false}
              />
              <span className="text-white text-2xl font-semibold">.Suite</span>
            </h2>

            <div className="space-y-2 mb-10">
              {products.map((product, index) => (
                <motion.button
                  key={product.id}
                  onClick={() => handleProductClick(index)}
                  className={`w-full text-left px-4 py-3 rounded-xl transition-all duration-300 ${
                    activeProduct === index
                      ? "bg-primary/20 border border-primary/30"
                      : "hover:bg-white/5 border border-transparent"
                  }`}
                  whileHover={{ x: 4 }}
                >
                  <span className={`block font-medium ${activeProduct === index ? "text-white" : "text-white"}`}>
                    {product.suffix}
                  </span>
                  <span className="text-white/40 text-sm">{product.subtitle}</span>
                </motion.button>
              ))}
            </div>

            <Link
              to="/solucoes"
              className="text-secondary text-sm font-medium hover:text-secondary/80 transition-colors inline-flex items-center gap-1"
            >
              <DxmLogo height={28} />
              <span>... muito mais</span>
            </Link>
          </motion.div>

          {/* Center Column - 3D Carousel Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-5 flex flex-col items-center"
          >
            <div
              className="relative w-full max-w-[340px] sm:max-w-full mx-auto h-[340px] sm:h-[380px]"
              style={{ perspective: "1200px" }}
            >
              <AnimatePresence mode="wait">
                <ProductCard key={products[activeProduct].id} product={products[activeProduct]} isActive={true} />
              </AnimatePresence>
            </div>

            <div className="flex items-center gap-2 mt-8">
              {products.map((_, index) => (
                <button
                  key={index}
                  onClick={() => handleProductClick(index)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    activeProduct === index ? "w-8 bg-secondary" : "w-2 bg-white/30 hover:bg-white/50"
                  }`}
                  aria-label={`Go to product ${index + 1}`}
                />
              ))}
            </div>
          </motion.div>

          {/* Right Column - CTA & Product Pills */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="lg:col-span-4 flex flex-col items-center lg:items-end"
          >
            <div className="hidden lg:block text-right mb-10">
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-8 bg-secondary/20 text-secondary border border-secondary/30">
                <Sparkles size={14} />
                Parceiro TOTVS
              </span>
              <h1 className="text-5xl xl:text-6xl font-bold text-white mb-2">
                MAIS <span className="text-gradient-orange">CLIENTES</span>
              </h1>
              <p className="text-white/50 text-xl">PARA O SEU NEGÓCIO</p>
            </div>

            <div className="hidden lg:flex flex-col gap-3 w-full max-w-xs mb-10">
              {products.slice(1).map((product, index) => (
                <motion.button
                  key={product.id}
                  onClick={() => handleProductClick(index + 1)}
                  className={`w-full px-5 py-3 rounded-xl text-left font-medium transition-all duration-300 ${
                    activeProduct === index + 1
                      ? "bg-primary text-white"
                      : "bg-white/5 text-white/70 border border-white/10 hover:bg-white/10"
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {product.suffix}
                </motion.button>
              ))}
            </div>

            <div className="lg:hidden w-full mb-8 px-2">
              <div className="flex flex-wrap justify-center gap-2 pb-2">
                {products.map((product, index) => (
                  <button
                    key={product.id}
                    onClick={() => handleProductClick(index)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all duration-300 inline-flex items-center gap-0.5 ${
                      activeProduct === index
                        ? "bg-primary text-white"
                        : "bg-white/10 text-white/70 border border-white/10"
                    }`}
                  >
                    {product.suffix}
                  </button>
                ))}
              </div>
            </div>

            <motion.button
              onClick={scrollToForm}
              className="w-full max-w-[280px] sm:max-w-xs px-6 sm:px-8 py-3 sm:py-4 rounded-2xl font-medium text-sm sm:text-base transition-all duration-300 flex items-center justify-center gap-2 sm:gap-3"
              style={{
                background: "linear-gradient(135deg, hsl(211 100% 45%) 0%, hsl(211 100% 40%) 100%)",
                boxShadow: "0 8px 32px hsl(211 100% 45% / 0.3)",
              }}
              whileHover={{ scale: 1.02, boxShadow: "0 12px 40px hsl(211 100% 45% / 0.4)" }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="text-white">Solicitar Demonstração</span>
              <ChevronDown size={18} className="text-white" />
            </motion.button>
          </motion.div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-white/20 flex items-start justify-center p-2">
          <motion.div
            className="w-1.5 h-1.5 rounded-full bg-white/40"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
      </motion.div>
    </section>
  );
};

export default SuiteHeroSection;
