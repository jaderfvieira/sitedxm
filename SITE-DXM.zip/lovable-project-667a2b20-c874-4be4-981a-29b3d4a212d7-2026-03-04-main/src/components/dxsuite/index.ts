export { default as SuiteHeroSection } from "./SuiteHeroSection";
export { default as IntegrationDiagram } from "./IntegrationDiagram";
export { default as ValueChainGrid } from "./ValueChainGrid";
export { default as BackOfficeSection } from "./BackOfficeSection";
