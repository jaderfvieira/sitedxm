import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState } from "react";
import { 
  Package, 
  Wallet, 
  FileText, 
  Calculator, 
  Building2,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const backofficeCategories = [
  {
    icon: Package,
    title: "Gestão de Compras e Estoques",
    sections: [
      {
        name: "Gestão de Estoques",
        items: [
          "Controle de Requisições/Devoluções",
          "Lançamentos/Saldos de Estoque",
          "Controle de Inventários",
          "Ressupprimento",
          "Controle de Empréstimos/Doações",
          "Controle de Transferências",
        ],
      },
      {
        name: "Processos de Compras",
        items: [
          "Solicitação de Compras",
          "Cotações/Análise",
          "Gestão Ciclo Pedido",
          "Entrada Automática Notas Fiscais",
        ],
      },
    ],
  },
  {
    icon: Wallet,
    title: "Gestão Financeira / Contratos",
    sections: [
      {
        name: "Gestão Financeira",
        items: [
          "Contas a Pagar/Receber",
          "Tesouraria/Controle de Caixas",
          "Gestão do Fluxo de Caixa",
          "Comunicação Bancária",
          "Aplicações e Empréstimos",
          "Posição Financeira Fornecedores/Clientes",
          "TEF/Conciliação de Cartões",
        ],
      },
      {
        name: "Gestão de Contratos",
        items: [
          "Contrato de Compras Serviços",
          "Contrato de Compras Mercadorias",
          "Gestão de Aditivos Contratuais",
          "Apontamentos e Controles",
          "Recebimentos",
        ],
      },
    ],
  },
  {
    icon: FileText,
    title: "Faturamento / Notas Fiscais",
    sections: [
      {
        name: "Faturamento",
        items: [
          "Integração Prefeituras",
          "NFS-e",
          "Pedido de Venda",
          "Lançamentos Contábeis",
          "Lançamentos Fiscais",
          "Lançamentos Financeiros",
          "Lançamentos Estoque",
        ],
      },
    ],
  },
  {
    icon: Calculator,
    title: "Contabilidade Fiscal",
    sections: [
      {
        name: "Contabilidade",
        items: [
          "Gestão Contábil",
          "Lançamentos/Integrações",
          "Livros Contábeis",
          "Demonstrativos Resultado",
          "Obrigações Eletrônicas",
          "Contabilidade Gerencial",
        ],
      },
      {
        name: "Fiscal",
        items: [
          "Livros Fiscais",
          "Escrituração Contábil",
          "E-Social",
          "Cálculos de Impostos",
        ],
      },
    ],
  },
  {
    icon: Building2,
    title: "Gestão de Ativos",
    sections: [
      {
        name: "Patrimônio",
        items: [
          "Controle de Ativos",
          "Responsável x Bens",
          "Localização de Ativos",
          "Controle Inventários",
          "Depreciação de Ativos",
        ],
      },
    ],
  },
];

const BackOfficeSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const isMobile = useIsMobile();
  const [openItems, setOpenItems] = useState<string[]>([]);

  const toggleItem = (title: string) => {
    setOpenItems((prev) =>
      prev.includes(title)
        ? prev.filter((item) => item !== title)
        : [...prev, title]
    );
  };

  return (
    <section
      ref={ref}
      className="py-20 lg:py-32 relative overflow-hidden"
      style={{ background: "hsl(210 50% 8%)" }}
    >
      {/* Subtle background gradient */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-0 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-20"
          style={{ background: "hsl(187 80% 48%)" }}
        />
        <div
          className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
          style={{ background: "hsl(24 95% 53%)" }}
        />
      </div>

      <div className="container-dxm relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span
            className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-widest mb-6"
            style={{
              background: "linear-gradient(135deg, hsl(187 80% 48% / 0.2), hsl(187 80% 48% / 0.1))",
              color: "hsl(187 80% 60%)",
              border: "1px solid hsl(187 80% 48% / 0.3)",
            }}
          >
            + Módulo de BackOffice Completo
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Gestão empresarial{" "}
            <span className="text-gradient-orange">integrada</span>
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Todos os processos administrativos em uma única plataforma, totalmente integrados com a gestão clínica.
          </p>
        </motion.div>

        {/* Mobile: Accordion Layout */}
        {isMobile ? (
          <div className="space-y-4">
            {backofficeCategories.map((category, index) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Collapsible
                  open={openItems.includes(category.title)}
                  onOpenChange={() => toggleItem(category.title)}
                >
                  <CollapsibleTrigger className="w-full">
                    <div
                      className="flex items-center justify-between p-4 rounded-xl transition-all"
                      style={{
                        background: "hsl(210 40% 12%)",
                        border: "1px solid hsl(187 80% 48% / 0.2)",
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ background: "hsl(187 80% 48% / 0.2)" }}
                        >
                          <category.icon size={20} style={{ color: "hsl(187 80% 60%)" }} />
                        </div>
                        <span className="font-semibold text-white text-sm text-left">
                          {category.title}
                        </span>
                      </div>
                      {openItems.includes(category.title) ? (
                        <ChevronUp size={20} className="text-white/50" />
                      ) : (
                        <ChevronDown size={20} className="text-white/50" />
                      )}
                    </div>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="p-4 space-y-4">
                      {category.sections.map((section) => (
                        <div key={section.name}>
                          <h4 className="text-xs uppercase tracking-wider text-white/40 mb-2">
                            {section.name}
                          </h4>
                          <ul className="space-y-1.5">
                            {section.items.map((item) => (
                              <li
                                key={item}
                                className="text-sm text-white/60 flex items-center gap-2"
                              >
                                <span
                                  className="w-1.5 h-1.5 rounded-full"
                                  style={{ background: "hsl(187 80% 48%)" }}
                                />
                                {item}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </motion.div>
            ))}
          </div>
        ) : (
          /* Desktop/Tablet: Grid Layout */
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {backofficeCategories.map((category, index) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -4 }}
                className="group"
              >
                <div
                  className="h-full rounded-2xl p-6 transition-all duration-300"
                  style={{
                    background: "linear-gradient(180deg, hsl(210 40% 14%), hsl(210 40% 10%))",
                    border: "1px solid hsl(187 80% 48% / 0.15)",
                    boxShadow: "0 4px 24px -8px hsl(0 0% 0% / 0.5)",
                  }}
                >
                  {/* Header */}
                  <div
                    className="flex items-center gap-3 pb-4 mb-4"
                    style={{ borderBottom: "1px solid hsl(187 80% 48% / 0.2)" }}
                  >
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-300 group-hover:scale-110"
                      style={{
                        background: "linear-gradient(135deg, hsl(187 80% 48% / 0.3), hsl(187 80% 48% / 0.1))",
                      }}
                    >
                      <category.icon
                        size={20}
                        className="transition-colors duration-300"
                        style={{ color: "hsl(187 80% 60%)" }}
                      />
                    </div>
                    <h3 className="font-semibold text-white text-sm leading-tight">
                      {category.title}
                    </h3>
                  </div>

                  {/* Sections */}
                  <div className="space-y-4">
                    {category.sections.map((section) => (
                      <div key={section.name}>
                        <h4 className="text-xs uppercase tracking-wider text-white/40 mb-2">
                          {section.name}
                        </h4>
                        <ul className="space-y-1.5">
                          {section.items.map((item) => (
                            <li
                              key={item}
                              className="text-xs text-white/60 flex items-start gap-2 group-hover:text-white/80 transition-colors"
                            >
                              <span
                                className="w-1 h-1 rounded-full mt-1.5 flex-shrink-0"
                                style={{ background: "hsl(187 80% 48%)" }}
                              />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Bottom Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <span
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm"
            style={{
              background: "hsl(210 40% 12%)",
              border: "1px solid hsl(24 95% 53% / 0.3)",
              color: "hsl(24 95% 63%)",
            }}
          >
            100% integrado com TOTVS Gestão de Clínicas
          </span>
        </motion.div>
      </div>
    </section>
  );
};

export default BackOfficeSection;
