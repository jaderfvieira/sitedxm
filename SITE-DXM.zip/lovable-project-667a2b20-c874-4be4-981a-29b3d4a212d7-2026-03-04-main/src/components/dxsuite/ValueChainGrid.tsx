import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import {
  Users,
  Calendar,
  ClipboardList,
  Puzzle,
  Link2,
  Receipt,
  Wallet,
  Package,
  Workflow,
  Megaphone,
  BarChart3,
  Sparkles,
} from "lucide-react";

const coreModules = [
  {
    icon: Users,
    title: "Portal dos Pais",
    features: ["Acesso familiar", "Programas em casa", "Comunicação direta"],
    color: "hsl(210 100% 56%)",
  },
  {
    icon: Calendar,
    title: "Agendamento e Atendimento",
    features: ["Agenda especializada", "Multidisciplinar", "Relatórios automáticos"],
    color: "hsl(6 76% 55%)",
  },
  {
    icon: ClipboardList,
    title: "Prontuário Eletrônico",
    features: ["Fluxo integrado", "Assinatura digital", "Scores personalizados"],
    color: "hsl(50 97% 60%)",
  },
  {
    icon: Puzzle,
    title: "Terapias",
    features: ["Protocolo ABA", "Pré-cadastro", "Relatórios detalhados"],
    color: "hsl(122 39% 49%)",
  },
  {
    icon: Link2,
    title: "Integração",
    features: ["Suite RM TOTVS", "Envio de dados", "Controle centralizado"],
    color: "hsl(187 100% 42%)",
  },
  {
    icon: Receipt,
    title: "Faturamento e Repasse",
    features: ["Elaboração de contas", "Geração XML TISS", "Glosa e recurso"],
    color: "hsl(28 92% 54%)",
  },
];

const complementaryModules = [
  { icon: Wallet, title: "Gestão Financeira" },
  { icon: Package, title: "Estoque/Compras" },
  { icon: Workflow, title: "Processos/APIs" },
  { icon: Megaphone, title: "Marketing" },
  { icon: BarChart3, title: "BI/Relatórios" },
  { icon: Sparkles, title: "E muito mais..." },
];

const ValueChainGrid = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="bg-white py-16 sm:py-24 lg:py-32">
      <div className="container-dxm">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-10 sm:mb-16"
        >
          <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
            Cadeia de Valor
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Core Business <span className="text-gradient-orange">Completo</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-2xl">
            Todos os módulos integrados para uma gestão clínica de excelência.
          </p>
        </motion.div>

        {/* Core Business Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-10 sm:mb-12">
          {coreModules.map((module, index) => (
            <motion.div
              key={module.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -4, boxShadow: `0 20px 40px -20px ${module.color}40` }}
              className="group rounded-2xl p-4 sm:p-6 transition-all duration-300 border-l-4"
              style={{
                background: "hsl(0 0% 98%)",
                borderLeftColor: module.color,
              }}
            >
              {/* Icon */}
              <div
                className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center mb-3 sm:mb-4 transition-transform duration-300 group-hover:scale-110"
                style={{ background: `${module.color}20` }}
              >
                <module.icon className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: module.color }} />
              </div>

              {/* Title */}
              <h3 className="text-base sm:text-lg font-semibold text-foreground mb-2 sm:mb-3">
                {module.title}
              </h3>

              {/* Features */}
              <ul className="space-y-2">
                {module.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <div
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ background: module.color }}
                    />
                    {feature}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Complementary Modules */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h3 className="text-xs sm:text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4 sm:mb-6">
            Módulos Complementares
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            {complementaryModules.map((module, index) => (
              <motion.div
                key={module.title}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.4, delay: 0.7 + index * 0.05 }}
                whileHover={{ scale: 1.05 }}
                className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-xl bg-muted/50 border border-border/50 transition-all"
              >
                <module.icon className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-muted-foreground shrink-0" />
                <span className="text-xs sm:text-sm font-medium text-foreground">{module.title}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ValueChainGrid;
