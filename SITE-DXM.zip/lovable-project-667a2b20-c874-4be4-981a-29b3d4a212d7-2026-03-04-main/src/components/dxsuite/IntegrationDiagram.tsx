import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Cloud, Shield, Lock, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const totvsModules = [
  "Atendimento",
  "Faturamento",
  "Financeiro",
  "Indicadores",
];

const dxmModules = [
  "Agenda",
  "Atendimento",
  "Gestão Cadastral",
  "Indicadores",
];

const IntegrationDiagram = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-24 lg:py-32 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #0a1929 0%, #0d1f35 50%, #0a1929 100%)",
      }}
    >
      {/* Background decorations */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute top-20 left-10 w-[300px] h-[300px] rounded-full blur-[100px]"
          style={{ background: "hsl(187 100% 42%)" }}
        />
        <div
          className="absolute bottom-20 right-10 w-[400px] h-[400px] rounded-full blur-[120px]"
          style={{ background: "hsl(28 92% 54%)" }}
        />
      </div>

      <div className="container-dxm relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
            Integração Nativa
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 px-2">
            100% Integrado com{" "}
            <span className="text-gradient-orange">TOTVS Gestão de Clínicas</span>
          </h2>
          <p className="text-white/50 text-base sm:text-lg max-w-2xl mx-auto px-4">
            A única suite de mercado com processo de ponta a ponta do paciente.
          </p>
        </motion.div>

        {/* Badges */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-12 sm:mb-16 px-2"
        >
          <Badge className="bg-[hsl(187,100%,42%)]/20 text-[hsl(187,100%,60%)] border border-[hsl(187,100%,42%)]/30 px-3 py-1.5 text-xs sm:text-sm gap-1.5 sm:gap-2">
            <Shield size={14} />
            LGPD e Segurança
          </Badge>
          <Badge className="bg-[hsl(187,100%,42%)]/20 text-[hsl(187,100%,60%)] border border-[hsl(187,100%,42%)]/30 px-3 py-1.5 text-xs sm:text-sm gap-1.5 sm:gap-2">
            <Cloud size={14} />
            Nuvem Própria
          </Badge>
          <Badge className="bg-[hsl(187,100%,42%)]/20 text-[hsl(187,100%,60%)] border border-[hsl(187,100%,42%)]/30 px-3 py-1.5 text-xs sm:text-sm gap-1.5 sm:gap-2">
            <Lock size={14} />
            Dados Criptografados
          </Badge>
        </motion.div>

        {/* Integration Diagram */}
        <div className="flex flex-col lg:flex-row items-center justify-center gap-6 lg:gap-4 px-2">
          {/* TOTVS Block */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="w-full max-w-[340px] lg:max-w-none lg:w-[300px]"
          >
            <div
              className="rounded-2xl p-5 sm:p-6 border-l-4"
              style={{
                background: "hsl(0 0% 100% / 0.05)",
                backdropFilter: "blur(16px)",
                borderColor: "hsl(187 100% 42%)",
                border: "1px solid hsl(0 0% 100% / 0.1)",
                borderLeftWidth: "4px",
                borderLeftColor: "hsl(187 100% 42%)",
              }}
            >
              <h3 className="text-[hsl(187,100%,60%)] text-lg font-semibold mb-4">
                TOTVS Gestão de Clínicas
              </h3>
              <ul className="space-y-3">
                {totvsModules.map((module, index) => (
                  <motion.li
                    key={module}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                    className="flex items-center gap-3 text-white/70 text-sm"
                  >
                    <div className="w-2 h-2 rounded-full bg-[hsl(187,100%,42%)]" />
                    {module}
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Connection - Cloud Icon */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-col items-center gap-2 py-4 lg:py-0"
          >
            {/* Animated connection lines */}
            <div className="hidden lg:flex items-center gap-2">
              <motion.div
                animate={{ x: [0, 10, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="flex items-center gap-1"
              >
                <div className="w-8 h-0.5 bg-gradient-to-r from-[hsl(187,100%,42%)] to-transparent" />
                <ArrowRight size={16} className="text-[hsl(187,100%,42%)]" />
              </motion.div>
            </div>

            {/* Cloud icon with pulse */}
            <motion.div
              animate={{
                boxShadow: [
                  "0 0 20px hsl(187 100% 42% / 0.3)",
                  "0 0 40px hsl(187 100% 42% / 0.5)",
                  "0 0 20px hsl(187 100% 42% / 0.3)",
                ],
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-20 h-20 rounded-full bg-[hsl(187,100%,42%)]/10 border border-[hsl(187,100%,42%)]/30 flex items-center justify-center"
            >
              <Cloud size={32} className="text-[hsl(187,100%,60%)]" />
            </motion.div>
            <span className="text-white/40 text-xs uppercase tracking-wider">Real-time</span>

            {/* Animated connection lines (right) */}
            <div className="hidden lg:flex items-center gap-2">
              <motion.div
                animate={{ x: [0, -10, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="flex items-center gap-1"
              >
                <ArrowRight size={16} className="text-secondary rotate-180" />
                <div className="w-8 h-0.5 bg-gradient-to-l from-secondary to-transparent" />
              </motion.div>
            </div>
          </motion.div>

          {/* DXM Block */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="w-full max-w-[340px] lg:max-w-none lg:w-[300px]"
          >
            <div
              className="rounded-2xl p-5 sm:p-6 border-l-4"
              style={{
                background: "hsl(0 0% 100% / 0.05)",
                backdropFilter: "blur(16px)",
                borderColor: "hsl(28 92% 54%)",
                border: "1px solid hsl(0 0% 100% / 0.1)",
                borderLeftWidth: "4px",
                borderLeftColor: "hsl(28 92% 54%)",
              }}
            >
              <h3 className="text-secondary text-lg font-semibold mb-4">
                Protocolo ABA by DXM
              </h3>
              <ul className="space-y-3">
                {dxmModules.map((module, index) => (
                  <motion.li
                    key={module}
                    initial={{ opacity: 0, x: 20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                    className="flex items-center gap-3 text-white/70 text-sm"
                  >
                    <div className="w-2 h-2 rounded-full bg-secondary" />
                    {module}
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default IntegrationDiagram;
