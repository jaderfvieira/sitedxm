import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import logoDxmLight from "@/assets/logo-dxm-light.png";
import { DXMLogo } from "@/components/common/DXMLogo";

const navItems = [
  { name: "Home", href: "/" },
  { name: "Sobre", href: "/sobre" },
  { name: "Soluções", href: "/solucoes" },
  { name: "DX Suite", href: "/dx-suite", highlight: true, isDXLogo: true },
  { name: "Prontuário ABA", href: "/prontuario" },
  { name: "Contato", href: "/contato" },
];

const NavItemLabel = ({ item, size = "sm" }: { item: typeof navItems[0]; size?: "sm" | "lg" }) => {
  if (item.isDXLogo) {
    const h = size === "lg" ? 36 : 24;
    return (
      <span className="inline-flex items-center gap-0">
        <DXMLogo variant="light" height={h} />
        <span>Suite</span>
      </span>
    );
  }
  return <>{item.name}</>;
};

export const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  // Bloquear scroll quando menu mobile está aberto
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "glass-dark py-4"
          : "bg-transparent py-6"
      }`}
    >
      <div className="container-dxm">
        <nav className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="relative z-10">
            <img
              src={logoDxmLight}
              alt="DXM Soluções"
              className="h-10 md:h-12 w-auto transition-transform duration-300 hover:scale-105"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-10">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`text-sm font-medium transition-colors duration-300 ${
                  item.highlight
                    ? "text-secondary hover:text-secondary/80"
                    : location.pathname === item.href
                    ? "text-white"
                    : "text-white/50 hover:text-white"
                }`}
              >
                <NavItemLabel item={item} />
              </Link>
            ))}
            <Link
              to="/contato"
              className="btn-secondary text-sm py-3 px-7"
            >
              Fale Conosco
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 text-white"
            aria-label="Menu"
          >
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </nav>
      </div>

      {/* Mobile Navigation - Fullscreen Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 starry-bg z-40 lg:hidden"
          >
            <div className="flex flex-col items-center justify-center h-full gap-8">
              {navItems.map((item, index) => (
                <motion.div
                  key={item.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link
                    to={item.href}
                    className={`text-3xl font-semibold tracking-tight transition-colors ${
                      item.highlight
                        ? "text-secondary"
                        : "text-white hover:text-secondary"
                    }`}
                  >
                    <NavItemLabel item={item} size="lg" />
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: navItems.length * 0.1 }}
                className="mt-8"
              >
                <Link to="/contato" className="btn-secondary text-lg px-10 py-4">
                  Fale Conosco
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
