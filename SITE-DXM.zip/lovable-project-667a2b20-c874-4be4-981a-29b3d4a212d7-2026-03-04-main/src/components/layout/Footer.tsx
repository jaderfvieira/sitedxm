import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, Linkedin, Instagram } from "lucide-react";
import logoDxm from "@/assets/logo-dxm-light.png";
import { companyInfo } from "@/config/company";
import { DXMLogo } from "@/components/common/DXMLogo";

const footerLinks = {
  empresa: [
    { name: "Sobre Nós", href: "/sobre" },
    { name: "Soluções", href: "/solucoes" },
    { name: "DX Suite", href: "/dx-suite", isDXLogo: true },
    { name: "Prontuário ABA", href: "/prontuario" },
    { name: "Contato", href: "/contato" },
  ],
  solucoes: [
    { name: "TOTVS Protheus", href: "/solucoes#protheus" },
    { name: "TOTVS RM", href: "/solucoes#rm" },
    { name: "TOTVS Fluig", href: "/solucoes#fluig" },
    { name: "TOTVS IPASS", href: "/solucoes#ipass" },
    { name: "RD Station", href: "/solucoes#rd-station" },
  ],
};

const FooterLinkLabel = ({ link }: { link: { name: string; isDXLogo?: boolean } }) => {
  if (link.isDXLogo) {
    return (
      <span className="inline-flex items-center gap-0">
        <DXMLogo variant="light" height={14} />
        <span>Suite</span>
      </span>
    );
  }
  return <>{link.name}</>;
};

export const Footer = () => {
  return (
    <footer className="starry-bg py-20 lg:py-24">
      <div className="container-dxm">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Logo e Descrição */}
          <div className="lg:col-span-1">
            <img src={logoDxm} alt="DXM Soluções" className="h-12 w-auto mb-6" />
            <p className="text-white/40 text-sm leading-relaxed mb-8">Somos movidos por resultados!</p>
            <div className="flex gap-3">
              <a
                href={companyInfo.social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl glass flex items-center justify-center text-white/40 hover:bg-secondary hover:text-white transition-all duration-300"
                aria-label="LinkedIn"
              >
                <Linkedin size={18} />
              </a>
              <a
                href={companyInfo.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl glass flex items-center justify-center text-white/40 hover:bg-secondary hover:text-white transition-all duration-300"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
            </div>
          </div>

          {/* Links - Empresa */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-6">Empresa</h4>
            <ul className="space-y-4">
              {footerLinks.empresa.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-white/40 hover:text-white transition-colors duration-300 text-sm"
                  >
                    <FooterLinkLabel link={link} />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Links - Soluções */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-6">Soluções</h4>
            <ul className="space-y-4">
              {footerLinks.solucoes.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-white/40 hover:text-white transition-colors duration-300 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-6">Contato</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <Phone size={14} className="text-secondary" />
                <span className="text-white/40 text-sm">{companyInfo.phone}</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={14} className="text-secondary" />
                <span className="text-white/40 text-sm">{companyInfo.email}</span>
              </li>
              <li className="flex items-center gap-3">
                <MapPin size={14} className="text-secondary" />
                <span className="text-white/40 text-sm">{companyInfo.address}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-white/10 my-16" />

        {/* Copyright */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/20 text-sm">
            © {new Date().getFullYear()} DXM Soluções. Todos os direitos reservados.
          </p>
          <div className="flex gap-8">
            <Link to="/privacidade" className="text-white/20 hover:text-white text-sm transition-colors duration-300">
              Privacidade
            </Link>
            <Link to="/termos" className="text-white/20 hover:text-white text-sm transition-colors duration-300">
              Termos
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
