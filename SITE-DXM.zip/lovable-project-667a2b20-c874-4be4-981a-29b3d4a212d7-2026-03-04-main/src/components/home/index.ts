export { HeroSection } from "./HeroSection";
export { SolutionsSection } from "./SolutionsSection";
export { StatsSection } from "./StatsSection";
export { ProntuarioPreview } from "./ProntuarioPreview";
export { CTASection } from "./CTASection";
