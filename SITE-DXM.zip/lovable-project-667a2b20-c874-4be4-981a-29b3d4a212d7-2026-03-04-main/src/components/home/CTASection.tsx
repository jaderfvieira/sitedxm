import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { FloatingShape, FloatingDiagonalLines } from "@/components/decorative";

export const CTASection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="starry-bg py-32 lg:py-40 relative overflow-hidden">
      {/* Subtle radial gradient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-radial from-secondary/10 to-transparent blur-3xl pointer-events-none" />
      
      {/* Floating Partial Hexagon - Large, Bottom Left */}
      <FloatingShape
        variant="hexagon-partial"
        size={600}
        position={{ bottom: "5%", left: "-15%" }}
        animation={["float", "rotate", "pulse"]}
        opacity={0.18}
        delay={0.3}
      />

      {/* Floating Diagonal Lines - Top Right */}
      <FloatingDiagonalLines
        size={350}
        position={{ top: "5%", right: "-10%" }}
        animation={["parallax", "glow"]}
        opacity={0.15}
        delay={0.5}
        direction="top-right"
      />
      
      <div className="container-dxm relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center max-w-3xl mx-auto"
        >
          {/* Headline */}
          <h2 className="text-hero text-white mb-8">
            Pronto para
            <br />
            <span className="text-gradient-orange">transformar?</span>
          </h2>

          <p className="text-white/50 text-xl md:text-2xl max-w-2xl mx-auto mb-14 font-light leading-relaxed">
            Nossa equipe de especialistas está pronta para criar a solução ideal para o seu negócio.
          </p>

          {/* CTA */}
          <Link
            to="/contato"
            className="btn-secondary inline-flex items-center gap-3 text-lg px-10 py-5"
          >
            Fale com um Especialista
            <ArrowRight size={20} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};
