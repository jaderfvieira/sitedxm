import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { 
  HeartPulse, 
  BarChart2, 
  Calendar, 
  FileText, 
  Users, 
  Shield,
  ArrowRight
} from "lucide-react";
import { Link } from "react-router-dom";
import { DXMLogo } from "@/components/common/DXMLogo";

const features = [
  { icon: HeartPulse, label: "Registro de sessões" },
  { icon: BarChart2, label: "Gráficos de evolução" },
  { icon: Calendar, label: "Gestão de agenda" },
  { icon: FileText, label: "Prontuário digital" },
  { icon: Users, label: "Multi-terapeutas" },
  { icon: Shield, label: "Dados seguros" },
];

export const ProntuarioPreview = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="bg-white py-32 lg:py-40 overflow-hidden">
      <div className="container-dxm">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            {/* Badge */}
              <span className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-8">
              <HeartPulse size={16} />
              <span className="inline-flex items-center gap-0">Produto <DXMLogo variant="dark" height={18} /><span>Suite</span></span>
            </span>

            <h2 className="text-headline text-foreground mb-6">
              Prontuário ABA para{" "}
              <span className="text-gradient-orange">clínicas especializadas.</span>
            </h2>

            <p className="text-muted-foreground text-lg leading-relaxed mb-12">
              Prontuário especializado em atendimento a pacientes com TEA e suas 
              particularidades. Sistema completo para clínicas de terapia ABA.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-5 mb-12">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <feature.icon size={18} className="text-foreground" />
                  </div>
                  <span className="text-sm font-medium text-foreground">
                    {feature.label}
                  </span>
                </motion.div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap gap-4">
              <Link
                to="/prontuario"
                className="btn-secondary inline-flex items-center gap-2"
              >
                Conhecer o Prontuário ABA
                <ArrowRight size={18} />
              </Link>
              <Link
                to="/contato?produto=prontuario"
                className="btn-outline-dark inline-flex items-center gap-2"
              >
                Agendar Demo
              </Link>
            </div>
          </motion.div>

          {/* Visual - Glass Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <div className="starry-bg rounded-3xl p-10 lg:p-12">
              {/* Header */}
              <div className="flex items-center justify-between mb-10 pb-8 border-b border-white/10">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-secondary to-secondary/80 flex items-center justify-center">
                    <HeartPulse size={24} className="text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-lg">Prontuário ABA</h4>
                    <p className="text-sm text-white/40">Sistema Especializado</p>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mb-10">
                <div className="text-center glass rounded-2xl p-5">
                  <p className="text-3xl font-semibold text-white">12</p>
                  <p className="text-xs text-white/40 mt-1">Pacientes</p>
                </div>
                <div className="text-center glass rounded-2xl p-5">
                  <p className="text-3xl font-semibold text-secondary">47</p>
                  <p className="text-xs text-white/40 mt-1">Sessões</p>
                </div>
                <div className="text-center glass rounded-2xl p-5">
                  <p className="text-3xl font-semibold text-white">89%</p>
                  <p className="text-xs text-white/40 mt-1">Evolução</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="glass rounded-2xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-white/50 text-sm">Progresso Mensal</span>
                  <span className="text-secondary text-sm font-semibold">+18%</span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full w-4/5 bg-gradient-to-r from-primary to-secondary rounded-full" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
