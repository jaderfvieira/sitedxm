import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { FloatingShape } from "@/components/decorative";

const stats = [
  { value: 40, prefix: "+", label: "Clientes Atendidos" },
  { value: 32, prefix: "+", suffix: " mil", label: "Usuários", description: "utilizando soluções desenvolvidas e implementadas pelo grupo" },
  { value: 24, prefix: "+", label: "Projetos Entregues", description: "por ano" },
  { value: 10, prefix: "+", label: "Anos de Atuação", description: "no mercado" },
  { value: 22, prefix: "+", suffix: " mil", label: "Horas Anuais", description: "de fábrica de software disponíveis para projetos" },
];

const Counter = ({ value, prefix, suffix, isInView }: { value: number; prefix?: string; suffix?: string; isInView: boolean }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;

    const duration = 2500;
    const steps = 60;
    const increment = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value, isInView]);

  return (
    <span>
      {prefix}{count}{suffix}
    </span>
  );
};

export const StatsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="starry-bg py-28 lg:py-36 relative overflow-hidden">
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-secondary/5 to-transparent pointer-events-none" />
      
      {/* Floating Hexagons */}
      <FloatingShape
        variant="hexagon-petrol"
        size={150}
        position={{ top: "10%", left: "5%" }}
        animation="float"
        opacity={0.1}
        delay={0}
      />
      <FloatingShape
        variant="hexagon-petrol"
        size={120}
        position={{ bottom: "15%", right: "8%" }}
        animation="float"
        opacity={0.08}
        delay={1.5}
      />
      
      <div className="container-dxm relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-headline text-white">
            Números que <span className="text-gradient-orange">comprovam.</span>
          </h2>
        </motion.div>

        {/* Stats Grid */}
        <div className="flex flex-wrap justify-center gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center w-[calc(50%-1rem)] lg:w-[calc(20%-2.4rem)]"
            >
              {/* Number */}
              <div className="text-5xl md:text-6xl lg:text-7xl font-semibold text-white mb-4 tracking-tight">
                <Counter value={stat.value} prefix={stat.prefix} suffix={stat.suffix} isInView={isInView} />
              </div>

              {/* Label */}
              <p className="text-white/40 text-sm font-medium tracking-wide">
                {stat.label}
              </p>

              {/* Description */}
              {stat.description && (
                <p className="text-white/25 text-xs mt-1 leading-relaxed max-w-[200px] mx-auto">
                  {stat.description}
                </p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
