import { motion } from "framer-motion";
import { ArrowRight, ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";
import { FloatingShape, FloatingDiagonalLines } from "@/components/decorative";
import { DXMLogo } from "@/components/common/DXMLogo";

export const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center starry-bg overflow-hidden">
      <div className="container-dxm relative z-10 pt-32 pb-20">
        <div className="max-w-4xl">
          {/* Badge with glass effect */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <span className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full glass text-white/80 text-sm font-medium">
              <span className="w-2 h-2 rounded-full bg-secondary animate-pulse-soft" />
              Parceiro Oficial TOTVS
            </span>
          </motion.div>

          {/* Headline - Apple Style */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-hero text-white mb-8"
          >
            Transforme
            <br />
            <span className="text-gradient-orange">sua empresa.</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-white/50 text-xl md:text-2xl max-w-2xl mb-14 leading-relaxed font-light"
          >
            Especialistas em{" "}
            <span className="text-white/80 font-medium">TOTVS Protheus, RM, Fluig e IPASS</span>.
            <br className="hidden md:block" />
            Implantamos, integramos e automatizamos.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-5"
          >
            <Link
              to="/contato"
              className="btn-secondary inline-flex items-center gap-3"
            >
              Agende uma Demonstração
              <ArrowRight size={18} />
            </Link>
            <Link
              to="/dx-suite"
              className="btn-outline inline-flex items-center gap-3"
            >
              <span className="inline-flex items-center gap-0">Conhecer <DXMLogo variant="light" height={24} /><span>Suite</span></span>
            </Link>
          </motion.div>

          {/* Trust indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-28 pt-12 border-t border-white/10"
          >
            <p className="text-white/30 text-xs uppercase tracking-[0.2em] mb-8 font-medium">
              Parceiros e Tecnologias
            </p>
            <div className="flex flex-wrap items-center gap-12">
              <span className="text-white/40 text-2xl font-semibold tracking-tight">TOTVS</span>
              <span className="text-white/40 text-xl font-medium tracking-tight">RD Station</span>
              <span className="text-white/40 text-base font-medium">+50 Clientes Ativos</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Subtle radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-gradient-radial from-secondary/5 to-transparent blur-3xl pointer-events-none" />

      {/* Floating TOTVS Hexagon */}
      <FloatingShape
        variant="hexagon-cyan"
        size={450}
        position={{ top: "15%", right: "-5%" }}
        animation={["float", "rotate", "mouse-follow"]}
        opacity={0.08}
        delay={0.5}
      />

      {/* Floating Diagonal Lines - Bottom Left */}
      <FloatingDiagonalLines
        size={400}
        position={{ bottom: "10%", left: "-8%" }}
        animation={["slide-in", "parallax"]}
        opacity={0.12}
        delay={0.3}
        direction="bottom-left"
      />

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-12 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <ChevronDown size={28} className="text-white/30" />
      </motion.div>
    </section>
  );
};
