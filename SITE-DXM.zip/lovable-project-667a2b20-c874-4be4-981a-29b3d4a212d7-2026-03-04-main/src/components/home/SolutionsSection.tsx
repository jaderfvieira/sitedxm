import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Database, Users, Workflow, Link as LinkIcon, BarChart3, Zap, ArrowRight, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { FloatingShape } from "@/components/decorative";
import { DXMLogo } from "@/components/common/DXMLogo";

const solutions = [
  {
    icon: Sparkles,
    title: "DX.Suite",
    description: "Produtos próprios para gestão em saúde.",
    href: "/dx-suite",
    featured: true,
  },
  {
    icon: Database,
    title: "TOTVS Protheus",
    description: "ERP completo para gestão empresarial integrada.",
    href: "/solucoes/protheus",
  },
  {
    icon: Users,
    title: "TOTVS RM",
    description: "Gestão de recursos humanos e folha de pagamento.",
    href: "/solucoes/rm",
  },
  {
    icon: Workflow,
    title: "TOTVS Fluig",
    description: "Plataforma de processos e colaboração empresarial.",
    href: "/solucoes/fluig",
  },
  {
    icon: LinkIcon,
    title: "TOTVS IPASS",
    description: "Hub de integrações robusto e automatizado.",
    href: "/solucoes/ipass",
  },
  {
    icon: Zap,
    title: "Automações",
    description: "Conectamos plataformas e automatizamos processos.",
    href: "/solucoes#automacoes",
  },
];

export const SolutionsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="bg-white py-32 lg:py-40 relative overflow-hidden">
      {/* Floating Diagonal Lines */}
      <FloatingShape
        variant="diagonal-lines"
        size={300}
        position={{ bottom: "5%", left: "-5%" }}
        animation="parallax"
        opacity={0.06}
      />
      <div className="container-dxm">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mb-20"
        >
          <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">Soluções</span>
          <h2 className="text-headline text-foreground">Tecnologia que impulsiona resultados.</h2>
        </motion.div>

        {/* Solutions Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {solutions.map((solution, index) => (
            <motion.div
              key={solution.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Link
                to={solution.href}
                className={`group block p-8 lg:p-10 rounded-3xl transition-all duration-500 h-full ${
                  solution.featured ? "starry-bg hover-glow" : "bg-muted hover:starry-bg"
                }`}
              >
                {/* Icon */}
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-8 transition-all duration-500 ${
                    solution.featured
                      ? "bg-gradient-to-br from-secondary to-secondary/80"
                      : "bg-white shadow-sm group-hover:bg-gradient-to-br group-hover:from-secondary group-hover:to-secondary/80"
                  }`}
                >
                  <solution.icon
                    size={24}
                    className={solution.featured ? "text-white" : "text-foreground group-hover:text-white"}
                  />
                </div>

                {/* Content */}
                <h3
                  className={`text-xl font-semibold mb-3 transition-colors duration-500 ${
                    solution.featured ? "text-white" : "text-foreground group-hover:text-white"
                  }`}
                >
                  {solution.title === "DX.Suite" ? (
                    <span className="inline-flex items-center gap-0">
                      <DXMLogo variant={solution.featured ? "light" : "dark"} height={28} />
                      <span>Suite</span>
                    </span>
                  ) : (
                    solution.title
                  )}
                </h3>
                <p
                  className={`text-sm leading-relaxed mb-8 transition-colors duration-500 ${
                    solution.featured ? "text-white/50" : "text-muted-foreground group-hover:text-white/60"
                  }`}
                >
                  {solution.description}
                </p>

                {/* Link */}
                <div
                  className={`flex items-center gap-2 font-medium text-sm transition-all duration-500 ${
                    solution.featured ? "text-secondary" : "text-secondary group-hover:text-secondary"
                  }`}
                >
                  Saiba mais
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
