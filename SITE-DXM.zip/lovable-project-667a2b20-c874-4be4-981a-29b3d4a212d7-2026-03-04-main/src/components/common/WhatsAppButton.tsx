import { motion } from "framer-motion";
import { companyInfo } from "@/config/company";

interface WhatsAppButtonProps {
  phoneNumber?: string;
  message?: string;
}

export const WhatsAppButton = ({
  phoneNumber = companyInfo.whatsapp,
  message = companyInfo.whatsappMessages.default,
}: WhatsAppButtonProps) => {
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <motion.a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      aria-label="Fale conosco pelo WhatsApp"
    >
      <svg viewBox="0 0 32 32" width="28" height="28" fill="white">
        <path d="M16.004 0h-.008C7.174 0 0 7.176 0 16.004c0 3.502 1.14 6.742 3.072 9.37L1.062 31.14l5.966-1.97A15.93 15.93 0 0016.004 32C24.826 32 32 24.826 32 16.004 32 7.176 24.826 0 16.004 0zm9.32 22.616c-.396 1.116-1.956 2.04-3.216 2.31-.864.186-1.992.336-5.79-1.242-4.86-2.022-7.98-6.954-8.226-7.278-.234-.324-1.974-2.634-1.974-5.022s1.248-3.564 1.692-4.05c.444-.486.972-.606 1.296-.606.324 0 .648 0 .93.018.3.012.702-.114 1.098.84.396.954 1.35 3.282 1.47 3.522.12.24.198.522.036.846-.162.324-.246.522-.486.804-.24.282-.504.63-.72.846-.24.24-.486.504-.21.99.276.486 1.23 2.028 2.64 3.288 1.812 1.62 3.342 2.124 3.816 2.364.474.24.756.198 1.032-.12.276-.318 1.2-1.398 1.518-1.878.318-.486.642-.402 1.08-.24.444.162 2.778 1.308 3.252 1.548.474.24.792.36.912.558.12.198.12 1.152-.276 2.268z"/>
      </svg>
      
      {/* Pulse animation */}
      <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-30" />
      
      {/* Pulse animation */}
      <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-30" />
    </motion.a>
  );
};
