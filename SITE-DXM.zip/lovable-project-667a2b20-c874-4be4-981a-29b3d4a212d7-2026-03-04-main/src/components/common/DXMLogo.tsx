import logoDxSymbol from "@/assets/dx-logo.png";
import logoDark from "@/assets/logo-dxm-symbol-dark.png";

interface DXMLogoProps {
  variant?: "light" | "dark";
  height?: number;
  className?: string;
}

export const DXMLogo = ({ variant = "light", height = 40, className = "" }: DXMLogoProps) => (
  <img
    src={variant === "light" ? logoDxSymbol : logoDark}
    alt="DX"
    style={{ height: `${height}px` }}
    className={`inline-block align-middle ${className}`}
    draggable={false}
  />
);
