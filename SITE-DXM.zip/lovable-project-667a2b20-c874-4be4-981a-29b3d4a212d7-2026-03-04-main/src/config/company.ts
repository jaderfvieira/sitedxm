/**
 * Configuração centralizada dos dados da empresa.
 * 
 * Para alterar qualquer informação de contato, edite apenas este arquivo.
 * Todos os componentes do site (Footer, WhatsApp, etc.) usarão esses dados automaticamente.
 */

export const companyInfo = {
  // Dados de contato
  phone: "(81) 98822-2163",           // Telefone formatado para exibição
  whatsapp: "5581988222163",           // WhatsApp (só números, com código do país 55)
  email: "isabela.lima@dxmconsultoria.com.br",
  address: "São Paulo, SP",
  
  // Mensagens padrão do WhatsApp
  whatsappMessages: {
    default: "Olá! Gostaria de saber mais sobre as soluções DXM.",
    prontuario: "Olá! Gostaria de agendar uma demonstração do Prontuário DXM."
  },
  
  // Redes sociais
  social: {
    linkedin: "https://www.linkedin.com/company/dxm-consultoria/",
    instagram: "https://www.instagram.com/dxmconsultoria"
  }
};
