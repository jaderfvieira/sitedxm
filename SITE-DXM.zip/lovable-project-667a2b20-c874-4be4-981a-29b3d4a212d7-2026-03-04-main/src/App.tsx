import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { PageTransition } from "@/components/decorative";
import { ScrollToTop } from "@/components/common/ScrollToTop";
import Index from "./pages/Index";
import Sobre from "./pages/Sobre";
import Solucoes from "./pages/Solucoes";
import Prontuario from "./pages/Prontuario";
import DXSuite from "./pages/DXSuite";
import Contato from "./pages/Contato";
import NotFound from "./pages/NotFound";
import Protheus from "./pages/solucoes/Protheus";
import RM from "./pages/solucoes/RM";
import Fluig from "./pages/solucoes/Fluig";
import IPASS from "./pages/solucoes/IPASS";
import RDStation from "./pages/solucoes/RDStation";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTop />
        <PageTransition>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/sobre" element={<Sobre />} />
            <Route path="/solucoes" element={<Solucoes />} />
            <Route path="/solucoes/protheus" element={<Protheus />} />
            <Route path="/solucoes/rm" element={<RM />} />
            <Route path="/solucoes/fluig" element={<Fluig />} />
            <Route path="/solucoes/ipass" element={<IPASS />} />
            <Route path="/solucoes/rd-station" element={<RDStation />} />
            <Route path="/prontuario" element={<Prontuario />} />
            <Route path="/dx-suite" element={<DXSuite />} />
            <Route path="/contato" element={<Contato />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </PageTransition>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
