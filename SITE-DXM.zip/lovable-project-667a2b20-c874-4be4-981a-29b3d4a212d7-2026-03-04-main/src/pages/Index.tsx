import { Layout } from "@/components/layout";
import {
  HeroSection,
  SolutionsSection,
  StatsSection,
  ProntuarioPreview,
  CTASection,
} from "@/components/home";

const Index = () => {
  return (
    <Layout>
      <HeroSection />
      <SolutionsSection />
      <StatsSection />
      <ProntuarioPreview />
      <CTASection />
    </Layout>
  );
};

export default Index;
