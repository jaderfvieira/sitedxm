import { motion, AnimatePresence } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Layout } from "@/components/layout";
import { Link } from "react-router-dom";
import {
  Briefcase,
  Users,
  TrendingUp,
  HeartPulse,
  LayoutDashboard,
  Building2,
  Shield,
  Phone,
  ArrowRight,
  FileCheck,
} from "lucide-react";
import { SuiteHeroSection } from "@/components/dxsuite";
import logoFull from "@/assets/logo-dxm-full.png";
import logoLight from "@/assets/logo-dxm-symbol-light.png";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const pillars = [
  {
    icon: Briefcase,
    title: "Gerir",
    subtitle: "Seu Negócio",
    description:
      "Gestão absoluta de informações com sistemas especializados em saúde. Redução de trabalho manual e automatização de processos.",
  },
  {
    icon: Users,
    title: "Relacionar",
    subtitle: "Com Clientes",
    description:
      "Comunicação efetiva através de sistemas personalizados. Flexibilidade para atender às necessidades específicas do seu negócio.",
  },
  {
    icon: TrendingUp,
    title: "Vender",
    subtitle: "Mais",
    description:
      "Foco em aumento de faturamento com apoio estratégico e operacional. Resultados mensuráveis e crescimento sustentável.",
  },
];

const segmentTabs = [
  {
    id: "hospitais",
    label: "Hospitais e Clínicas",
    products: [
      {
        icon: HeartPulse,
        name: "DX Prontuário ABA",
        subtitle: "Sistema Especializado",
        description:
          "Prontuário especializado em atendimento a pacientes com TEA e suas particularidades. Também contempla prestadores de serviços continuados (Fonoaudiologia, Nutrição, etc).",
        href: "/prontuario",
        featured: true,
        hasDXLogo: false,
      },
      {
        icon: LayoutDashboard,
        name: "DX Painéis Hospitalares",
        subtitle: "Gestão Visual",
        description:
          "Painéis hospitalares personalizados para visualização em tempo real de indicadores e métricas críticas.",
        href: "/contato?produto=paineis",
        hasDXLogo: false,
      },
      {
        icon: Building2,
        name: "DX Saúde Longa Permanência",
        subtitle: "Instituições de Longa Permanência",
        description: "Prontuário especializado em gestão de pacientes em Instituições de Longa Permanência.",
        href: "/contato?produto=ilpi",
        hasDXLogo: false,
      },
    ],
  },
  {
    id: "operadoras",
    label: "Operadoras e Administradoras",
    products: [
      {
        icon: Phone,
        name: "Call Center Saúde",
        subtitle: "RN 623",
        description:
          "Módulo Call Center especializado em atendimento da RN 623 para Operadoras. Integrado com URAs e ferramentas de chat de conversas. O ideal para sua operadora de grande porte.",
        href: "/contato?produto=callcenter",
        hasDXLogo: false,
      },
      {
        icon: Shield,
        name: "DX ADM de Benefícios",
        subtitle: "Módulo Administradora",
        description:
          "Módulo de Administradora de Benefícios para gestão completa e informatizada do seu processo. Controle beneficiários, valor net, valor over e todo background da sua operação.",
        href: "/contato?produto=beneficios",
        hasDXLogo: false,
      },
      {
        icon: FileCheck,
        name: "Portal de Credenciamento",
        subtitle: "Credenciamento de Prestadores",
        description:
          "Portal de credenciamento de prestadores para operadoras. Auxiliando a sua operadora a credenciar de forma mais rápida e prática os seus prestadores.",
        href: "/contato?produto=credenciamento",
        hasDXLogo: false,
      },
    ],
  },
];

type Product = (typeof segmentTabs)[0]["products"][0];

const ProductCard = ({ product, index, inView }: { product: Product; index: number; inView: boolean }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    animate={inView ? { opacity: 1, y: 0 } : {}}
    transition={{ duration: 0.6, delay: index * 0.1 }}
  >
    <Link
      to={product.href}
      className={`group block p-5 sm:p-6 md:p-8 lg:p-10 rounded-3xl transition-all duration-500 h-full ${
        product.featured ? "starry-bg hover-glow" : "bg-white hover:starry-bg"
      }`}
    >
      <div
        className={`w-11 h-11 sm:w-12 sm:h-12 lg:w-14 lg:h-14 rounded-2xl flex items-center justify-center mb-4 sm:mb-5 lg:mb-6 transition-all duration-500 ${
          product.featured
            ? "bg-gradient-to-br from-secondary to-secondary/80"
            : "bg-muted group-hover:bg-gradient-to-br group-hover:from-secondary group-hover:to-secondary/80"
        }`}
      >
        <product.icon
          className={`w-5 h-5 sm:w-6 sm:h-6 ${product.featured ? "text-white" : "text-foreground group-hover:text-white transition-colors duration-500"}`}
        />
      </div>

      <h3
        className={`text-lg sm:text-xl lg:text-2xl font-semibold mb-2 transition-colors duration-500 flex items-center gap-1.5 flex-wrap ${
          product.featured ? "text-white" : "text-foreground group-hover:text-white"
        }`}
      >
        {product.name.startsWith("DX") ? (
          <>
            {product.featured ? (
              <img src={logoLight} alt="DXM" style={{ height: "50px" }} className="inline-block align-middle" />
            ) : (
              <>
                <img
                  src={logoFull}
                  alt="DXM"
                  style={{ height: "50px" }}
                  className="inline-block align-middle group-hover:hidden"
                />
                <img
                  src={logoLight}
                  alt="DXM"
                  style={{ height: "45px" }}
                  className="hidden group-hover:inline-block align-middle"
                />
              </>
            )}
            {product.name.replace("DX ", "")}
          </>
        ) : (
          product.name
        )}
      </h3>
      <p className="text-secondary text-xs sm:text-sm font-medium mb-3 sm:mb-4">{product.subtitle}</p>
      <p
        className={`text-xs sm:text-sm leading-relaxed mb-4 sm:mb-6 transition-colors duration-500 ${
          product.featured ? "text-white/50" : "text-muted-foreground group-hover:text-white/60"
        }`}
      >
        {product.description}
      </p>

      <div
        className={`flex items-center gap-2 font-medium text-xs sm:text-sm transition-all duration-500 ${
          product.featured ? "text-secondary" : "text-primary group-hover:text-secondary"
        }`}
      >
        Saiba mais
        <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-300" />
      </div>
    </Link>
  </motion.div>
);

const DXSuite = () => {
  const pillarsRef = useRef(null);
  const productsRef = useRef(null);

  const pillarsInView = useInView(pillarsRef, { once: true, margin: "-100px" });
  const productsInView = useInView(productsRef, { once: true, margin: "-100px" });

  return (
    <Layout>
      <SuiteHeroSection />

      {/* Pillars Section */}
      <section ref={pillarsRef} className="bg-white py-16 sm:py-24 lg:py-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={pillarsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-10 sm:mb-16 lg:mb-20"
          >
            <span className="text-primary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
              Nossos Pilares
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground">O que nos move.</h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8 lg:gap-12">
            {pillars.map((pillar, index) => (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 30 }}
                animate={pillarsInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="group"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-2xl bg-muted flex items-center justify-center mb-4 sm:mb-6 lg:mb-8 group-hover:bg-gradient-to-br group-hover:from-secondary group-hover:to-secondary/80 transition-all duration-500">
                  <pillar.icon className="w-5 h-5 sm:w-6 sm:h-6 lg:w-7 lg:h-7 text-foreground group-hover:text-white transition-colors duration-500" />
                </div>
                <h3 className="text-xl sm:text-2xl lg:text-3xl font-semibold text-foreground mb-2">{pillar.title}</h3>
                <p className="text-secondary font-medium text-base sm:text-lg mb-3 sm:mb-4">{pillar.subtitle}</p>
                <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">{pillar.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section with Tabs */}
      <section ref={productsRef} className="bg-muted py-16 sm:py-24 lg:py-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={productsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-10 sm:mb-16 lg:mb-20"
          >
            <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">Produtos</span>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground">Nossas soluções.</h2>
          </motion.div>

          <Tabs defaultValue="hospitais" className="w-full">
            <TabsList className="bg-foreground/5 border border-foreground/10 rounded-2xl p-1.5 h-auto mb-8 sm:mb-12 flex flex-col sm:flex-row w-full sm:w-auto sm:inline-flex gap-1">
              {segmentTabs.map((tab) => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="rounded-xl px-5 py-3 text-xs sm:text-sm font-medium text-muted-foreground data-[state=active]:bg-secondary data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 whitespace-nowrap w-full sm:w-auto"
                >
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>

            {segmentTabs.map((tab) => (
              <TabsContent key={tab.id} value={tab.id} className="mt-0">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                  className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8"
                >
                  {tab.products.map((product, index) => (
                    <ProductCard key={product.name} product={product} index={index} inView={productsInView} />
                  ))}
                </motion.div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="starry-bg py-16 sm:py-24 lg:py-40 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-gradient-radial from-secondary/10 to-transparent blur-3xl pointer-events-none" />

        <div className="container-dxm text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto px-4"
          >
            <h2 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-white mb-6 sm:mb-8">
              Vamos <span className="text-gradient-orange">conversar?</span>
            </h2>
            <p className="text-white/50 text-base sm:text-lg lg:text-xl mb-8 sm:mb-10 lg:mb-14 font-light inline-flex items-center gap-1.5 flex-wrap justify-center">
              Descubra como a{" "}
              <img src={logoLight} alt="DXM" style={{ height: "20px" }} className="inline-block align-middle" />
              <span>Suite pode transformar a gestão do seu negócio.</span>
            </p>
            <Link
              to="/contato"
              className="btn-secondary inline-flex items-center gap-2 sm:gap-3 text-sm sm:text-base lg:text-lg px-6 sm:px-8 lg:px-10 py-3 sm:py-4 lg:py-5"
            >
              Agendar Demonstração
              <ArrowRight size={20} />
            </Link>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default DXSuite;
