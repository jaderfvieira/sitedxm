import { motion, useScroll, useTransform, useMotionValue, useSpring } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Layout } from "@/components/layout";
import { Link } from "react-router-dom";
import { IntegrationDiagram, ValueChainGrid, BackOfficeSection } from "@/components/dxsuite";
import { 
  PuzzlePiece, 
  AnimatedCounter, 
  LetterAnimation,
  MouseFollowPuzzle,
  ParticleField,
  ScreenshotCarousel,
  FlipCard,
  InteractivePreview,
  ProgressBar,
  PillarsSection,
  AgendaSection,
  TherapySection,
  BillingSection,
} from "@/components/prontuario";
import prontuarioDashboard from "@/assets/prontuario-dashboard.png";
import prontuarioAgenda from "@/assets/prontuario-agenda.png";
import autismPuzzleHead from "@/assets/autism-puzzle-head.png";
import autismRibbon from "@/assets/autism-ribbon.png";
import prontuarioRelatorio1 from "@/assets/prontuario-relatorio-1.png";
import prontuarioRelatorio2 from "@/assets/prontuario-relatorio-2.png";
import prontuarioRelatorio3 from "@/assets/prontuario-relatorio-3.png";
import {
  HeartPulse,
  Brain,
  BarChart2,
  Calendar,
  FileText,
  Users,
  Shield,
  ClipboardList,
  TrendingUp,
  Clock,
  Award,
  ArrowRight,
  BookOpen,
  Building2,
  Sparkles,
} from "lucide-react";

const features = [
  {
    icon: ClipboardList,
    title: "Registro de Sessões",
    description: "Documentação completa de cada sessão com templates personalizáveis.",
    backContent: "Registre comportamentos, intervenções e resultados em tempo real com templates intuitivos.",
    color: "blue" as const,
  },
  {
    icon: BarChart2,
    title: "Gráficos de Evolução",
    description: "Visualize o progresso com gráficos claros e relatórios automáticos.",
    backContent: "Acompanhe a evolução de cada paciente com dashboards visuais e métricas detalhadas.",
    color: "red" as const,
  },
  {
    icon: Calendar,
    title: "Gestão de Agenda",
    description: "Organize sessões, terapeutas e salas com notificações automáticas.",
    backContent: "Sistema completo de agendamento com confirmações automáticas e lembretes.",
    color: "yellow" as const,
  },
  {
    icon: FileText,
    title: "Planos de Tratamento",
    description: "Crie planos individualizados com metas e objetivos mensuráveis.",
    backContent: "Desenvolva planos personalizados baseados em protocolos ABA validados.",
    color: "green" as const,
  },
  {
    icon: Users,
    title: "Multi-Terapeutas",
    description: "Gestão de equipe com diferentes níveis de acesso.",
    backContent: "Controle permissões e visualize o desempenho de cada profissional.",
    color: "blue" as const,
  },
  {
    icon: Shield,
    title: "Dados Seguros",
    description: "Criptografia de ponta e conformidade com LGPD.",
    backContent: "Seus dados protegidos com os mais altos padrões de segurança.",
    color: "red" as const,
  },
  {
    icon: Clock,
    title: "Histórico Completo",
    description: "Acesso ao histórico completo do paciente.",
    backContent: "Navegue pelo histórico de sessões e evolução ao longo do tempo.",
    color: "yellow" as const,
  },
  {
    icon: Award,
    title: "Relatórios Profissionais",
    description: "Relatórios para famílias, escolas e convênios.",
    backContent: "Gere relatórios profissionais com um clique para todas as partes interessadas.",
    color: "green" as const,
  },
];


const screenshotTabs = [
  {
    id: "dashboard",
    label: "Dashboard",
    image: prontuarioDashboard,
    hotspots: [
      { id: "menu", x: 5, y: 15, title: "Menu de Navegação", description: "Acesse rapidamente todas as funcionalidades do sistema através do menu lateral intuitivo.", color: "blue" as const },
      { id: "charts", x: 70, y: 40, title: "Gráficos de Evolução", description: "Visualize o progresso do paciente com gráficos interativos e análises detalhadas.", color: "green" as const },
      { id: "filters", x: 50, y: 20, title: "Filtros Avançados", description: "Encontre rapidamente as informações que precisa com filtros inteligentes.", color: "yellow" as const },
    ],
  },
  {
    id: "agenda",
    label: "Agenda",
    image: prontuarioAgenda,
    hotspots: [
      { id: "calendar", x: 50, y: 30, title: "Calendário Visual", description: "Visualize a agenda de toda a equipe em um calendário interativo.", color: "blue" as const },
      { id: "new", x: 85, y: 15, title: "Novo Agendamento", description: "Crie novos agendamentos com poucos cliques.", color: "red" as const },
    ],
  },
  {
    id: "relatorios",
    label: "Relatórios",
    image: prontuarioRelatorio1,
    hotspots: [
      { id: "metricas", x: 50, y: 18, title: "Métricas do Período", description: "Visualize atendimentos, pacientes, horas trabalhadas e registros em cards coloridos.", color: "blue" as const },
      { id: "filtros", x: 50, y: 42, title: "Filtros Avançados", description: "Filtre por período, profissional e tipo de registro para análises específicas.", color: "yellow" as const },
      { id: "acoes", x: 75, y: 55, title: "Ações Rápidas", description: "Busque dados filtrados e gere PDFs profissionais com um clique.", color: "green" as const },
      { id: "profissional", x: 50, y: 75, title: "Dados do Profissional", description: "Informações detalhadas do profissional selecionado.", color: "red" as const },
    ],
  },
];

const carouselScreenshots = [
  { src: prontuarioDashboard, title: "Dashboard Principal", description: "Visão geral completa do paciente e suas evoluções" },
  { src: prontuarioAgenda, title: "Sistema de Agenda", description: "Gerencie agendamentos de toda a equipe" },
  { src: prontuarioRelatorio1, title: "Relatório de Profissionais", description: "Métricas completas de atendimentos e evoluções" },
  { src: prontuarioRelatorio2, title: "Análise Gráfica", description: "Acompanhe atendimentos por dia com gráficos interativos" },
  { src: prontuarioRelatorio3, title: "Dashboards Visuais", description: "Distribuição e comparativos em visualizações claras" },
];

const colorClasses = {
  blue: {
    border: "border-t-[hsl(210,100%,56%)]",
    bg: "bg-[hsl(210,100%,56%)]",
    text: "text-[hsl(210,100%,56%)]",
    glow: "hover:shadow-[0_0_30px_-5px_hsl(210,100%,56%,0.5)]",
  },
  red: {
    border: "border-t-[hsl(6,76%,55%)]",
    bg: "bg-[hsl(6,76%,55%)]",
    text: "text-[hsl(6,76%,55%)]",
    glow: "hover:shadow-[0_0_30px_-5px_hsl(6,76%,55%,0.5)]",
  },
  yellow: {
    border: "border-t-[hsl(50,97%,60%)]",
    bg: "bg-[hsl(50,97%,60%)]",
    text: "text-[hsl(50,97%,60%)]",
    glow: "hover:shadow-[0_0_30px_-5px_hsl(50,97%,60%,0.5)]",
  },
  green: {
    border: "border-t-[hsl(122,39%,49%)]",
    bg: "bg-[hsl(122,39%,49%)]",
    text: "text-[hsl(122,39%,49%)]",
    glow: "hover:shadow-[0_0_30px_-5px_hsl(122,39%,49%,0.5)]",
  },
};

const Prontuario = () => {
  const heroRef = useRef(null);
  const abaRef = useRef(null);
  const featuresRef = useRef(null);
  const ctaRef = useRef(null);


  const heroInView = useInView(heroRef, { once: true });
  const abaInView = useInView(abaRef, { once: true, margin: "-100px" });
  const featuresInView = useInView(featuresRef, { once: true, margin: "-100px" });
  

  // Parallax for hero screenshot
  const { scrollY } = useScroll();
  const screenshotY = useTransform(scrollY, [0, 500], [0, 100]);
  const screenshotRotateX = useTransform(scrollY, [0, 500], [5, 0]);
  const screenshotScale = useTransform(scrollY, [0, 500], [1, 0.95]);
  
  // Puzzle dispersion on scroll
  const puzzleDisperse = useTransform(scrollY, [0, 400], [0, 1]);
  
  // Mouse position for 3D effect on screenshot
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const rotateXSpring = useSpring(useTransform(mouseY, [-300, 300], [5, -5]), { stiffness: 100, damping: 20 });
  const rotateYSpring = useSpring(useTransform(mouseX, [-300, 300], [-5, 5]), { stiffness: 100, damping: 20 });

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    mouseX.set(e.clientX - centerX);
    mouseY.set(e.clientY - centerY);
  };

  return (
    <Layout>
      {/* Hero Section with Interactive Puzzle Pieces & Particles */}
      <section ref={heroRef} className="starry-bg pt-24 pb-20 lg:pt-48 lg:pb-40 overflow-hidden relative min-h-[85vh] lg:min-h-screen">
        {/* Particle Field */}
        <ParticleField count={50} />
        
        {/* Mouse-Following Puzzle Pieces */}
        <div className="absolute inset-0 overflow-hidden pointer-events-auto hidden lg:block">
          <motion.div style={{ x: useTransform(puzzleDisperse, [0, 1], [0, -100]) }}>
            <MouseFollowPuzzle color="blue" size={80} className="absolute top-20 left-[10%]" intensity={1.5} />
          </motion.div>
          <motion.div style={{ x: useTransform(puzzleDisperse, [0, 1], [0, 150]) }}>
            <MouseFollowPuzzle color="red" size={60} className="absolute top-32 right-[15%]" intensity={0.8} />
          </motion.div>
          <motion.div style={{ y: useTransform(puzzleDisperse, [0, 1], [0, 100]) }}>
            <MouseFollowPuzzle color="yellow" size={70} className="absolute bottom-40 left-[20%]" intensity={1.2} />
          </motion.div>
          <motion.div style={{ x: useTransform(puzzleDisperse, [0, 1], [0, -80]) }}>
            <MouseFollowPuzzle color="green" size={50} className="absolute bottom-32 right-[25%]" intensity={1} />
          </motion.div>
          <motion.div style={{ y: useTransform(puzzleDisperse, [0, 1], [0, -120]) }}>
            <MouseFollowPuzzle color="blue" size={40} className="absolute top-[40%] left-[5%]" intensity={0.6} />
          </motion.div>
          <motion.div style={{ x: useTransform(puzzleDisperse, [0, 1], [0, 100]) }}>
            <MouseFollowPuzzle color="red" size={55} className="absolute top-[60%] right-[8%]" intensity={0.9} />
          </motion.div>
        </div>

        {/* Mobile: Static puzzle pieces */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none lg:hidden">
          <PuzzlePiece color="blue" size={40} className="absolute top-20 left-[2%]" delay={0} duration={6} />
          <PuzzlePiece color="red" size={35} className="absolute top-32 right-[2%]" delay={0.5} duration={8} />
          <PuzzlePiece color="yellow" size={38} className="absolute bottom-40 left-[5%]" delay={1} duration={7} />
          <PuzzlePiece color="green" size={32} className="absolute bottom-32 right-[5%]" delay={1.5} duration={9} />
        </div>

        <div className="container-dxm relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={heroInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7 }}
            >
              {/* Badge with rotating gradient border and shimmer text */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={heroInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: 0.2 }}
                whileHover={{ scale: 1.05 }}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full mb-10 relative overflow-hidden group"
                style={{
                  background: "linear-gradient(hsl(234 29% 14%), hsl(234 29% 14%)) padding-box, linear-gradient(90deg, hsl(210 100% 56%), hsl(6 76% 55%), hsl(50 97% 60%), hsl(122 39% 49%), hsl(210 100% 56%)) border-box",
                  border: "2px solid transparent",
                  backgroundSize: "100% 100%, 200% 100%",
                  animation: "autism-gradient-shift 4s ease-in-out infinite",
                }}
              >
                <Sparkles size={16} className="text-[hsl(50,97%,60%)]" />
                <span className="shimmer-text text-sm font-medium">Sistema Especializado TEA</span>
              </motion.div>

              {/* Hero Title with Letter Animation */}
              <h1 className="text-4xl md:text-5xl lg:text-hero text-white mb-6">
                <LetterAnimation text="Prontuário " delay={0.3} />
                <LetterAnimation text="ABA" delay={0.8} gradient />
              </h1>

              <motion.p 
                initial={{ opacity: 0 }}
                animate={heroInView ? { opacity: 1 } : {}}
                transition={{ duration: 0.6, delay: 1.2 }}
                className="text-white/60 text-lg lg:text-xl mb-4 font-medium"
              >
                O sistema mais completo para clínicas ABA
              </motion.p>

              <motion.p 
                initial={{ opacity: 0 }}
                animate={heroInView ? { opacity: 1 } : {}}
                transition={{ duration: 0.6, delay: 1.4 }}
                className="text-white/40 text-base lg:text-lg leading-relaxed mb-8 lg:mb-12 max-w-xl font-light"
              >
                Gestão clínica especializada no tratamento do Transtorno do Espectro Autista 
                com protocolos ABA, gráficos de evolução e relatórios automatizados.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={heroInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 1.6 }}
                className="flex flex-wrap gap-4"
              >
                <motion.div
                  whileHover={{ scale: 1.05, rotate: 1 }}
                  whileTap={{ scale: 0.98 }}
                  className="ripple-container"
                >
                  <Link
                    to="/contato?produto=prontuario"
                    className="btn-secondary inline-flex items-center gap-2 group pulse-autism-glow"
                  >
                    Agendar Demonstração
                    <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
                  </Link>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }}>
                  <a
                    href="#funcionalidades"
                    className="btn-outline inline-flex items-center gap-2"
                  >
                    Ver Funcionalidades
                  </a>
                </motion.div>
              </motion.div>
            </motion.div>

            {/* 3D Screenshot with Mouse-Following Rotation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, rotateY: -10 }}
              animate={heroInView ? { opacity: 1, scale: 1, rotateY: 0 } : {}}
              transition={{ duration: 1, delay: 0.5 }}
              style={{ 
                y: screenshotY,
                scale: screenshotScale,
              }}
              className="relative hidden lg:block"
              onMouseMove={handleMouseMove}
              onMouseLeave={() => { mouseX.set(0); mouseY.set(0); }}
            >
              <motion.div 
                className="relative hover-glitch"
                style={{
                  rotateX: rotateXSpring,
                  rotateY: rotateYSpring,
                  transformStyle: "preserve-3d",
                }}
              >
                {/* Pulsating glow effect behind the screenshot */}
                <motion.div 
                  className="absolute -inset-4 rounded-3xl opacity-50 blur-2xl pulse-autism-glow"
                  style={{
                    background: "linear-gradient(135deg, hsl(210 100% 56% / 0.3), hsl(6 76% 55% / 0.2), hsl(50 97% 60% / 0.2), hsl(122 39% 49% / 0.3))",
                  }}
                />
                
                {/* Screenshot container with morphing rotation */}
                <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10 morph-rotate">
                  <img 
                    src={prontuarioDashboard} 
                    alt="Dashboard Prontuário ABA" 
                    className="w-full h-auto"
                  />
                  
                  {/* Overlay gradient for depth */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[hsl(234,29%,10%,0.3)] to-transparent pointer-events-none" />
                </div>

                {/* Apple-style reflection */}
                <div 
                  className="absolute top-full left-0 right-0 h-32 mt-4 rounded-2xl overflow-hidden opacity-20"
                  style={{
                    transform: "scaleY(-1)",
                    maskImage: "linear-gradient(to bottom, rgba(0,0,0,0.4), transparent)",
                    WebkitMaskImage: "linear-gradient(to bottom, rgba(0,0,0,0.4), transparent)",
                  }}
                >
                  <img 
                    src={prontuarioDashboard} 
                    alt="" 
                    className="w-full h-auto blur-sm"
                  />
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Ribbon with Autism Colors + Progress Bars */}
      <section className="relative py-12 lg:py-20 overflow-hidden" style={{ background: "hsl(234 29% 8%)" }}>
        {/* Top border with autism colors */}
        <div className="absolute top-0 left-0 right-0 h-1 autism-gradient-animated" />
        
        <div className="container-dxm">
          {/* Stats Section Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl lg:text-5xl font-bold text-white mb-4">
              Impacto <span className="text-autism-gradient">Real.</span>
            </h2>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">
              Resultados que fazem a diferença no cuidado com TEA.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 lg:gap-12">
            {[
              { value: 1247, label: "Pacientes Ativos", suffix: "", color: "blue" as const, progress: 85 },
              { value: 89, label: "Profissionais", suffix: "+", color: "red" as const, progress: 72 },
              { value: 15, label: "Protocolos ABA", suffix: "+", color: "yellow" as const, progress: 90 },
              { value: 98, label: "Satisfação", suffix: "%", color: "green" as const, progress: 98 },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <p className={`text-3xl md:text-4xl lg:text-6xl font-bold mb-2 ${colorClasses[stat.color].text}`}>
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </p>
                <p className="text-white/40 text-sm mb-4">{stat.label}</p>
                <ProgressBar value={stat.progress} color={stat.color} delay={index * 0.2} />
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Bottom border with autism colors */}
        <div className="absolute bottom-0 left-0 right-0 h-1 autism-gradient-animated" style={{ animationDirection: "reverse" }} />
      </section>

      {/* NEW: Pillars Section - Agilidade + Produtividade + Experiência */}
      <PillarsSection />

      {/* NEW: Agenda Prática Section */}
      <AgendaSection />

      {/* NEW: Therapy Section */}
      <TherapySection />

      {/* NEW: Billing Section */}
      <BillingSection />

      {/* Cadeia de Valor - Core Business */}
      <ValueChainGrid />

      {/* BackOffice - Gestão empresarial integrada */}
      <BackOfficeSection />

      {/* TOTVS Integration Diagram */}
      <IntegrationDiagram />

      {/* Compromisso com TEA - Symbolic Section */}
      <section className="relative py-16 lg:py-32 overflow-hidden" style={{ background: "linear-gradient(180deg, hsl(234 29% 8%) 0%, hsl(234 29% 12%) 50%, hsl(234 29% 8%) 100%)" }}>
        {/* Subtle radial glow */}
        <div className="absolute inset-0 opacity-30"
          style={{
            background: "radial-gradient(ellipse at center, hsl(210 100% 56% / 0.15), transparent 60%)",
          }}
        />

        <div className="container-dxm relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-20">
            {/* Puzzle Head - Left */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <motion.div
                animate={{ 
                  y: [0, -10, 0],
                  rotateZ: [0, 2, 0, -2, 0],
                }}
                transition={{ 
                  duration: 5, 
                  repeat: Infinity, 
                  ease: "easeInOut" 
                }}
                whileHover={{ scale: 1.05, rotateY: 10 }}
                className="relative"
              >
                {/* Glow behind */}
                <div className="absolute -inset-4 rounded-full opacity-40 blur-2xl"
                  style={{ background: "linear-gradient(135deg, hsl(210 100% 56% / 0.4), hsl(6 76% 55% / 0.3), hsl(50 97% 60% / 0.3), hsl(122 39% 49% / 0.4))" }}
                />
                <img 
                  src={autismPuzzleHead} 
                  alt="Autism Puzzle Head" 
                  className="w-24 h-24 md:w-32 md:h-32 lg:w-48 lg:h-48 object-contain relative z-10 drop-shadow-2xl"
                />
              </motion.div>
            </motion.div>

            {/* Center Text */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-center max-w-xl"
            >
              <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-6">
                Compromisso com a{" "}
                <span className="text-autism-gradient">Neurodiversidade</span>
              </h3>
              <p className="text-white/50 text-lg leading-relaxed">
                Desenvolvido em parceria com especialistas em TEA, nosso sistema 
                respeita e valoriza cada indivíduo no espectro autista, 
                promovendo uma abordagem terapêutica humanizada e baseada em evidências.
              </p>
            </motion.div>

            {/* Ribbon - Right */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative"
            >
              <motion.div
                animate={{ 
                  y: [0, -8, 0],
                  rotate: [0, 360],
                }}
                transition={{ 
                  y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
                  rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                }}
                whileHover={{ scale: 1.1 }}
                className="relative"
              >
                {/* Pulsing glow */}
                <motion.div 
                  animate={{ opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute -inset-4 rounded-full blur-xl"
                  style={{ background: "linear-gradient(135deg, hsl(210 100% 56% / 0.5), hsl(6 76% 55% / 0.4), hsl(50 97% 60% / 0.4), hsl(122 39% 49% / 0.5))" }}
                />
                <img 
                  src={autismRibbon} 
                  alt="Autism Awareness Ribbon" 
                  className="w-20 h-20 md:w-28 md:h-28 lg:w-44 lg:h-44 object-contain relative z-10 drop-shadow-2xl"
                />
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* O que é ABA - Asymmetric Layout with Animated Lines */}
      <section ref={abaRef} className="bg-white py-20 lg:py-40">
        <div className="container-dxm">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={abaInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7 }}
            >
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-8"
                style={{ background: "linear-gradient(135deg, hsl(210 100% 56% / 0.2), hsl(122 39% 49% / 0.2))" }}>
                <Brain size={28} className="text-foreground" />
              </div>

              <h2 className="text-headline text-foreground mb-8">
                O que são os{" "}
                <span className="text-autism-gradient">protocolos ABA?</span>
              </h2>

              <div className="space-y-6 text-muted-foreground leading-relaxed text-lg">
                <p>
                  Os protocolos ABA são ferramentas de avaliação sistemática que ajudam 
                  a identificar áreas de desenvolvimento de crianças com autismo ou 
                  deficiências de desenvolvimento.
                </p>
                <p>
                  São métodos pré-determinados e maleáveis para tratar, acompanhar 
                  e evoluir os pacientes. Com o aumento do diagnóstico, a demanda 
                  tem crescido cada vez mais no Brasil.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={abaInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="space-y-4 relative"
            >
              {/* Connecting line SVG with draw animation */}
              <svg className="absolute left-6 top-8 bottom-8 w-1 hidden lg:block" style={{ height: "calc(100% - 64px)" }}>
                <motion.line
                  x1="2" y1="0" x2="2" y2="100%"
                  stroke="url(#autism-line-gradient)"
                  strokeWidth="2"
                  strokeDasharray="8 4"
                  initial={{ pathLength: 0 }}
                  animate={abaInView ? { pathLength: 1 } : {}}
                  transition={{ duration: 2, delay: 0.5 }}
                />
                <defs>
                  <linearGradient id="autism-line-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="hsl(210 100% 56%)" />
                    <stop offset="33%" stopColor="hsl(6 76% 55%)" />
                    <stop offset="66%" stopColor="hsl(50 97% 60%)" />
                    <stop offset="100%" stopColor="hsl(122 39% 49%)" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Traveling particle on the line */}
              {abaInView && (
                <motion.div
                  className="absolute left-[3px] w-3 h-3 rounded-full hidden lg:block"
                  style={{ background: "linear-gradient(135deg, hsl(210 100% 56%), hsl(122 39% 49%))" }}
                  animate={{
                    top: ["8px", "calc(100% - 72px)", "8px"],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
              )}

              {[
                { icon: BookOpen, title: "Baseada em Evidências", desc: "Décadas de pesquisa científica validando a metodologia", color: "blue" as const },
                { icon: Users, title: "Individualizada", desc: "Planos únicos adaptados para cada pessoa", color: "red" as const },
                { icon: BarChart2, title: "Mensurável", desc: "Progresso documentado com dados objetivos", color: "yellow" as const },
                { icon: TrendingUp, title: "Evolutiva", desc: "Foco em reforçar comportamentos positivos", color: "green" as const },
              ].map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, x: 20 }}
                  animate={abaInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.15 }}
                  whileHover={{ x: 8, scale: 1.02 }}
                  className={`flex items-start gap-4 lg:gap-5 bg-muted rounded-2xl p-4 lg:p-6 lg:ml-8 border-l-4 ${colorClasses[item.color].border} transition-all cursor-pointer`}
                >
                  <motion.div 
                    animate={{ y: [0, -3, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: index * 0.3 }}
                    className={`w-10 h-10 lg:w-12 lg:h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${colorClasses[item.color].bg}`}
                  >
                    <item.icon size={20} className="text-white" />
                  </motion.div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">{item.title}</h4>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Interactive Preview with Tabs */}
      <section className="starry-bg py-20 lg:py-40 overflow-hidden">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="text-sm font-semibold uppercase tracking-[0.2em] mb-4 block text-autism-gradient">
              Conheça o Sistema
            </span>
            <h2 className="text-headline text-white">
              Interface <span className="text-autism-gradient">intuitiva</span> e completa
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-5xl mx-auto"
          >
            <InteractivePreview tabs={screenshotTabs} />
          </motion.div>
        </div>
      </section>

      {/* 3D Carousel Section */}
      <section className="bg-white py-20 lg:py-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="text-sm font-semibold uppercase tracking-[0.2em] mb-4 block text-autism-gradient">
              Explore as Telas
            </span>
            <h2 className="text-headline text-foreground">
              Navegue pelo <span className="text-autism-gradient">sistema</span>
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-4xl mx-auto"
          >
            <ScreenshotCarousel screenshots={carouselScreenshots} />
          </motion.div>
        </div>
      </section>

      {/* Funcionalidades - FlipCards Grid */}
      <section ref={featuresRef} id="funcionalidades" className="starry-bg py-20 lg:py-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={featuresInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-20 text-center"
          >
            <span className="text-sm font-semibold uppercase tracking-[0.2em] mb-4 block text-autism-gradient">
              Funcionalidades
            </span>
            <h2 className="text-headline text-white">
              Tudo que sua clínica <span className="text-autism-gradient">precisa</span>
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <FlipCard
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                backContent={feature.backContent}
                color={feature.color}
                delay={Math.floor(index / 4) * 0.1 + (index % 4) * 0.08}
              />
            ))}
          </div>
        </div>
      </section>


      {/* CTA Final - Immersive with Converging Puzzles */}
      <section ref={ctaRef} className="relative py-20 lg:py-48 overflow-hidden" style={{ background: "hsl(234 29% 10%)" }}>
        {/* Radial gradient background with autism colors */}
        <div className="absolute inset-0 opacity-30"
          style={{
            background: "radial-gradient(ellipse at top left, hsl(210 100% 56% / 0.3), transparent 50%), radial-gradient(ellipse at bottom right, hsl(122 39% 49% / 0.3), transparent 50%), radial-gradient(ellipse at center, hsl(6 76% 55% / 0.15), transparent 60%)",
          }}
        />

        {/* Particles */}
        <ParticleField count={30} />

        {/* Converging puzzle pieces */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            initial={{ x: -200, y: -100, rotate: -30 }}
            whileInView={{ x: 0, y: 0, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.3 }}
          >
            <PuzzlePiece color="blue" size={100} className="absolute top-10 left-[5%]" delay={0} duration={5} />
          </motion.div>
          <motion.div
            initial={{ x: 200, y: -100, rotate: 30 }}
            whileInView={{ x: 0, y: 0, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.5 }}
          >
            <PuzzlePiece color="red" size={80} className="absolute top-20 right-[10%]" delay={0.5} duration={6} />
          </motion.div>
          <motion.div
            initial={{ x: -150, y: 100, rotate: -20 }}
            whileInView={{ x: 0, y: 0, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.7 }}
          >
            <PuzzlePiece color="yellow" size={90} className="absolute bottom-20 left-[15%]" delay={1} duration={7} />
          </motion.div>
          <motion.div
            initial={{ x: 150, y: 100, rotate: 20 }}
            whileInView={{ x: 0, y: 0, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.9 }}
          >
            <PuzzlePiece color="green" size={70} className="absolute bottom-10 right-[20%]" delay={1.5} duration={5.5} />
          </motion.div>
        </div>
        
        <div className="container-dxm text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <h2 className="text-3xl md:text-5xl lg:text-7xl font-bold text-white mb-6 lg:mb-8 leading-tight">
              Transforme sua{" "}
              <span className="text-autism-gradient">clínica</span>
            </h2>
            <p className="text-white/50 text-base lg:text-xl mb-10 lg:mb-14 font-light max-w-2xl mx-auto">
              Agende uma demonstração gratuita e descubra como o Prontuário ABA 
              pode revolucionar a gestão da sua clínica.
            </p>
            
            <motion.div
              whileHover={{ scale: 1.05, rotate: 1 }}
              whileTap={{ scale: 0.98 }}
            >
              <Link
                to="/contato?produto=prontuario"
                className="inline-flex items-center gap-3 text-lg px-10 py-5 rounded-2xl font-medium text-white transition-all duration-300 group pulse-autism-glow"
                style={{
                  background: "linear-gradient(135deg, hsl(210 100% 56%), hsl(6 76% 55%), hsl(50 97% 60%), hsl(122 39% 49%))",
                  backgroundSize: "200% 200%",
                  animation: "autism-gradient-shift 4s ease-in-out infinite",
                }}
              >
                Agendar Demonstração
                <ArrowRight size={20} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

    </Layout>
  );
};

export default Prontuario;
