import { solutionsData } from "@/data/solutions";
import { SolutionPage } from "./SolutionPage";

const Fluig = () => <SolutionPage data={solutionsData.fluig} />;

export default Fluig;
