import { solutionsData } from "@/data/solutions";
import { SolutionPage } from "./SolutionPage";

const IPASS = () => <SolutionPage data={solutionsData.ipass} />;

export default IPASS;
