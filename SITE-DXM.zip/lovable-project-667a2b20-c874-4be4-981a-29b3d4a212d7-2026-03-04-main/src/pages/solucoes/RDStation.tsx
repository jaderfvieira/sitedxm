import { solutionsData } from "@/data/solutions";
import { SolutionPage } from "./SolutionPage";

const RDStation = () => <SolutionPage data={solutionsData["rd-station"]} />;

export default RDStation;
