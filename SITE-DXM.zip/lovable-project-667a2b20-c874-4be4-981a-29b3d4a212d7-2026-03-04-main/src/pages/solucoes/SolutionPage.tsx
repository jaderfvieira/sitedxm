import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout";
import { FloatingShape } from "@/components/decorative";
import { CheckCircle2, ArrowRight, ArrowLeft } from "lucide-react";
import { companyInfo } from "@/config/company";
import type { SolutionData } from "@/data/solutions";

interface SolutionPageProps {
  data: SolutionData;
}

export const SolutionPage = ({ data }: SolutionPageProps) => {
  const Icon = data.icon;

  return (
    <Layout>
      {/* Hero */}
      <section className="starry-bg pt-40 pb-24 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <FloatingShape
          variant="hexagon-cyan"
          size={400}
          position={{ top: "10%", right: "-8%" }}
          animation={["float", "parallax"]}
          opacity={0.08}
        />
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-4xl"
          >
            <Link
              to="/solucoes"
              className="inline-flex items-center gap-2 text-white/40 hover:text-white/70 transition-colors text-sm mb-10"
            >
              <ArrowLeft size={14} />
              Voltar para Soluções
            </Link>

            <div className="w-16 h-16 rounded-2xl bg-secondary/20 flex items-center justify-center mb-8">
              <Icon size={30} className="text-secondary" />
            </div>

            <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
              {data.subtitle}
            </span>

            <h1 className="text-hero text-white mb-6">
              {data.title}
            </h1>

            <p className="text-white/60 text-xl md:text-2xl leading-relaxed font-light max-w-3xl">
              {data.tagline}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Overview */}
      <section className="bg-white py-24 lg:py-32">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="grid lg:grid-cols-2 gap-16 items-center"
          >
            <div>
              <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
                Visão Geral
              </span>
              <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-6">
                O que é o {data.title}?
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                {data.overview}
              </p>
            </div>

            <div className="starry-bg rounded-3xl p-8 lg:p-10">
              <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
                Posição de Mercado
              </span>
              <p className="text-white/80 text-lg leading-relaxed font-light">
                {data.marketPosition}
              </p>

              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/50 text-sm leading-relaxed">
                  {data.description}
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-muted py-24 lg:py-32">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl mb-16"
          >
            <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
              Funcionalidades
            </span>
            <h2 className="text-3xl md:text-4xl font-semibold text-foreground">
              Tudo que você precisa em uma plataforma.
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {data.features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.6, delay: index * 0.07 }}
                className="bg-white rounded-2xl p-6"
              >
                <div className="w-2 h-2 rounded-full bg-secondary mb-4" />
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits + Ideal For */}
      <section className="bg-white py-24 lg:py-32">
        <div className="container-dxm">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Benefits */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7 }}
            >
              <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
                Benefícios
              </span>
              <h2 className="text-3xl font-semibold text-foreground mb-8">
                O que muda na prática.
              </h2>
              <div className="space-y-4">
                {data.benefits.map((benefit) => (
                  <div key={benefit} className="flex items-start gap-3">
                    <CheckCircle2 size={20} className="text-secondary shrink-0 mt-0.5" />
                    <span className="text-foreground leading-relaxed">{benefit}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Ideal For */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.15 }}
            >
              <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
                Para quem é
              </span>
              <h2 className="text-3xl font-semibold text-foreground mb-8">
                Perfil de empresa ideal.
              </h2>
              <div className="starry-bg rounded-2xl p-8">
                <div className="space-y-4">
                  {data.idealFor.map((profile) => (
                    <div key={profile} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-secondary shrink-0 mt-2" />
                      <span className="text-white/70 leading-relaxed">{profile}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="starry-bg py-32 lg:py-40 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-gradient-radial from-secondary/10 to-transparent blur-3xl pointer-events-none" />

        <div className="container-dxm text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-2xl mx-auto"
          >
            <h2 className="text-headline text-white mb-6">
              Pronto para implementar o{" "}
              <span className="text-gradient-orange">{data.title}?</span>
            </h2>
            <p className="text-white/50 text-lg mb-12 font-light">
              Fale com nossos especialistas e descubra como podemos acelerar a implantação na sua empresa.
            </p>
            <a
              href={`https://wa.me/${companyInfo.whatsapp}?text=${encodeURIComponent(data.whatsappMessage)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary inline-flex items-center gap-2"
            >
              Falar com um Especialista
              <ArrowRight size={18} />
            </a>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};
