import { solutionsData } from "@/data/solutions";
import { SolutionPage } from "./SolutionPage";

const Protheus = () => <SolutionPage data={solutionsData.protheus} />;

export default Protheus;
