import { solutionsData } from "@/data/solutions";
import { SolutionPage } from "./SolutionPage";

const RM = () => <SolutionPage data={solutionsData.rm} />;

export default RM;
