import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Layout } from "@/components/layout";
import { Link } from "react-router-dom";
import { companyInfo } from "@/config/company";
import {
  Database,
  Users,
  Workflow,
  Link as LinkIcon,
  BarChart3,
  Zap,
  CheckCircle2,
  ArrowRight,
  ExternalLink,
} from "lucide-react";
import { FloatingShape } from "@/components/decorative";

const solutions = [
  {
    id: "protheus",
    icon: Database,
    title: "TOTVS Protheus",
    subtitle: "ERP Completo",
    description:
      "O ERP mais utilizado no Brasil. Gestão integrada de todos os processos empresariais.",
    features: [
      "Gestão Financeira",
      "Controle de Estoque",
      "Módulo de Vendas",
      "Gestão de Produção",
      "Fiscal e Contábil",
      "Business Intelligence",
    ],
    benefits: [
      "Redução de custos operacionais",
      "Maior controle e visibilidade",
      "Tomada de decisão baseada em dados",
      "Compliance fiscal automatizado",
    ],
    detailsHref: "/solucoes/protheus",
  },
  {
    id: "rm",
    icon: Users,
    title: "TOTVS RM",
    subtitle: "Gestão de Pessoas",
    description:
      "Solução completa para gestão de RH, folha de pagamento e desenvolvimento de talentos.",
    features: [
      "Folha de Pagamento",
      "Gestão de Benefícios",
      "Recrutamento",
      "Treinamento",
      "Avaliação",
      "Portal do Colaborador",
    ],
    benefits: [
      "Automatização de processos de RH",
      "Redução de erros na folha",
      "Melhor gestão de talentos",
      "Conformidade trabalhista",
    ],
    detailsHref: "/solucoes/rm",
  },
  {
    id: "fluig",
    icon: Workflow,
    title: "TOTVS Fluig",
    subtitle: "Processos e Colaboração",
    description:
      "Plataforma de gestão de processos, documentos e colaboração empresarial.",
    features: [
      "Construtor de Workflows",
      "Gestão de Documentos",
      "Portal Corporativo",
      "Formulários Dinâmicos",
      "Analytics",
      "Integração com ERPs",
    ],
    benefits: [
      "Processos mais ágeis",
      "Redução de papel",
      "Rastreabilidade completa",
      "Colaboração em tempo real",
    ],
    detailsHref: "/solucoes/fluig",
  },
  {
    id: "ipass",
    icon: LinkIcon,
    title: "TOTVS IPASS",
    subtitle: "Hub de Integrações",
    description:
      "Plataforma robusta de integrações no-code/low-code para conectar qualquer sistema.",
    features: [
      "Conectores Prontos",
      "Orquestração de APIs",
      "Transformação de Dados",
      "Monitoramento",
      "Logs e Auditoria",
      "Escalabilidade",
    ],
    benefits: [
      "Integração sem código",
      "Dados sincronizados",
      "Redução de erros",
      "Visibilidade total",
    ],
    detailsHref: "/solucoes/ipass",
  },
  {
    id: "rd-station",
    icon: BarChart3,
    title: "RD Station",
    subtitle: "Marketing e Vendas",
    description:
      "Plataforma líder em automação de marketing digital no Brasil.",
    features: [
      "Landing Pages",
      "Automação de E-mail",
      "Lead Scoring",
      "CRM Integrado",
      "Analytics",
      "Integração com Anúncios",
    ],
    benefits: [
      "Mais leads qualificados",
      "Jornada automatizada",
      "ROI mensurável",
      "Alinhamento marketing e vendas",
    ],
    detailsHref: "/solucoes/rd-station",
  },
  {
    id: "automacoes",
    icon: Zap,
    title: "Automações",
    subtitle: "Conexões Inteligentes",
    description:
      "Conectamos plataformas e automatizamos processos repetitivos.",
    features: [
      "Integração E-commerces",
      "Conexão ERP x Logística",
      "Automação de Relatórios",
      "Sincronização",
      "Webhooks e APIs",
      "RPA",
    ],
    benefits: [
      "Eliminação de tarefas manuais",
      "Dados consistentes",
      "Processos mais rápidos",
      "Foco no que importa",
    ],
    detailsHref: null,
  },
];

const Solucoes = () => {
  const heroRef = useRef(null);
  const heroInView = useInView(heroRef, { once: true });

  return (
    <Layout>
      {/* Hero Section */}
      <section ref={heroRef} className="starry-bg pt-40 pb-24 lg:pt-48 lg:pb-32 relative overflow-hidden">
        {/* Floating Hexagon */}
        <FloatingShape
          variant="hexagon-cyan"
          size={400}
          position={{ top: "10%", right: "-8%" }}
          animation={["float", "parallax"]}
          opacity={0.1}
        />
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={heroInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="max-w-4xl mx-auto text-center"
          >
            <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-6 block">
              Nossas Soluções
            </span>
            <h1 className="text-hero text-white mb-8">
              Tecnologias que <span className="text-gradient-orange">impulsionam.</span>
            </h1>
            <p className="text-white/50 text-xl md:text-2xl leading-relaxed font-light">
              Portfólio completo de soluções TOTVS e integrações para 
              transformar a gestão da sua empresa.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Solutions List */}
      <section>
        {solutions.map((solution, index) => (
          <div
            key={solution.id}
            id={solution.id}
            className={index % 2 === 0 ? "bg-white py-24 lg:py-32" : "bg-muted py-24 lg:py-32"}
          >
            <div className="container-dxm">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7 }}
                className={`grid lg:grid-cols-2 gap-16 items-center ${
                  index % 2 === 1 ? "lg:flex-row-reverse" : ""
                }`}
              >
                {/* Content */}
                <div className={index % 2 === 1 ? "lg:order-2" : ""}>
                  <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mb-6">
                    <solution.icon size={26} className="text-secondary" />
                  </div>

                  <span className="text-secondary text-sm font-medium mb-2 block">
                    {solution.subtitle}
                  </span>

                  <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
                    {solution.title}
                  </h2>

                  <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                    {solution.description}
                  </p>

                  {/* Benefits */}
                  <div className="space-y-3 mb-8">
                    {solution.benefits.map((benefit) => (
                      <div key={benefit} className="flex items-center gap-3">
                        <CheckCircle2 size={18} className="text-secondary" />
                        <span className="text-foreground font-medium">
                          {benefit}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <a
                      href={`https://wa.me/${companyInfo.whatsapp}?text=${encodeURIComponent(companyInfo.whatsappMessages.default)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-secondary text-white rounded-full px-6 py-3 hover:bg-secondary/90 transition-colors inline-flex items-center gap-2 font-medium"
                    >
                      Solicitar informações
                      <ArrowRight size={18} />
                    </a>
                    {solution.detailsHref && (
                      <Link
                        to={solution.detailsHref}
                        className="border border-secondary text-secondary rounded-full px-6 py-3 hover:bg-secondary/10 transition-colors inline-flex items-center gap-2 font-medium"
                      >
                        Ver detalhes
                        <ExternalLink size={16} />
                      </Link>
                    )}
                  </div>
                </div>

                {/* Features Card */}
                <div className={index % 2 === 1 ? "lg:order-1" : ""}>
                  <div className="starry-bg rounded-3xl p-8 lg:p-10">
                    <h3 className="text-sm font-semibold text-white/80 mb-6 uppercase tracking-[0.15em]">
                      Funcionalidades
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      {solution.features.map((feature) => (
                        <div
                          key={feature}
                          className="flex items-center gap-3"
                        >
                          <div className="w-2 h-2 rounded-full bg-secondary" />
                          <span className="text-white/60 text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        ))}
      </section>

      {/* CTA */}
      <section className="starry-bg py-32 lg:py-40 relative overflow-hidden">
        {/* Subtle glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-gradient-radial from-secondary/10 to-transparent blur-3xl pointer-events-none" />
        
        <div className="container-dxm text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-2xl mx-auto"
          >
            <h2 className="text-headline text-white mb-6">
              Não sabe qual solução <span className="text-gradient-orange">escolher?</span>
            </h2>
            <p className="text-white/50 text-lg mb-12 font-light">
              Nossa equipe pode ajudar a identificar a melhor combinação para seu negócio.
            </p>
            <Link to="/contato" className="btn-secondary inline-flex items-center gap-2">
              Fale com um Especialista
              <ArrowRight size={18} />
            </Link>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Solucoes;
