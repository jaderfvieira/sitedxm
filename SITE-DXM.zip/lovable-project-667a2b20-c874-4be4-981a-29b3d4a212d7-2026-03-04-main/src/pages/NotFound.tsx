import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Layout } from "@/components/layout";
import { Home, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <Layout>
      <section className="section-dark min-h-screen flex items-center justify-center py-20">
        <div className="container-dxm text-center">
          <h1 className="font-display text-8xl md:text-9xl font-bold text-secondary mb-4">
            404
          </h1>
          <h2 className="font-display text-2xl md:text-3xl text-white mb-4">
            Página não encontrada
          </h2>
          <p className="text-white/70 text-lg mb-8 max-w-md mx-auto">
            A página que você está procurando não existe ou foi movida.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/"
              className="btn-secondary inline-flex items-center gap-2"
            >
              <Home size={18} />
              Voltar para Home
            </Link>
            <button
              onClick={() => window.history.back()}
              className="btn-primary bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 inline-flex items-center gap-2 text-white"
            >
              <ArrowLeft size={18} />
              Página Anterior
            </button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default NotFound;
