import { motion } from "framer-motion";
import { useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout";
import { Send, MessageCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

import { PuzzlePiece, ParticleField } from "@/components/prontuario";
import { supabase } from "@/integrations/supabase/client";

const Contato = () => {
  const formRef = useRef(null);
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const isProntuario = searchParams.get("produto") === "prontuario";


  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: isProntuario
      ? "Gostaria de agendar uma demonstração do Prontuário DXM para minha clínica."
      : "",
  });

  // Generate floating puzzle pieces
  const puzzlePieces = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 30 + Math.random() * 40,
    rotation: Math.random() * 360,
    delay: Math.random() * 5,
    color: ["blue", "red", "yellow", "green"][i % 4] as "blue" | "red" | "yellow" | "green",
  }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('contact_leads')
        .insert({
          name: formData.name,
          email: formData.email,
          phone: formData.phone || null,
          message: formData.message,
          source: isProntuario ? 'prontuario' : 'contato'
        });

      if (error) throw error;

      // Fire-and-forget: notifica por e-mail sem bloquear o fluxo
      supabase.functions.invoke('notify-new-lead', {
        body: { name: formData.name, email: formData.email, phone: formData.phone, message: formData.message, source: isProntuario ? 'prontuario' : 'contato' }
      }).catch(err => console.error('Erro ao notificar por e-mail:', err));

      toast({
        title: "Mensagem enviada!",
        description: "Nossa equipe entrará em contato em breve.",
      });

      setFormData({
        name: "",
        email: "",
        phone: "",
        message: "",
      });
    } catch (error) {
      console.error('Erro ao salvar lead:', error);
      toast({
        title: "Erro ao enviar",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      {/* Main Section */}
      <section className="relative min-h-screen pt-32 pb-16 lg:pt-40 lg:pb-24 overflow-hidden starry-bg">
        {/* Particle Field */}
        <ParticleField />

        {/* Floating Puzzle Pieces */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {puzzlePieces.map((piece) => (
            <motion.div
              key={piece.id}
              className="absolute opacity-20"
              style={{
                left: `${piece.x}%`,
                top: `${piece.y}%`,
              }}
              animate={{
                y: [0, -20, 0],
                rotate: [piece.rotation, piece.rotation + 10, piece.rotation],
              }}
              transition={{
                duration: 6 + piece.delay,
                repeat: Infinity,
                ease: "easeInOut",
                delay: piece.delay,
              }}
            >
              <PuzzlePiece size={piece.size} color={piece.color} />
            </motion.div>
          ))}
        </div>

        <div className="container-dxm relative z-10">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-start">
            
            {/* Column 1: Text Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-3 space-y-6"
            >
              {/* Tagline */}
              <div className="inline-flex items-center gap-2 text-secondary font-medium">
                <MessageCircle size={20} className="text-secondary" />
                <span>Vamos conversar?</span>
              </div>
              
              {/* Headline */}
              <h1 className="text-4xl lg:text-5xl font-semibold text-white leading-tight">
              {isProntuario ? (
                  <>Agende sua <span className="text-gradient-orange">demo.</span></>
                ) : (
                  <>Fale com nosso <span className="text-gradient-orange">time.</span></>
                )}
              </h1>
              
              {/* Description */}
              <p className="text-white/70 text-lg leading-relaxed">
                {isProntuario
                  ? "Descubra como o Prontuário DXM pode transformar a gestão da sua clínica ABA."
                  : "Somos especialistas em soluções TOTVS. Entre em contato e descubra como podemos ajudar sua empresa a crescer."}
              </p>
            </motion.div>

            {/* Column 2: Form */}
            <motion.div
              ref={formRef}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="lg:col-span-5"
            >
              <div 
                className="rounded-3xl p-6 lg:p-8 border border-white/10"
                style={{
                  background: "rgba(255, 255, 255, 0.05)",
                  backdropFilter: "blur(20px)",
                }}
              >
                <form onSubmit={handleSubmit} className="space-y-5">
                  {/* Nome */}
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Seu nome <span className="text-secondary">*</span>
                    </label>
                    <Input
                      type="text"
                      required
                      maxLength={100}
                      placeholder="Ex.: Ana Paula de Oliveira"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      className="bg-white/10 border border-white/20 h-12 rounded-xl text-white placeholder:text-white/40 focus:border-secondary focus:ring-secondary"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Seu e-mail <span className="text-secondary">*</span>
                    </label>
                    <Input
                      type="email"
                      required
                      maxLength={255}
                      placeholder="Ex.: ana.oliveira@email.com"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="bg-white/10 border border-white/20 h-12 rounded-xl text-white placeholder:text-white/40 focus:border-secondary focus:ring-secondary"
                    />
                  </div>

                  {/* Telefone */}
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Seu telefone com DDD <span className="text-white/50 text-xs">(opcional)</span>
                    </label>
                    <Input
                      type="tel"
                      maxLength={20}
                      placeholder="Ex.: 11 99999-9999"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="bg-white/10 border border-white/20 h-12 rounded-xl text-white placeholder:text-white/40 focus:border-secondary focus:ring-secondary"
                    />
                  </div>

                  {/* Mensagem */}
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Sobre o que gostaria de conversar? <span className="text-secondary">*</span>
                    </label>
                    <Textarea
                      required
                      maxLength={1000}
                      placeholder="Deixe uma mensagem prévia..."
                      value={formData.message}
                      onChange={(e) =>
                        setFormData({ ...formData, message: e.target.value })
                      }
                      className="bg-white/10 border border-white/20 min-h-[120px] rounded-xl text-white placeholder:text-white/40 focus:border-secondary focus:ring-secondary resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-secondary to-secondary/90 hover:from-secondary/90 hover:to-secondary/80 text-white py-6 text-base font-medium rounded-xl transition-all duration-300 group"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Enviando...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        Enviar mensagem
                        <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                      </span>
                    )}
                  </Button>
                </form>
              </div>
            </motion.div>

            {/* Column 3: Image */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-4 hidden lg:block"
            >
              <div className="relative h-full min-h-[500px]">
                <img
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                  alt="Equipe colaborativa em reunião"
                  className="w-full h-full object-cover rounded-3xl"
                  style={{
                    boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5)",
                  }}
                />
                
                {/* Floating Card */}
                <div 
                  className="absolute -bottom-4 -left-4 rounded-2xl p-4 max-w-[200px] border border-white/10"
                  style={{
                    background: "rgba(255, 255, 255, 0.1)",
                    backdropFilter: "blur(20px)",
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-secondary/20 flex items-center justify-center">
                      <Send size={18} className="text-secondary" />
                    </div>
                    <div>
                      <p className="text-xs text-white/60">Resposta em</p>
                      <p className="font-semibold text-white text-sm">até 24h</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

      </section>
    </Layout>
  );
};

export default Contato;
