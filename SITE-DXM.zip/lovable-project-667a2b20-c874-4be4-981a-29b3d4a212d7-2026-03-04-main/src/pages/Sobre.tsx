import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Layout } from "@/components/layout";
import { Target, Eye, Heart, Lightbulb, Users, CheckCircle2, Award, Server, Puzzle, Handshake, TrendingUp, Rocket, Megaphone, Package } from "lucide-react";
import { FloatingShape } from "@/components/decorative";

const values = [
  {
    icon: Target,
    title: "Resultados",
    description: "Somos movidos por resultados mensuráveis.",
  },
  {
    icon: Heart,
    title: "Gente Boa",
    description: "Valorizamos gente boa que é boa gente.",
  },
  {
    icon: Lightbulb,
    title: "Colaboração",
    description: "Quando colaboramos somos mais fortes.",
  },
  {
    icon: Users,
    title: "Relacionamento",
    description: "Construímos relações de longo prazo.",
  },
];

const strategicVision = [
  {
    icon: Server,
    text: <>Ser referência <strong>aos segmentos</strong> em Backoffice Protheus</>,
  },
  {
    icon: Puzzle,
    text: <>Entregar soluções <strong>complementares</strong> acopladas aos sistemas TOTVS</>,
  },
  {
    icon: Handshake,
    text: <>Ser Trusted Advisor <strong>para as áreas da TOTVS e clientes</strong>, agregando muito mais que entrega de serviços</>,
  },
  {
    icon: TrendingUp,
    text: <>Ser <strong>referência</strong> em vendas e prospecção de clientes nos segmentos homologados</>,
  },
  {
    icon: Rocket,
    text: <>Em até <strong>5 anos</strong>, ser o principal canal parceiro da TOTVS nos principais segmentos de atuação</>,
  },
  {
    icon: Megaphone,
    text: <>Ser <strong>referência</strong> em comunicação e novidades para TOTVS e clientes</>,
  },
  {
    icon: Package,
    text: <>Ser referência e apoio a <strong>ofertas</strong> de produtos em parceria com as Engenharias de Valor</>,
  },
];

const differentials = [
  "Especialistas certificados TOTVS",
  "Mais de 10 anos de experiência",
  "Suporte dedicado e personalizado",
  "Metodologia ágil de implantação",
  "Foco em resultados mensuráveis",
  "Atendimento humanizado",
];

const Sobre = () => {
  const visionRef = useRef(null);
  const heroRef = useRef(null);
  const valuesRef = useRef(null);
  const diffRef = useRef(null);
  const visionInView = useInView(visionRef, { once: true, margin: "-100px" });
  const heroInView = useInView(heroRef, { once: true });
  const valuesInView = useInView(valuesRef, { once: true, margin: "-100px" });
  const diffInView = useInView(diffRef, { once: true, margin: "-100px" });

  return (
    <Layout>
      {/* Hero Section */}
      <section ref={heroRef} className="starry-bg pt-40 pb-32 lg:pt-48 lg:pb-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={heroInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="max-w-4xl"
          >
            <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-8 block">
              Sobre a DXM
            </span>
            <h1 className="text-hero text-white mb-10">
              Quem <span className="text-gradient-orange">somos.</span>
            </h1>
            <p className="text-white/50 text-xl md:text-2xl leading-relaxed max-w-3xl font-light">
              Especialistas em soluções TOTVS, ajudando empresas a alcançar novos 
              patamares de eficiência através de implantações e automações inteligentes.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="bg-white py-32 lg:py-40">
        <div className="container-dxm">
          <div className="grid md:grid-cols-2 gap-8 lg:gap-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="p-10 lg:p-12 bg-muted rounded-3xl"
            >
              <div className="w-16 h-16 rounded-2xl bg-foreground flex items-center justify-center mb-8">
                <Target size={28} className="text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">
                Nossa Missão
              </h3>
              <p className="text-muted-foreground leading-relaxed text-lg">
                Capacitar empresas com soluções tecnológicas de excelência, 
                simplificando processos e impulsionando o crescimento sustentável.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="p-10 lg:p-12 bg-muted rounded-3xl"
            >
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-secondary to-secondary/80 flex items-center justify-center mb-8">
                <Eye size={28} className="text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">
                Nossa Visão
              </h3>
              <p className="text-muted-foreground leading-relaxed text-lg">
                Ser a principal referência em implantação e integração de 
                soluções TOTVS, sendo parceiros estratégicos na transformação digital.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Strategic Vision */}
      <section ref={visionRef} className="bg-muted py-32 lg:py-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={visionInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-20"
          >
            <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
              Visão Estratégica
            </span>
            <h2 className="text-headline text-foreground">
              Para onde <span className="text-gradient-orange">caminhamos.</span>
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {strategicVision.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={visionInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`p-8 bg-white rounded-3xl shadow-sm ${index === 6 ? "sm:col-start-1 lg:col-start-2" : ""}`}
              >
                <div className="w-14 h-14 rounded-2xl bg-foreground flex items-center justify-center mb-6">
                  <item.icon size={24} className="text-white" />
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {item.text}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section ref={valuesRef} className="bg-muted py-32 lg:py-40">
        <div className="container-dxm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={valuesInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-20"
          >
            <span className="text-primary text-xs font-semibold uppercase tracking-[0.2em] mb-4 block">
              Nossos Valores
            </span>
            <h2 className="text-headline text-foreground">
              O que nos move.
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                animate={valuesInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-white shadow-sm flex items-center justify-center mx-auto mb-6">
                  <value.icon size={28} className="text-foreground" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {value.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Differentials */}
      <section ref={diffRef} className="starry-bg py-32 lg:py-40 relative overflow-hidden">
        {/* Floating Diagonal Lines */}
        <FloatingShape
          variant="diagonal-lines"
          size={250}
          position={{ bottom: "10%", left: "-5%" }}
          animation="parallax"
          opacity={0.05}
        />
        <div className="container-dxm">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={diffInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7 }}
            >
              <span className="text-secondary text-xs font-semibold uppercase tracking-[0.2em] mb-8 block">
                Por que a DXM?
              </span>
              <h2 className="text-headline text-white mb-8">
                Diferenciais que <span className="text-gradient-orange">importam.</span>
              </h2>
              <p className="text-white/50 text-lg leading-relaxed font-light">
                Combinamos expertise técnica, metodologia comprovada e 
                atendimento personalizado para garantir o sucesso de cada projeto.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={diffInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="grid sm:grid-cols-2 gap-4"
            >
              {differentials.map((item, index) => (
                <motion.div
                  key={item}
                  initial={{ opacity: 0, y: 10 }}
                  animate={diffInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                  className="flex items-center gap-4 glass rounded-2xl p-5"
                >
                  <CheckCircle2 size={18} className="text-secondary flex-shrink-0" />
                  <span className="text-white/70 text-sm font-medium">{item}</span>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Partnership */}
      <section className="bg-white py-32 lg:py-40">
        <div className="container-dxm text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="w-20 h-20 rounded-3xl bg-muted flex items-center justify-center mx-auto mb-10">
              <Award size={40} className="text-foreground" />
            </div>
            <h2 className="text-headline text-foreground mb-6">
              Parceiro oficial <span className="text-gradient-petrol">TOTVS.</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Como parceiro oficial, temos acesso às melhores ferramentas, 
              treinamentos e suporte direto da TOTVS.
            </p>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Sobre;
