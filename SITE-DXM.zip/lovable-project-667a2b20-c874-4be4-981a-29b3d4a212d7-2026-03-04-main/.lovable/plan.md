

## Adicionar Favicon do site

Copiar a imagem enviada para `public/favicon.png` e atualizar `index.html` para referenciá-la.

### Alterações

1. **Copiar** `user-uploads://Novo_Logo_DXM_02.fw-5.png` → `public/favicon.png`
2. **Editar** `index.html`: substituir `<link rel="icon" href="/favicon.ico">` por `<link rel="icon" href="/favicon.png" type="image/png">`

2 alterações, 1 arquivo copiado.

